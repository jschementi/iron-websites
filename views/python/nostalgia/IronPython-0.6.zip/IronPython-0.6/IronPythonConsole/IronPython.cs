/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.IO;
using System.Reflection;
using System.Text;
using System.Collections;

using System.Globalization;

using System.Diagnostics;

using IronPython.AST;
using IronPython.Modules;
using IronPython.Objects;

namespace IronPythonConsole
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class IronPython
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args) {
			Options.MonoWorkaround = HasMonoLongBug();
			if (Options.MonoWorkaround) {
				//???Console.WriteLine("Using workaround for long-multiply overflow bug (mono-1.0)");
			}

			if (args.Length == 0) {
				DoInteractive();
			} else if (args.Length >= 1) {
				object t = SnippetMaker.snippetAssembly;
				try {
					DoFile(args);
				} finally {
					ReflectedMethodBase.DumpReflectedCalls(); //??? 
					try {
						SnippetMaker.DumpAssembly();
					} catch (NotSupportedException) { } // usually not important info...
				}
			} else {
				throw new NotImplementedException("more than 1 arg: " + args.Length);
			}
		}

		private static void DoFile(string[] args) {
			int i=0;
			bool absInterp = false;
			while (i < args.Length) {
				if (args[i] == "-O2") {
					Options.FRAME_FUNCTIONS = false;
				} else if (args[i] == "-abs") {
					absInterp = true;
				} else if (args[i] == "-O") {
					Options.DEBUG = false;
				} else {
					break;
				}
				i++;
			}

			string source = args[i];
			List argv = new List();
			for (; i<args.Length; i++) argv.append(args[i]);
			sys.argv = argv;

			sys.path.append(Path.GetDirectoryName(source));


//			PyList argv = PyList.make();
//			for (;i<args.Length; i++) argv.append(PyString.make(args[i]));
//			sys.argv = argv;
			//!!!sys.path.append(PyString.make(Path.GetDirectoryName(source)));

			Parser p =Parser.fromFile(source);
			Stmt s = p.parseFileInput();

			if (absInterp) {
				NameEnv env = new NameEnv(new module(), null);
				s.Execute(env);
			} else {
				ModuleDef md = new ModuleDef(Name.make("__main__"), s);

				module mod =  md.Generate(source); //, "temp.exe");

				sys.modules[mod.__name__] = mod;

				//!!!sys.modules.__setitem__(mod.__name__, mod);

				// try { ///
				mod.init();
//			} else {
//				ModuleDef md = new ModuleDef(Name.make("__main__"), s);
//
//				PyModule mod =  md.generate(source); //, "temp.exe");
//
//				sys.modules.__setitem__(mod.__name__, mod);
//
//				// try { ///
//				mod.init();
			}

			//			try {

			//			} catch (TargetInvocationException e) {
			//				Exception ie = e.InnerException;
			//				ppException(ie);
			//				//Console.WriteLine(ie.GetType().Name + ": " + ie.Message);
			//				//Console.WriteLine(ie.StackTrace);
			//
			//				//!!! This is great fun
			//				//StackTrace st = new StackTrace(ie, true);
			//				//Console.WriteLine(st);
			//				//Console.WriteLine(st.GetFrame(0));
			//
			//				//Console.WriteLine(st.GetFrame(2));
			//			}
		}

		private static bool HasMonoLongBug() {
			try {
				long x = 582645929725440000;
				checked {
					x = 256 * x;
				}
				return true;
			} catch (OverflowException) {
				return false;
			}
		}


		private static Stmt ParseText(string text) {
			Parser p = Parser.fromString(text);
			try {
				return p.parseStmt();
			} catch (PythonSyntaxError se) {
				if (se.Message.IndexOf("<eof>") > 0) return null;
				throw se;
			}
		}


		private static void DoInteractive() {
			sys.path.append(Environment.CurrentDirectory);

			module top = new module();
			//Dict globals = new Dict();
			Frame topFrame = new Frame(top);

			while (true) {
				Console.Write(sys.ps1.ToString());
				

				try {
					StringBuilder b = new StringBuilder();
					Stmt s;
					while (true) {
						string line = Console.ReadLine();
						if (line == null) goto end;
						b.Append(line);
						s = ParseText(b.ToString());
						if (b.ToString().IndexOf('\n') != -1) {
							if (line == "") break;
						} else {
							if (s != null) break;
						}
						
						b.Append("\n");
						Console.Write("... ");
						Console.Out.Flush();
					}

					FrameCode code = SnippetMaker.generate(s, "input");
					code.Run(topFrame);
				} catch (Exception e) {
					Console.Error.WriteLine(e);
				}
			}
			end:;
		}
	}
}
