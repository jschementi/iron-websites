/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
//using NUnit.Framework;
using System.IO;

namespace IronMath {
	/// <summary>
	/// Summary description for integerTest.
	/// </summary>
//	[TestFixture]
//	public class integerTest {
//		integer i0 = integer.make(0);
//		integer i1 = integer.make(1);
//		const long L0 = 1234567890L;
//		integer iL0 = integer.make(L0);
//
//		[Test] public void strings() {
//			Assert.AreEqual("0", i0.ToString());
//			Assert.AreEqual("1", i1.ToString());
//			Assert.AreEqual(L0.ToString(), iL0.ToString());
//		}
//
//		[Test] public void add() {
//			Assert.AreEqual(integer.make(0), i0+i0);
//			Assert.AreEqual(integer.make(1), i1+i0);
//			Assert.AreEqual(integer.make(1), i0+i1);
//			Assert.AreEqual(integer.make(2), i1+i1);
//		}
//
//		[Test] public void subtract() {
//			Assert.AreEqual(integer.make(0), i0-i0);
//			Assert.AreEqual(integer.make(1), i1-i0);
//			Assert.AreEqual(integer.make(-1), i0-i1);
//			Assert.AreEqual(integer.make(0), i1-i1);
//		}
//
//		private integer[] makeTestNums(string kind) {
//			uint[] pats = {0, 1, 42, 0x7fffffff, 0x80000000, 0xabcdef01, 0xffffffff};
//			int n2 = 1;
//			if (kind != "short") n2 = pats.Length;
//
//			int n = n2*pats.Length*pats.Length*2;
//
//			integer[] ret = new integer[n];
//			int ri = 0;
//			for (int i0 = 0; i0< pats.Length; i0++) {
//				for (int i1 = 0; i1 < pats.Length; i1++) {
//					for (int i2=0; i2 < n2; i2++) {
//						ret[ri++] = new integer(+1, pats[i0], pats[i1], pats[i2]);
//						ret[ri++] = new integer(-1, pats[i0], pats[i1], pats[i2]);
//					}
//				}
//			}
//			return ret;
//		}
//
//		private void doBlock(string name, string kind, iop2 op) {
//			integer[] nums = makeTestNums(kind);
//
//			using (StreamReader r = (kind.StartsWith("time")) ? null :
//					   new StreamReader("../../scripts/" + kind + "_" + name + ".txt")) {
//				foreach (integer x in nums) {
//					foreach (integer y in nums) {
//						string actual=null;
//						try {
//							integer z = op(x, y);
//							if (r != null || kind == "time1") actual = z.ToString();
//						} catch(Exception) {
//							actual = "ERROR";
//						}
//						if (r == null) continue;
//						string line = r.ReadLine().Trim();
//						Assert.AreEqual(line, actual, name + "(" + x + ", " + y + ")");
//					}
//				}
//			}
//		}
//
//		delegate integer iop2(integer x, integer y);
//
//		private static string KIND = "full";
//		[Test] public void autoAdd() { doBlock("add", KIND, new iop2(integer.add)); }
//		[Test] public void autoSub() { doBlock("sub", KIND, new iop2(integer.subtract)); }
//		[Test] public void autoMul() { doBlock("mul", KIND, new iop2(integer.multiply)); }
//		[Test] public void autoDiv() { doBlock("div", KIND, new iop2(integer.divide)); }
//		[Test] public void autoMod() { doBlock("mod", KIND, new iop2(integer.modulo)); }
//		[Test] public void autoAnd() { doBlock("and_", KIND, new iop2(integer.and)); }
//		[Test] public void autoOr() { doBlock("or_", KIND, new iop2(integer.or)); }
//		[Test] public void autoXor() { doBlock("xor", KIND, new iop2(integer.xor)); }
//	}
}
