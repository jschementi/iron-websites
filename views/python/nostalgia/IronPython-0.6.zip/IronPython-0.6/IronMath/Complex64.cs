/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Diagnostics;
using System.Text;
using System.Collections;

namespace IronMath {
	/// <summary>
	/// arbitrary precision integers
	/// </summary>
	public struct Complex64:IComparable {
		public readonly double real, imag;

		public static Complex64 MakeImaginary(double imag) {
			return new Complex64(0.0, imag);
		}

		public static Complex64 MakeReal(double real) {
			return new Complex64(real, 0.0);
		}

		public Complex64(double real, double imag) {
			this.real = real;
			this.imag = imag;
		}

		public Complex64 conjugate() {
			return new Complex64(real, -imag);
		}


		public override string ToString() {
			if (real == 0.0) return imag.ToString() + "j";
			else return string.Format("({0}+{1}j)", real, imag);
		}

		public static implicit operator Complex64(double d) {
			return MakeReal(d);
		}

		public static implicit operator Complex64(integer i) {
			return MakeReal(i.ToFloat64());  //!!! can throw an overflow exception
		}

		public static bool operator ==(Complex64 x, Complex64 y) {
			return x.real == y.real && x.imag == y.imag;
		}

		public static bool operator !=(Complex64 x, Complex64 y) {
			return x.real != y.real || x.imag != y.imag;
		}


		public static Complex64 Add(Complex64 x, Complex64 y) { return x + y; }

		public static Complex64 operator +(Complex64 x, Complex64 y) {
			return new Complex64(x.real+y.real, x.imag+y.imag);
		}

		public static Complex64 subtract(Complex64 x, Complex64 y) { return x - y; }

		public static Complex64 operator -(Complex64 x, Complex64 y) {
			return new Complex64(x.real-y.real, x.imag-y.imag);
		}

		public static Complex64 multiply(Complex64 x, Complex64 y) { return x * y; }

		public static Complex64 operator *(Complex64 x, Complex64 y) {
			return new Complex64(x.real*y.real - x.imag*y.imag, x.real*y.imag + x.imag*y.real);
		}

		public static Complex64 divide(Complex64 x, Complex64 y) { return x / y; }

		public static Complex64 operator /(Complex64 a, Complex64 b) {
			//!!! read the comments in complexobject.c in the standard Python distrib before implementing this naively
			throw new NotImplementedException("complex division");
		}

		public static Complex64 modulo(Complex64 x, Complex64 y) { return x % y; }

		public static Complex64 operator %(Complex64 x, Complex64 y) {
			throw new NotImplementedException();
		}



		public static Complex64 operator -(Complex64 x) {
			return new Complex64(-x.real, -x.imag);
		}

		public static double Hypot(double x, double y) {
			//!!! this is a very naive implementation of this algorithm
			return Math.Sqrt(x*x + y*y);
		}

		public double Abs() {
			return Hypot(real, imag);
		}

		public Complex64 Power(Complex64 y) {
			throw new NotImplementedException();
		}

//		public Complex64 pow(int power) {
//			if (power == 0) return ONE;
//			if (power < 0) throw new ArgumentOutOfRangeException("power", power, "power must be >= 0");
//			integer factor = this;
//			integer result = ONE; //!!! want a mutable here for efficiency
//			while (power != 0) {
//				if ((power & 1) != 0) result = result*factor;
//				factor = factor.square();
//				power >>=1;
//			}
//			return result;
//		}

		public override int GetHashCode() {
			return (int)real;  //!!! weak
		}

		public override bool Equals(object obj) {
			if (!(obj is Complex64)) return false;
			return this == ((Complex64)obj);
		}

		#region IComparable Members

		public int CompareTo(object obj) {
			throw new NotImplementedException();
		}

		#endregion
	}
}
