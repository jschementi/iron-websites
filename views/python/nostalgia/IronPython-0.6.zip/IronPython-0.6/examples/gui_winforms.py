from System.Windows.Forms import *
from System.Drawing import *

f = Form(Text="Windows fun with IronPython", HelpButton=True,
         MinimizeBox=False, MaximizeBox=False)

f.FormBorderStyle = FormBorderStyle.FixedDialog
f.StartPosition = FormStartPosition.CenterScreen

b1 = Button(Text="Say Something", Location=Point(30,30), Size=Size(100,30))

def push(data, event):
    l = Label(Text="IronPython Is Alive!", ForeColor=Color.Red)
    l.Location = Point(30, 50+f.Controls.Count*25)
    f.Controls.Add(l)

b1.Click += push

f.Controls.Add(b1)
f.ShowDialog()

