import Gtk

Gtk.Application.Init()
w = Gtk.Window("hello world")
w.DeleteEvent += lambda *ignore: Gtk.Application.Quit()

b = Gtk.Button("click me")

def say_hello(o, args): print "hello"

b.Clicked += say_hello

w.Add(b)
w.ShowAll()
Gtk.Application.Run()
