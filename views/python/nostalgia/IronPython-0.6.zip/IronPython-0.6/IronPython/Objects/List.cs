/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;
using System.Collections.Specialized;

using System.Reflection;
using System.Text;

using IronPython.AST;

namespace IronPython.Objects {

	[PythonType("list")]
	public class List:IMutableSequence,IList,IComparable {
		private int size;
		private object[] data;

		public static List Make() {
			return new List();
		}

		public static List Make(object o) {
			if (o is List) return (List)o;
			return new List(Ops.GetEnumerator(o));
		}

		private List(IEnumerator e):this(10) {
			while (e.MoveNext()) append(e.Current);
		}

		public static List MakeList(params object[] items) {
			return new List(items);
		}

		public static List MakeEmptyList(int capacity) {
			return new List(capacity);
		}

		private List(int capacity) { data = new object[capacity]; size = 0;}
		private List(params object[] items) { data = items; size = data.Length; } //!!! do we need to copy
		public List():this(20) {}  //!!! figure out the right default size
		public List(ICollection items): this(items.Count) {
			int i = 0;
			foreach (object item in items) {
				data[i++] = item;
			}
			size = i;
		}

		public static List operator *(List l, int count) {
			return (List)l.__mul__(count);
		}

		public static List operator *(int count, List l) {
			return (List)l.__mul__(count);
		}

		public object[] GetObjectArray() {
			object[] ret = new object[size];
			Array.Copy(data, 0, ret, 0, size);
			return ret;
		}

		#region ISequence Members

		public int __len__() {
			return size;
		}

		public bool __contains__(object item) {
			return Array.IndexOf(data, item, 0, size) >= 0;
		}

		public virtual object __getitem__(int index) {
			return data[Ops.FixIndex(index, size)];
		}

		public virtual object __add__(object other) {
			List l = other as List;
			if (l == null) throw Ops.TypeError("can only concatenate list (not \"{0}\") to list", Ops.GetDynamicType(other).__name__);
			
			object[] ret = new object[size + l.size];
			Array.Copy(data, 0, ret, 0, size);
			Array.Copy(l.data, 0, ret, size, l.size);
			return new List(ret);
		}

		public virtual void __delitem__(int index) {
			RawDelete( Ops.FixIndex(index, size) );
		}

		public virtual void __setitem__(int index, object value) {
			data[ Ops.FixIndex(index, size) ] = value;
		}

//		public override PyObject __iadd__(PyObject other) {
//			extend(other);
//			return this;
//		}

		public object __mul__(int count) {
			int n = this.size;
			//??? is this useful optimization
			//???if (n == 1) return new List(Array.ArrayList.Repeat(this[0], count));

			int newCount = n*count;
			
			object[] ret = new object[newCount];
			Array.Copy(data, 0, ret, 0, n);

			// this should be extremely fast for large count as it uses the same algoithim as efficient integer powers
			// ??? need to test to see how large count and n need to be for this to be fastest approach
			int block=n;
			int pos = n;
			while (pos < newCount) {
				Array.Copy(ret, 0, ret, pos, Math.Min(block, newCount-pos));
				pos += block;
				block *= 2;
			}
			return new List(ret);
		}

		public object __getitem__(Slice slice) {
			int start, stop, step;
			slice.indices(size, out start, out stop, out step);

			if (step == 1) {
				int n = stop-start;
				object[] ret = new object[n];
				Array.Copy(data, start, ret, 0, n);
				return new List(ret);
			} else {
				int n = (stop-start)/step;
				object[] ret = new object[n];
				int ri = 0;
				for (int i=start; i < stop; i+= step) {
					ret[ri++] = data[i];
				}
				return new List(ret);
			}
		}

		public void __setitem__(Slice slice, object value) {
			throw new NotImplementedException();
		}

		public void __delitem__(Slice slice) {
			int start, stop, step;
			slice.indices(size, out start, out stop, out step);
            
			if (step == 1) {
				int i = start;
				for (int j=stop; j < size; j++) {
					data[i++] = data[j];
				}
				size -= stop-start;
			} else {
				throw new NotImplementedException();
			}
		}

		#endregion

		private void RawDelete(int index) {
			int len = size-1;
			size = len;
			object[] tempData = data;
			for (int i=index; i < len; i++) {
				tempData[i] = tempData[i+1];
			}
		}


		public override string ToString() {
			StringBuilder buf = new StringBuilder();
			buf.Append("[");
			for(int i=0; i < size; i++) {
				if (i > 0) buf.Append(", ");
				buf.Append(Ops.StringRepr(data[i]));
			}
			buf.Append("]");
			return buf.ToString();
		}
		
		private void EnsureSize(int needed) {
			if (data.Length >= needed) return;

			int newSize = Math.Max(size*2, 4);
			while (newSize < needed) newSize *= 2;
			object[] newData = new object[newSize];
			data.CopyTo(newData, 0);
			data = newData;
		}


		public void append(object item) {
			EnsureSize(size+1);
			data[size] = item;
			size += 1;
		}

		public int count(object item) {
			int cnt = 0;
			for (int i=0, len=size; i < len; i++) {
				if (data[i].Equals(item)) cnt++;
			}
			return cnt;
		}

		public void extend(object seq) {
			//!!! optimize case of easy sequence (List or Tuple)

			IEnumerator i = Ops.GetEnumerator(seq);
			while (i.MoveNext()) append(i.Current);
		}

		private int ErrorOnIndexNotFound(int index) {
			if (index < 0) throw Ops.ValueError("list.index(x): x not in list");
			return index;
		}

		public int index(object item) {
			return ErrorOnIndexNotFound(Array.IndexOf(data, item, 0, size));
		}

		public int index(object item, int start) {
			//??? fix indices
			return ErrorOnIndexNotFound(Array.IndexOf(data, item, start, size-start));
		}

		public int index(object item, int start, int stop) {
			//??? fix indices
			return ErrorOnIndexNotFound(Array.IndexOf(data, item, start, stop-start));
		}

		//TODO 'insert'

		public object pop() {
			if (this.size == 0) throw Ops.ValueError("pop off of empty list");
			this.size -= 1;
			return this.data[this.size];
		}

		public void remove(object item) {
			RawDelete(index(item));
		}

		public void reverse() {
			Array.Reverse(data);
		}

		private class DefaultPythonComparer:IComparer {
			public static DefaultPythonComparer Instance = new DefaultPythonComparer();
			public DefaultPythonComparer() {  }

			public int Compare(object x, object y) {
				//??? Putting this optimization here is awfully special case, but comes close to halving sort time for int lists
//				if (x is int && y is int) {
//					int xi = (int)x;
//					int yi = (int)y;
//					return xi == yi ? 0 : (xi < yi ? -1 : +1);
//				}

				return Ops.Compare(x, y);
			}
		}

		public void sort() {
#if ONLY_JIMS_CODE
			Array.Sort(data, 0, size, DefaultPythonComparer.Instance);
#else
			new MergeState(data, size, null).sort();
#endif
		}

		private class FunctionComparer:IComparer {
			//??? optimized version when we know we have a Function
			private object cmpfunc;
			public FunctionComparer(object cmpfunc) { this.cmpfunc = cmpfunc; }

			public int Compare(object o1, object o2) {
				return Ops.object2int(Ops.Call(cmpfunc, o1, o2));
			}
		}

		public void sort(object cmpfunc) {
#if ONLY_JIMS_CODE
			Array.Sort(data, 0, size, new FunctionComparer(cmpfunc));		
#else
			new MergeState(data, size, cmpfunc).sort();
#endif
		}

		public override bool Equals(object obj) {
			List l = obj as List;
			if (l == null) return false;
			return Ops.CompareArrays(data, size, l.data, l.size) == 0;
		}

		public override int GetHashCode() {
			throw Ops.TypeError("list object is unhashable");
		}



		public int CompareTo(object other) {
			//!!! how to handle different type
			List l = other as List;
			if (l == null) throw new ArgumentException("expected list");

			return Ops.CompareArrays(data, size, l.data, l.size);
		}

		#region IList Members

		public bool IsReadOnly {
			get { return false; }
		}

		public object this[int index] {
			get {
				if (index < 0 || index >= size) throw new IndexOutOfRangeException();
				return data[index];
			}
			set {
				if (index < 0 || index >= size) throw new IndexOutOfRangeException();
				data[index] = value;
			}
		}

		public void RemoveAt(int index) {
			RawDelete(index);
		}

		public void Insert(int index, object value) {
			// TODO:  Add PyList.Insert implementation
		}

		public void Remove(object value) {
			remove(value);
		}

		public bool Contains(object value) {
			return __contains__(value);
		}

		public void Clear() {
			size = 0;
		}

		public int IndexOf(object value) {
			return Array.IndexOf(data, value, 0, size);
		}

		public int Add(object value) {
			append(value);
			return size-1;
		}

		public bool IsFixedSize {
			get { return false; }
		}

		#endregion

		#region ICollection Members

		public bool IsSynchronized {
			get { return false; }
		}

		public int Count {
			get { return size; }
		}

		public void CopyTo(Array array, int index) {
			Array.Copy(data, 0, array, index, size);
		}

		public object SyncRoot {
			get {
				throw new NotImplementedException();
			}
		}

		#endregion

		#region IEnumerable Members

		public IEnumerator GetEnumerator() {
			return new ListEnumerator(this);
		}

		#endregion

		private class ListEnumerator:IEnumerator {
			private int index = -1;
			private List l;
			public ListEnumerator(List l) { this.l = l; }

			#region IEnumerator Members

			public void Reset() {
				index = -1;
			}

			public object Current {
				get {
					return l.data[index];
				}
			}

			public bool MoveNext() {
				index++;
				return index < l.size;
			}

			#endregion

		}
	}
}
