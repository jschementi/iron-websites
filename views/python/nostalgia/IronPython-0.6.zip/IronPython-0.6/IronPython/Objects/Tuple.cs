/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;
using System.Text;

namespace IronPython.Objects {
	[PythonType("tuple")]
	public class Tuple:ISequence,ICollection,IComparable {
		private static Tuple EMPTY = new Tuple();

//		public static Tuple Make() {
//			return EMPTY;
//		}

		public static Tuple Make(object o) {
			if (o is Tuple) return (Tuple)o;
			return new Tuple(MakeItems(o));
		}

		public static Tuple MakeTuple(params object[] items) {
			if (items.Length == 0) return EMPTY;
			return new Tuple(items);
		}

		private static object[] MakeItems(object o) {
			if (o is Tuple) return ((Tuple)o).data;

			//!!! add special cases for obvious forms of o
			ArrayList l = new ArrayList();
			IEnumerator i = Ops.GetEnumerator(o);
			while (i.MoveNext()) {
				l.Add(i.Current);
			}

//			if (l.Count > 4) {
//				Console.WriteLine(l);
//			}
			return l.ToArray();
		}
//
//
//		public static PyTuple make(PyObject o) {
//			if (o is PyTuple) return (PyTuple)o;
//			return make(MakeItems(o));
//		}

		private readonly object[] data;

		public Tuple(object o) {
			this.data = MakeItems(o);
		}

		private Tuple(params object[] items) {
			this.data = items;
		}

		#region ISequence Members

		public int __len__() {
			return data.Length;
		}

		public bool __contains__(object item) {
			return ArrayOps.Contains(data, data.Length, item);
		}

		public object __getitem__(int index) {
			return data[Ops.FixIndex(index, data.Length)];
		}

		public object __add__(object other) {
			Tuple o = other as Tuple;
			if (o == null) throw Ops.TypeError("can only concatenate tuple (not \"{0}\") to tuple", Ops.GetDynamicType(other).__name__);

			return MakeTuple(ArrayOps.Add(data, data.Length, o.data, o.data.Length));
		}

		public object __mul__(int count) {
			return MakeTuple(ArrayOps.Multiply(data, data.Length, count));
		}

		public object __getitem__(Slice slice) {
			return MakeTuple(ArrayOps.GetSlice(data, data.Length, slice));
		}

		#endregion


		#region ICollection Members

		public bool IsSynchronized {
			get { return false; }
		}

		public int Count {
			get { return data.Length; }
		}

		public void CopyTo(Array array, int index) {
			Array.Copy(data, 0, array, index, data.Length);
		}

		public object SyncRoot {
			get {
				throw new NotImplementedException();
			}
		}

		#endregion

		#region IEnumerable Members

		public IEnumerator GetEnumerator() {
			return data.GetEnumerator();
		}

		#endregion


		public object this[int index] {
			get { return data[index]; }
		}

		public override int GetHashCode() {
			int ret = 0;
			foreach (object o in data) {
				ret ^= o.GetHashCode(); //!!! terrible hashing
			}
			return ret;
		}


		public override bool Equals(object obj) {
			Tuple l = obj as Tuple;
			if (l == null) return false;
			return Ops.CompareArrays(data, data.Length, l.data, l.data.Length) == 0;
		}


		public int CompareTo(object other) {
			//!!! how to handle different type
			Tuple l = other as Tuple;
			if (l == null) throw new ArgumentException("expected list");

			return Ops.CompareArrays(data, data.Length, l.data, l.data.Length);
		}

		public override string ToString() {
			StringBuilder buf = new StringBuilder();
			buf.Append("(");
			for(int i=0; i < data.Length; i++) {
				if (i > 0) buf.Append(", ");
				buf.Append(Ops.StringRepr(data[i]));
			}
			if (data.Length == 1) buf.Append(",");
			buf.Append(")");
			return buf.ToString();
		}
	}

//	public class Tuple2 {
//		private object d0, d1;
//
//		public Tuple2(object d0, object d1) {
//			this.d0 = d0;
//			this.d1 = d1;
//		}
//	}
}
