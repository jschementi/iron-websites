/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Text;
using System.Globalization;
using System.Collections;

namespace IronPython.Objects {
	/// <summary>
	/// Summary description for StringFormatter.
	/// </summary>
	public class StringFormatter {
		private static NumberFormatInfo nfi = new CultureInfo( "en-US", false ).NumberFormat;

		private object rawData;
		private Tuple data;
		private string str;
		private int index;

		private int itemCount;

		private StringBuilder buf;

		public StringFormatter(string str, object data) {
			this.str = str;
			this.rawData = data;
		}

		private object getData(int index) {
			if (index == 0) {
				if (rawData is Tuple) {
					data = (Tuple)rawData;
					return data[0];
				} else {
					return rawData;
				}
			} else {
				if (data == null) throw new Exception("tuple required");
				return data[index]; //.__getitem__(index);
			}
		}

		private void appendInt(int precision) {
			buf.Append( Ops.object2int( getData(itemCount++) ) );
		}

		private void appendFloat(int precision) {
			double v = Convert.ToDouble(getData(itemCount++)); //o.__float__().value;
			if (precision == -1) {
				buf.Append(v);
			} else {
				nfi.NumberDecimalDigits = precision;
				buf.Append(v.ToString("f", nfi));
			}
		}

		private void appendString(int precision) {
			string s = Ops.ToString(getData(itemCount++));
			if (precision != -1 && s.Length > precision) s = s.Substring(0, precision);
			buf.Append(s);
		}
		private void appendRepr(int precision) {
			string s = Ops.StringRepr(getData(itemCount++));
			if (precision != -1 && s.Length > precision) s = s.Substring(0, precision);
			buf.Append(s);
		}

		private int readInt() {
			//!!! more than one digit support
			return int.Parse(new string(str[index++], 1));
		}
		

		private void doFormatCode() {
			char ch = str[index++];
			if (ch == '%') {
				buf.Append('%');
				return;
			}

			string key = null;
			if (ch == '(') {
				int start = index;
				int end = str.IndexOf(')', start);
				key = str.Substring(start, end-start-1);
				index = end+1;
				ch = str[index++];
			}

			//!!! conversion flags

			int precision = -1;
			if (ch == '.') {
				int start = index;
				if (str[index] == '*') {
					throw new NotImplementedException("* for precision");
				} else {
					while (char.IsDigit(str, index)) { index++; }
					precision = int.Parse(str.Substring(start, index-start));
				}
				ch = str[index++];				
			}

			switch (ch) {
				case 'd': appendInt(precision); return;
				case 'f': appendFloat(precision); return;
				case 'g': appendFloat(precision); return;
				case 's': appendString(precision); return;
				case 'r': appendRepr(precision); return;
				default:
					throw new NotImplementedException("format code " + ch);
			}
		}

		public string format() {
			index = 0;
			buf = new StringBuilder(str.Length * 2);
			int modIndex;

			while ( (modIndex = str.IndexOf('%', index)) != -1) {
				buf.Append(str, index, modIndex-index);
				index=modIndex+1;
				doFormatCode();
			}
			buf.Append(str, index, str.Length-index);

			return buf.ToString();
		}
	}
}
