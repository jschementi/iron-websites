/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Text;
using System.Collections;
using System.Reflection;

using IronPython.AST;
using IronMath;

namespace IronPython.Objects {
	public class ExtensibleInt:IComparable {
		public int _value;
		public ExtensibleInt(int _value) { this._value = _value; }

		public override string ToString() {
			return _value.ToString();
		}

		public virtual int __cmp__(object other) {
			return IntOps.__cmp__(_value, other);
		}

		#region IComparable Members

		public int CompareTo(object obj) {
			return __cmp__(obj); //???
		}

		#endregion
		//!!! lots more virtual methods to add here
	}
//	public class ExtensibleInt:IComparable,ICodeFormattable,ISuperDynamicObject {
//		public ReflectedType __class__;
//		public int _value;
//		public ExtensibleInt(int _value) { this._value = _value; }
//
//		public override string ToString() {
//			object ret;
//			if (__class__.TryToInvoke(out ret, this, "__str__")) return (string)ret;
//
//			return _value.ToString();
//		}
//
//		#region ICodeFormattable Members
//
//		public virtual string ToCodeString() {
//			object ret;
//			if (__class__.TryToInvoke(out ret, this, "__repr__")) return (string)ret;
//
//			return _value.ToString();
//		}
//
//		#endregion
//
////		public virtual int __cmp__(object obj) {
////			return IntOps.__cmp__(_value, obj);
////		}
//
//		#region IComparable Members
//
//		//!!! this is just a mess
//		public virtual int CompareTo(object obj) {
//			object cmp = __class__.__cmp__;
//			if (cmp == null && __class__.rawBases != null) {  //!!! This search is not quite right
//				for (int i = 0; i < __class__.rawBases.Count; i++) {
//					ReflectedType b = (ReflectedType)__class__.rawBases[i];
//					if (b.isUserType) cmp = b.__cmp__;
//					if (cmp != null) break;
//				}
//			}
//
//			if (cmp != null) {
//				return Ops.object2int(Ops.Call(cmp, this, obj));
//			}
//
//			return IntOps.__cmp__(_value, obj);
//		}
//
//		#endregion
//
//		#region ISuperDynamicObject Members
//
//		public virtual Dict GetDict() {
//			throw new NotImplementedException();
//		}
//
//		public virtual void SetDict(Dict dict) {
//			throw new NotImplementedException();
//		}
//
//		public void SetDynamicType(ReflectedType newType) {
//			__class__ = newType;
//		}
//
//		#endregion
//
//		#region IDynamicObject Members
//
//		public bool GetSlot(string name, out object ret) {
//			return __class__.GetSlotForInstance(this, name, out ret);
//		}
//
//		public void SetSlot(string name, object value) {
//			__class__.SetSlotForInstance(this, name, value);
//		}
//
//		public void DelSlot(string name) {
//			__class__.DelSlotForInstance(this, name);
//		}
//
//		public DynamicType GetDynamicType() {
//			return __class__;
//		}
//
//		#endregion
//	}
//

	public class IntOps {
		public static ReflectedType MakeDynamicType() {
			OpsReflectedType ret = new OpsReflectedType("int", typeof(int), typeof(IntOps), typeof(ExtensibleInt));
			//ReflectedMethodGenerator.GenerateFunctions(ret);
			return ret;
		}

		public static int __cmp__(int self, object obj) {
			int oi = Ops.object2int(obj);
			return self == oi ? 0 : (self < oi ? -1 : +1);
		}

		public static object Make(string s, int radix) {
			return LiteralParser.ParseInteger( s, radix);
		}		

		public static object Make(object o) {
			if (o is string) return LiteralParser.ParseInteger( (string) o, 10);
			if (o is double) return (int) (double)o;

			return Ops.object2int(o);
		}
	
		public static object Abs(int x) {
			return Math.Abs(x);
		}

		private static object TrueDivide(int x, int y) {
			return x / (double)y;
		}

		public static int PowerMod(int x, int power, int mod) {
			if (power == 0) return 1;
			if (power < 0) throw new ArgumentOutOfRangeException("power", power, "power must be >= 0");
			long factor = x;
			long result = 1;

			while (power != 0) {
				if ( (power & 1) != 0) result = result*factor % mod;
				factor = factor*factor % mod; //???
				power >>= 1;
			}
			return (int)result;
		}

		public static object PowerMod(int x, object y, object z) {
			return PowerMod(x, (int)y, (int)z);
		}

		private static object Power(int x, int power) {
			if (power == 0) return 1;
			if (power < 0) throw new ArgumentOutOfRangeException("power", power, "power must be >= 0");
			int factor = x;
			int result = 1;
			int savePower = power;
			try {
				checked {
					while (power != 0) {  //??? this loop has redundant checks for exit condition
						if ( (power & 1) != 0) result = result*factor;
						if (power == 1) break; 
						factor = factor*factor;
						power >>= 1;
					}
					return result;
				}
			} catch (OverflowException) {
				return integer.make(x).pow(savePower);
			}
		}

		public static object Divide(int x, object other) {
			return FloorDivide(x, other);
		}

		public static object Equals(int x, object other) {
			if (other is int) return Ops.bool2object(x == (int)other);
			else if (other is long) return Ops.bool2object(x == (long)other);
			else if (other is double) return Ops.bool2object(x == (double)other);
			else if (other is integer) return Ops.bool2object((integer)x == (integer)other);
			else if (other is Complex64) return Ops.bool2object(x == (Complex64)other);

			return Ops.NotImplemented;
		}

		#region Generated IntOps
		
		public static object Add(int x, object other) {
		    if (other is int) {
		        int y = (int)other;
		        try {
		            return Ops.int2object(checked(x + y));
		        } catch (OverflowException) {
		            return (long)x + y; //integer.make(x) + y; //(long)x + y;
		        }
		    } else if (other is long) {
		        long y = (long)other;
		        try {
		            return checked(x + y);
		        } catch (OverflowException) {
		            return integer.make(x) + y;
		        }
		    } else if (other is integer) {
		        return integer.make(x) + (integer)other;
		    } else if (other is double) {
		        return x + (double)other;
		    } else if (other is Complex64) {
		        return Complex64.MakeReal(x) + (Complex64)other;
		    }
		    return Ops.NotImplemented;
		}
		
		
		public static object Subtract(int x, object other) {
		    if (other is int) {
		        int y = (int)other;
		        try {
		            return Ops.int2object(checked(x - y));
		        } catch (OverflowException) {
		            return integer.make(x) - y; //(long)x - y;
		        }
		    } else if (other is long) {
		        long y = (long)other;
		        try {
		            return checked(x - y);
		        } catch (OverflowException) {
		            return integer.make(x) - y;
		        }
		    } else if (other is integer) {
		        return integer.make(x) - (integer)other;
		    } else if (other is double) {
		        return x - (double)other;
		    } else if (other is Complex64) {
		        return Complex64.MakeReal(x) - (Complex64)other;
		    }
		    return Ops.NotImplemented;
		}
		
		
		public static object Power(int x, object other) {
		    if (other is int) {
		        return Power(x, (int)other);
		    }
		    return Ops.NotImplemented;
		}
		
		
		public static object Multiply(int x, object other) {
		    if (other is int) {
		        int y = (int)other;
		        try {
		            return Ops.int2object(checked(x * y));
		        } catch (OverflowException) {
		            return (long)x * y;
		        }
		    } else if (other is long) {
		        long y = (long)other;
				if (Options.MonoWorkaround) return x * integer.make(y);
				//Console.WriteLine("{0} * {1} ({2})", x, other, y);
		        try {
		            return checked(x * y);
		        } catch (OverflowException) {
					//Console.WriteLine("  {0} * {1} ({2})", x, other, y);
		            return integer.make(x) * y;
		        }
		    } else if (other is integer) {
		        return x * (integer)other; //integer.make(x) * (integer)other;
		    } else if (other is double) {
		        return x * (double)other;
		    } else if (other is Complex64) {
		        return Complex64.MakeReal(x) * (Complex64)other;
		    }
		    return Ops.NotImplemented;
		}
		
		
		public static object FloorDivide(int x, object other) {
		    if (other is int) {
		        int y = (int)other;
		        try {
		            return Ops.int2object(checked(x / y));
		        } catch (OverflowException) {
		            return integer.make(x) / y; //(long)x / y;
		        }
		    } else if (other is long) {
		        long y = (long)other;
		        try {
		            return checked(x / y);
		        } catch (OverflowException) {
		            return integer.make(x) / y;
		        }
		    } else if (other is integer) {
		        return integer.make(x) / (integer)other;
		    } else if (other is double) {
		        return x / (double)other;
		    } else if (other is Complex64) {
		        return Complex64.MakeReal(x) / (Complex64)other;
		    }
		    return Ops.NotImplemented;
		}
		
		
		public static object TrueDivide(int x, object other) {
		    if (other is int) {
		        return TrueDivide(x, (int)other);
		    }
		    return Ops.NotImplemented;
		}
		
		
		public static object Mod(int x, object other) {
		    if (other is int) {
		        int y = (int)other;
		        try {
		            return Ops.int2object(checked(x % y));
		        } catch (OverflowException) {
		            return integer.make(x) % y; //(long)x % y;
		        }
		    } else if (other is long) {
		        long y = (long)other;
		        try {
		            return checked(x % y);
		        } catch (OverflowException) {
		            return integer.make(x) % y;
		        }
		    } else if (other is integer) {
		        return integer.make(x) % (integer)other;
		    } else if (other is double) {
		        return x % (double)other;
		    } else if (other is Complex64) {
		        return Complex64.MakeReal(x) % (Complex64)other;
		    }
		    return Ops.NotImplemented;
		}
		
		
		public static object LeftShift(int x, object other) {
		    if (other is int) {
		        int y = (int)other;
		        try {
		            return Ops.int2object(checked(x << y));
		        } catch (OverflowException) {
		            return integer.make(x) << y;
		        }
		    }
		    return Ops.NotImplemented;
		}
		
		
		public static object RightShift(int x, object other) {
		    if (other is int) {
		        int y = (int)other;
		        try {
		            return Ops.int2object(checked(x >> y));
		        } catch (OverflowException) {
		            return integer.make(x) >> y;
		        }
		    }
		    return Ops.NotImplemented;
		}
		
		
		public static object BitwiseAnd(int x, object other) {
		    if (other is int) {
		        int y = (int)other;
		        try {
		            return Ops.int2object(checked(x & y));
		        } catch (OverflowException) {
		            return integer.make(x) & y;
		        }
		    } else if (other is long) {
		        long y = (long)other;
		        try {
		            return checked(x & y);
		        } catch (OverflowException) {
		            return integer.make(x) & y;
		        }
		    } else if (other is integer) {
		        return integer.make(x) & (integer)other;
		    }
		    return Ops.NotImplemented;
		}
		
		
		public static object BitwiseOr(int x, object other) {
		    if (other is int) {
		        int y = (int)other;
		        try {
		            return Ops.int2object(checked(x | y));
		        } catch (OverflowException) {
		            return integer.make(x) | y;
		        }
		    } else if (other is long) {
		        long y = (long)other;
		        try {
		            return checked(x | y);
		        } catch (OverflowException) {
		            return integer.make(x) | y;
		        }
		    } else if (other is integer) {
		        return integer.make(x) | (integer)other;
		    }
		    return Ops.NotImplemented;
		}
		
		
		public static object Xor(int x, object other) {
		    if (other is int) {
		        int y = (int)other;
		        try {
		            return Ops.int2object(checked(x ^ y));
		        } catch (OverflowException) {
		            return integer.make(x) ^ y;
		        }
		    } else if (other is long) {
		        long y = (long)other;
		        try {
		            return checked(x ^ y);
		        } catch (OverflowException) {
		            return integer.make(x) ^ y;
		        }
		    } else if (other is integer) {
		        return integer.make(x) ^ (integer)other;
		    }
		    return Ops.NotImplemented;
		}
		
		#endregion
	}
}
