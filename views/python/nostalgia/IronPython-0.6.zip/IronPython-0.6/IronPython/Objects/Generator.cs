/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;

namespace IronPython.Objects {
	[PythonType("generator")]
	public abstract class Generator:IEnumerator {
		public int location = Int32.MaxValue;
		private object current = null;

		public abstract bool InnerNext(out object ret);

		public object Current {
			get { return current; }
		}

		public bool MoveNext() {
//			try {
			return InnerNext(out current);
//			} catch (PythonStopIteration) {
//				return false;
//			}
		}

		public void Reset() {
			throw new NotImplementedException();
		}

		public object next() {
			object ret;
			if (!InnerNext(out ret)) throw Ops.StopIteration();
			return ret;
		}

		public override string ToString() {
			return string.Format("<generator object at {0}>", Ops.HexId(this));
		}

	}

	public class EnumIterator {
		private IEnumerator e;
		public EnumIterator(IEnumerator e) { this.e = e; }

		public object next() {
			if (!e.MoveNext()) throw Ops.StopIteration();
			return e.Current;
		}
	}
}
