/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Threading;
using System.Collections;
using System.Text;

using IronPython.Modules;
using IronPython.AST;

using IronMath;

namespace IronPython.Objects {
	/// <summary>
	/// Summary description for time.
	/// </summary>
	public class Ops {
		public static object NotImplemented = "<NotImplemented>"; //!!! need really singleton objects
		public static object Missing = "<<Missing>>";

		public static object Ellipsis = "..."; //!!!

		public static object[] MakeArray(object o1) { return new object[] { o1 }; }
		public static object[] MakeArray(object o1, object o2) { return new object[] { o1, o2 }; }


		public static List MakeList() { return List.MakeEmptyList(10); }

		public static List MakeList(params object[] items) {
			return new List(items);
		}

		public static Tuple MakeTuple(params object[] items) {
			return Tuple.MakeTuple(items);
		}
		public static object MakeSlice(object start, object stop, object step) {
			return new Slice(start, stop, step);
		}

		public static IronMath.integer MakeIntegerFromHex(string s) {
			return LiteralParser.ParseBigInteger(s, 16);
		}

		public static Dict MakeDict(int size) {
			return new Dict(size);
		}

		public static bool IsTrue(object o) {
			if (o == null) return false;
			if (o is bool) return (bool)o;
			if (o is int) return ((int)o) != 0;
			if (o is long) return ((long)o) != 0L;
			if (o is integer) return ((integer)o) != integer.ZERO;

			if (o is String) return ((string)o).Length != 0;

			if (o is ICollection) return ((ICollection)o).Count != 0;

			//Console.WriteLine("calling __nonzero__");

			object ret;
			if (TryToInvoke(o, "__nonzero__", out ret)) return IsTrue(ret);  //!!! this can recurse forever
			return true;
		}

//		public static IList GetList(object o) {
//			return (IList)o;
//		}

		public static string StringRepr(object o) {
			if (o == null) return "None";
			//!!! this is performance important
			string s = o as string;
			if (s != null) return StringOps.Quote(s);
			ICodeFormattable f = o as ICodeFormattable;
			if (f != null) return f.ToCodeString();

			Array a = o as Array;
			if (a != null) return ArrayOps.__repr__(a);

			if (o is long) return ((long)o).ToString() + "L";

			if (o is integer) return ((integer)o).ToString()+"L";


			return GetDynamicType(o).Repr(o);
		}

		public static string ToString(object o) {
			return o.ToString();
		}


		public static object Repr(object o) {
			return Ops.ToPython(StringRepr(o));
		}

		private static int MIN_CACHE = -100;
		private static int MAX_CACHE = 1000;
//		private static int MIN_CACHE = -200;
//		private static int MAX_CACHE = 10000;
//		private static int MIN_CACHE = -5;
//		private static int MAX_CACHE = 100;
		private static object[] cache = new object[MAX_CACHE-MIN_CACHE];


		public static object TRUE = true;
		public static object FALSE = false;


		private static string[] chars = new string[255];
		static Ops() {
			for (int i=0; i < (MAX_CACHE-MIN_CACHE); i++) {
				cache[i] =(object)(i+MIN_CACHE);
			}

			for (char ch = (char)0; ch < 255; ch++) {
				chars[ch] = new string(ch, 1);
			}
		}

		public static string char2string(char ch) {
			if (ch < 255) return chars[ch];
			return new string(ch, 1);
		}

		public static object bool2object(bool value) {
			return value ? TRUE : FALSE;
		}

		public static object int2object(int value) {
			// caches improves pystone by ~5-10% on MS .Net 1.1, this is a very integer intense app
			// cache appears to make a much larger improvement to performance on Mono-1.0 and will therefore be kept for now
			if (value < MAX_CACHE && value >= MIN_CACHE) {
				return cache[value-MIN_CACHE];
			}
			//Console.WriteLine("newint: " + value);
			return (object)value;
		}

		public static object long2object(long value) {
			return value;  // just use standard boxing conversion here
		}

		public static char object2char(object o) {
			if (o is string) {
				string s = (string)o;
				if (s.Length != 1) {
					throw Ops.TypeError("expected char, found string of length {0}", s.Length);
				}
				return s[0];
			} else if (o is char) {
				return (char)o;
			} else {
				throw Ops.TypeError("expected char, found {0}", Ops.GetDynamicType(o).__name__);
			}
		}

		public static short object2short(object value) {
			return (short)object2int(value); //!!!
		}


		public static int object2int(object value) {
			if (value is int) return (int)value;
			if (value is ExtensibleInt) return ((ExtensibleInt)value)._value;
			if (value is integer) return ((integer)value).ToInt32();
			if (value is long) {
				long l = (long)value;
				int ret = (int) l;
				if ((long)ret != l) throw Ops.ValueError("too big long for int");
				return ret;
			}
			if (value is bool) return ((bool)value) ? 1 : 0;
			throw Ops.TypeError("expected int, found {0}", Ops.GetDynamicType(value).__name__);
		}

		public static long object2long(object value) {
			if (value is long) return (long)value;
			return (long)object2int(value);
		}

		public static double object2double(object value) {
			if (value is int) return  (double) (int)value;
			if (value is ExtensibleInt) return (double) ((ExtensibleInt)value)._value;
			if (value is integer) return ((integer)value).ToFloat64();
			if (value is double) return ((double)value);
			if (value is long) return (double)((long)value);
			throw Ops.TypeError("expected double, found {0}", Ops.GetDynamicType(value).__name__);
		}

		public static integer object2integer(object value) {
			if (value is integer) return (integer)value;
			return integer.make(object2int(value));
		}

		public static Complex64 object2Complex64(object value) {
			if (value is Complex64) return (Complex64)value;
			return Complex64.MakeReal(object2double(value));
		}


		public static bool ConvertTo(object inObject, Type toType, out object outObject) {
			if (inObject == null) {
				outObject = null;
				return true;
			}
			try {
				if (toType == typeof(int)) {
					outObject = object2int(inObject);
					return true;
				} else if (toType == typeof(short)) {
					outObject = object2short(inObject);
					return true;
				} else if (toType == typeof(double)) {
					outObject = object2double(inObject);
					return true;
				} else if (toType == typeof(bool)) {
					outObject = IsTrue(inObject);
					return true;
				} else if (toType == typeof(integer)) {
					outObject = object2integer(inObject);
					return true;
				} else if (toType == typeof(Complex64)) {
					outObject = object2Complex64(inObject);
					return true;
				} else if (toType == typeof(char)) {
					outObject = object2char(inObject);
					return true;
				} else if (toType == typeof(IEnumerator)) {
					outObject = GetEnumerator(inObject);
					return true;
				} else if (typeof(Delegate).IsAssignableFrom(toType)) {
					outObject = GetDelegate(inObject, toType);
					return true;
				}
			} catch (PythonTypeError) { //!!! very inefficient handling of failed match
				outObject = null;
				return false;
			}
			outObject = inObject;

			Type inType = inObject.GetType();
			//if (inType == toType) return true;
			return toType.IsAssignableFrom(inType);
		}

		public static Delegate GetDelegate(object o, Type delegateType) {
			if (o is Delegate) return (Delegate)o;

			return Delegate.CreateDelegate(delegateType, new PythonEventHandler(o), "Handle");
		}

		public static object MakeString(string s) {
			return s;  //!!! this is key to str reprs
		}

		public static object ConvertTo(object o, Type toType) {
			object ret;
			if (ConvertTo(o, toType, out ret)) return ret;
			else throw new Exception("can't convert " + o + " to " + toType);
		}

		public static object ToPython(Type retType, object o) {
			if (o == null) return o;
			if (o.GetType().IsCOMObject) {
				return new TypedWrapper(o);
			} else {
				return ToPython(o);
			}
		}

		public static object ToPython(string s) {
			return s;
		}

		public static object ToPython(object o) {
			if (o is char) return char2string((char)o);
//			if (o is string) { return Str.make((string)o); }
//			else if (o is char) { return Str.make((char)o); }
			else return o;
		}

		public static object Plus(object o) {
			if (o is int) return o;
			else if (o is double) return o;
			else if (o is integer) return o;
			else if (o is Complex64) return o;

			else throw new NotImplementedException();
		}

		public static object Negate(object o) {
			if (o is int) return -(int)o;
			else if (o is double) return -(double)o;
			else if (o is long) return -(long)o;
			else if (o is integer) return -(integer)o;
			else if (o is Complex64) return -(Complex64)o;
			else throw new NotImplementedException();
		}

		public static object OnesComplement(object o) {
			if (o is int) return ~(int)o;
			else throw new NotImplementedException();
		}

		public static object Not(object o) {
			return IsTrue(o) ? FALSE : TRUE;
		}


		public static object Is(object x, object y) {
			return x == y;
		}

		public static object IsNot(object x, object y) {
			return x != y;
		}

		public static object In(object x, object y) {
			if (y is IDictionary) {
				return bool2object(((IDictionary)y).Contains(x));
			} else if (y is IList) {
				return bool2object( ((IList)y).Contains(x) );
			} else {
				IEnumerator e = GetEnumerator(y);
				while (e.MoveNext()) {
					if (Ops.IsTrue(Ops.Equal(e.Current, x))) return TRUE;
				}
				return FALSE;
			}
		}

		public static object NotIn(object x, object y) {
			return Not(In(x, y));  //???
		}

//		public static object GetDynamicType1(object o) {
//			IConvertible ic = o as IConvertible;
//			if (ic != null) {
//				switch (ic.GetTypeCode()) {
//					case TypeCode.Int32: return "int";
//					case TypeCode.Double: return "double";
//					default: throw new NotImplementedException();
//				}
//			} else {
//				throw new NotImplementedException();
//			}
//		}
//
//		private static object[] oas = new object[] { "int", "double" };
//
//		public static object GetDynamicType2(object o) {
//			Type ty = o.GetType();
//			int hc = ty.GetHashCode();
//
//			return oas[hc%1];
//		}

		private static Hashtable dynamicTypes = MakeDynamicTypesTable();
		
		private static ReflectedType StringType;
		private static Hashtable MakeDynamicTypesTable() {
			Hashtable ret = new Hashtable();
			StringType = new StringDynamicType();
			ret[typeof(string)] = StringType;
			ret[typeof(ExtensibleString)] = StringType;

			ret[typeof(int)] = IntOps.MakeDynamicType(); 
			ret[typeof(ExtensibleInt)] = ret[typeof(int)];

			ret[typeof(double)] = FloatOps.MakeDynamicType(); 
			//!!!ret[typeof(ExtensibleInt)] = ret[typeof(int)];
			
			ret[typeof(integer)] = LongOps.MakeDynamicType(); 
			//!!!ret[typeof(ExtensibleInt)] = ret[typeof(int)];

			ret[typeof(long)] = Int64Ops.MakeDynamicType((ReflectedType)ret[typeof(integer)]);
			
			ret[typeof(bool)] = BoolOps.MakeDynamicType((ReflectedType)ret[typeof(int)]);

			return ret;
		}

		public static void RegisterDynamicType(Type ty, DynamicType dt) {
			//!!! check that we're not replacing a previous entry
			dynamicTypes[ty] = dt;
		}

		public static DynamicType GetDynamicTypeFromType(Type ty) {
			DynamicType ret = (DynamicType)dynamicTypes[ty];
			if (ret != null) return ret;

			ret = ReflectedType.FromType(ty);
			dynamicTypes[ty] = ret;
			return ret;
		}

		public static DynamicType GetDynamicType(object o) {
			IDynamicObject dt = o as IDynamicObject;
			if (dt != null) return dt.GetDynamicType();

			if (o == null) return NoneType.Instance;

			if (o is String) return StringType;

			Type ty = o.GetType();
			//???ReflectedMethodBase.NoteCall(ty);
			//Console.WriteLine("Getting DynamicType: " + ty);
			return GetDynamicTypeFromType(ty);
		}


		#region Generated Binary Ops
		
		public static object Add(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.Add((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is double) {
		            ret = FloatOps.Add((double)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.Complex64) {
		            ret = ComplexOps.Add((IronMath.Complex64)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.Add((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is long) {
		            ret = Int64Ops.Add((long)x, y);
		            if (ret != NotImplemented) return ret;
		    }
			string sx = x as String;
			if (sx != null) {
				string sy = y as String;
				if (sy != null) {
					return sx + sy;
				}
			}
		    
    ISequence seq = x as ISequence;
    if (seq != null) { return seq.__add__(y); }

		
		    ret = GetDynamicType(x).Add(x, y);
		    if (ret != NotImplemented) return ret;
		    ret = GetDynamicType(y).ReverseAdd(y, x);
		    if (ret != NotImplemented) return ret;
		    throw Ops.TypeError("unsupported operand type(s) for +: '{0}' and '{1}'",
		                        GetDynamicType(x).__name__, GetDynamicType(y).__name__);
		}
		
		public static object InPlaceAdd(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.Add((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is double) {
		            ret = FloatOps.Add((double)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is long) {
		            ret = Int64Ops.Add((long)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.Add((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    }

			if (x is string && y is string) {
				return ((string)x) + ((string)y);
			}

			if (x is ReflectedEvent) {
				return ((ReflectedEvent)x).__iadd__(y);
			}
		    throw new NotImplementedException("InPlaceAdd");
		}
		
		
		public static object Subtract(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.Subtract((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is double) {
		            ret = FloatOps.Subtract((double)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.Complex64) {
		            ret = ComplexOps.Subtract((IronMath.Complex64)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.Subtract((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is long) {
		            ret = Int64Ops.Subtract((long)x, y);
		            if (ret != NotImplemented) return ret;
		    }
		
		    
		
		    ret = GetDynamicType(x).Subtract(x, y);
		    if (ret != NotImplemented) return ret;
		    ret = GetDynamicType(y).ReverseSubtract(y, x);
		    if (ret != NotImplemented) return ret;
		    throw Ops.TypeError("unsupported operand type(s) for -: '{0}' and '{1}'",
		                        GetDynamicType(x).__name__, GetDynamicType(y).__name__);
		}
		
		public static object InPlaceSubtract(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.Subtract((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is double) {
		            ret = FloatOps.Subtract((double)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is long) {
		            ret = Int64Ops.Subtract((long)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.Subtract((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    }
		    throw new NotImplementedException("InPlaceSubtract");
		}
		
		
		public static object Power(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.Power((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is double) {
		            ret = FloatOps.Power((double)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.Complex64) {
		            ret = ComplexOps.Power((IronMath.Complex64)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.Power((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is long) {
		            ret = Int64Ops.Power((long)x, y);
		            if (ret != NotImplemented) return ret;
		    }
		
		    
		
		    ret = GetDynamicType(x).Power(x, y);
		    if (ret != NotImplemented) return ret;
		    ret = GetDynamicType(y).ReversePower(y, x);
		    if (ret != NotImplemented) return ret;
		    throw Ops.TypeError("unsupported operand type(s) for **: '{0}' and '{1}'",
		                        GetDynamicType(x).__name__, GetDynamicType(y).__name__);
		}
		
		public static object InPlacePower(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.Power((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is double) {
		            ret = FloatOps.Power((double)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is long) {
		            ret = Int64Ops.Power((long)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.Power((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    }
		    throw new NotImplementedException("InPlacePower");
		}
		
		
		public static object Multiply(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.Multiply((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is double) {
		            ret = FloatOps.Multiply((double)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.Complex64) {
		            ret = ComplexOps.Multiply((IronMath.Complex64)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.Multiply((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is long) {
		            ret = Int64Ops.Multiply((long)x, y);
		            if (ret != NotImplemented) return ret;
		    }
		
		    
    ISequence seq = x as ISequence;
    if (seq != null && y is int) { return seq.__mul__((int)y); }

		
		    ret = GetDynamicType(x).Multiply(x, y);
		    if (ret != NotImplemented) return ret;
		    ret = GetDynamicType(y).ReverseMultiply(y, x);
		    if (ret != NotImplemented) return ret;
		    throw Ops.TypeError("unsupported operand type(s) for *: '{0}' and '{1}'",
		                        GetDynamicType(x).__name__, GetDynamicType(y).__name__);
		}
		
		public static object InPlaceMultiply(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.Multiply((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is double) {
		            ret = FloatOps.Multiply((double)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is long) {
		            ret = Int64Ops.Multiply((long)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.Multiply((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    }
		    throw new NotImplementedException("InPlaceMultiply");
		}
		
		
		public static object FloorDivide(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.FloorDivide((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is double) {
		            ret = FloatOps.FloorDivide((double)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.Complex64) {
		            ret = ComplexOps.FloorDivide((IronMath.Complex64)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.FloorDivide((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is long) {
		            ret = Int64Ops.FloorDivide((long)x, y);
		            if (ret != NotImplemented) return ret;
		    }
		
		    
		
		    ret = GetDynamicType(x).FloorDivide(x, y);
		    if (ret != NotImplemented) return ret;
		    ret = GetDynamicType(y).ReverseFloorDivide(y, x);
		    if (ret != NotImplemented) return ret;
		    throw Ops.TypeError("unsupported operand type(s) for //: '{0}' and '{1}'",
		                        GetDynamicType(x).__name__, GetDynamicType(y).__name__);
		}
		
		public static object InPlaceFloorDivide(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.FloorDivide((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is double) {
		            ret = FloatOps.FloorDivide((double)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is long) {
		            ret = Int64Ops.FloorDivide((long)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.FloorDivide((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    }
		    throw new NotImplementedException("InPlaceFloorDivide");
		}
		
		
		public static object Divide(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.Divide((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is double) {
		            ret = FloatOps.Divide((double)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.Complex64) {
		            ret = ComplexOps.Divide((IronMath.Complex64)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.Divide((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is long) {
		            ret = Int64Ops.Divide((long)x, y);
		            if (ret != NotImplemented) return ret;
		    }
		
		    
		
		    ret = GetDynamicType(x).Divide(x, y);
		    if (ret != NotImplemented) return ret;
		    ret = GetDynamicType(y).ReverseDivide(y, x);
		    if (ret != NotImplemented) return ret;
		    throw Ops.TypeError("unsupported operand type(s) for /: '{0}' and '{1}'",
		                        GetDynamicType(x).__name__, GetDynamicType(y).__name__);
		}
		
		public static object InPlaceDivide(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.Divide((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is double) {
		            ret = FloatOps.Divide((double)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is long) {
		            ret = Int64Ops.Divide((long)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.Divide((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    }
		    throw new NotImplementedException("InPlaceDivide");
		}
		
		
		public static object Mod(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.Mod((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is double) {
		            ret = FloatOps.Mod((double)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.Complex64) {
		            ret = ComplexOps.Mod((IronMath.Complex64)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.Mod((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is long) {
		            ret = Int64Ops.Mod((long)x, y);
		            if (ret != NotImplemented) return ret;
		    }
		
		    
		
		    ret = GetDynamicType(x).Mod(x, y);
		    if (ret != NotImplemented) return ret;
		    ret = GetDynamicType(y).ReverseMod(y, x);
		    if (ret != NotImplemented) return ret;
		    throw Ops.TypeError("unsupported operand type(s) for %: '{0}' and '{1}'",
		                        GetDynamicType(x).__name__, GetDynamicType(y).__name__);
		}
		
		public static object InPlaceMod(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.Mod((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is double) {
		            ret = FloatOps.Mod((double)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is long) {
		            ret = Int64Ops.Mod((long)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.Mod((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    }
		    throw new NotImplementedException("InPlaceMod");
		}
		
		
		public static object LeftShift(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.LeftShift((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.LeftShift((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is long) {
		            ret = Int64Ops.LeftShift((long)x, y);
		            if (ret != NotImplemented) return ret;
		    }
		    ret = GetDynamicType(x).LeftShift(x, y);
		    if (ret != NotImplemented) return ret;
		    ret = GetDynamicType(y).ReverseLeftShift(y, x);
		    if (ret != NotImplemented) return ret;
		    
		    throw Ops.TypeError("unsupported operand type(s) for <<: '{0}' and '{1}'",
		                        GetDynamicType(x).__name__, GetDynamicType(y).__name__);
		}
		
		public static object InPlaceLeftShift(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.LeftShift((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.LeftShift((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    }
		    throw new NotImplementedException("InPlaceLeftShift");
		}
		
		
		public static object RightShift(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.RightShift((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.RightShift((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is long) {
		            ret = Int64Ops.RightShift((long)x, y);
		            if (ret != NotImplemented) return ret;
		    }
		    ret = GetDynamicType(x).RightShift(x, y);
		    if (ret != NotImplemented) return ret;
		    ret = GetDynamicType(y).ReverseRightShift(y, x);
		    if (ret != NotImplemented) return ret;
		    
		    throw Ops.TypeError("unsupported operand type(s) for >>: '{0}' and '{1}'",
		                        GetDynamicType(x).__name__, GetDynamicType(y).__name__);
		}
		
		public static object InPlaceRightShift(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.RightShift((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.RightShift((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    }
		    throw new NotImplementedException("InPlaceRightShift");
		}
		
		
		public static object BitwiseAnd(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.BitwiseAnd((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.BitwiseAnd((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is long) {
		            ret = Int64Ops.BitwiseAnd((long)x, y);
		            if (ret != NotImplemented) return ret;
		    }
		    ret = GetDynamicType(x).BitwiseAnd(x, y);
		    if (ret != NotImplemented) return ret;
		    ret = GetDynamicType(y).ReverseBitwiseAnd(y, x);
		    if (ret != NotImplemented) return ret;
		    
		    throw Ops.TypeError("unsupported operand type(s) for &: '{0}' and '{1}'",
		                        GetDynamicType(x).__name__, GetDynamicType(y).__name__);
		}
		
		public static object InPlaceBitwiseAnd(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.BitwiseAnd((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.BitwiseAnd((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    }
		    throw new NotImplementedException("InPlaceBitwiseAnd");
		}
		
		
		public static object BitwiseOr(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.BitwiseOr((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.BitwiseOr((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is long) {
		            ret = Int64Ops.BitwiseOr((long)x, y);
		            if (ret != NotImplemented) return ret;
		    }
		    ret = GetDynamicType(x).BitwiseOr(x, y);
		    if (ret != NotImplemented) return ret;
		    ret = GetDynamicType(y).ReverseBitwiseOr(y, x);
		    if (ret != NotImplemented) return ret;
		    
		    throw Ops.TypeError("unsupported operand type(s) for |: '{0}' and '{1}'",
		                        GetDynamicType(x).__name__, GetDynamicType(y).__name__);
		}
		
		public static object InPlaceBitwiseOr(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.BitwiseOr((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.BitwiseOr((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    }
		    throw new NotImplementedException("InPlaceBitwiseOr");
		}
		
		
		public static object Xor(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.Xor((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.Xor((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is long) {
		            ret = Int64Ops.Xor((long)x, y);
		            if (ret != NotImplemented) return ret;
		    }
		    ret = GetDynamicType(x).Xor(x, y);
		    if (ret != NotImplemented) return ret;
		    ret = GetDynamicType(y).ReverseXor(y, x);
		    if (ret != NotImplemented) return ret;
		    
		    throw Ops.TypeError("unsupported operand type(s) for ^: '{0}' and '{1}'",
		                        GetDynamicType(x).__name__, GetDynamicType(y).__name__);
		}
		
		public static object InPlaceXor(object x, object y) {
		    object ret;
		    if (x is int) {
		            ret = IntOps.Xor((int)x, y);
		            if (ret != NotImplemented) return ret;
		    } else if (x is IronMath.integer) {
		            ret = LongOps.Xor((IronMath.integer)x, y);
		            if (ret != NotImplemented) return ret;
		    }
		    throw new NotImplementedException("InPlaceXor");
		}
		
		
		public static object LessThan(object x, object y) {
		    if (x is int) {
		        if (y is int) {
		            return bool2object(((int)x)<((int)y));
		        } else if (y is double) {
		            return ((int)x)<((double)y);
		        }
		    } else if (x is double) {
		        if (y is int) {
		            return ((double)x)<((int)y);
		        } else if (y is double) {
		            return ((double)x)<((double)y);
		        }
		    }
		
		    return bool2object(Compare(x, y) < 0);
		}
		
		public static object GreaterThan(object x, object y) {
		    if (x is int) {
		        if (y is int) {
		            return bool2object(((int)x)>((int)y));
		        } else if (y is double) {
		            return ((int)x)>((double)y);
		        }
		    } else if (x is double) {
		        if (y is int) {
		            return ((double)x)>((int)y);
		        } else if (y is double) {
		            return ((double)x)>((double)y);
		        }
		    }
		
		    return bool2object(Compare(x, y) > 0);
		}
		
		public static object LessThanOrEqual(object x, object y) {
		    if (x is int) {
		        if (y is int) {
		            return bool2object(((int)x)<=((int)y));
		        } else if (y is double) {
		            return ((int)x)<=((double)y);
		        }
		    } else if (x is double) {
		        if (y is int) {
		            return ((double)x)<=((int)y);
		        } else if (y is double) {
		            return ((double)x)<=((double)y);
		        }
		    }
		
		    return bool2object(Compare(x, y) <= 0);
		}
		
		public static object GreaterThanOrEqual(object x, object y) {
		    if (x is int) {
		        if (y is int) {
		            return bool2object(((int)x)>=((int)y));
		        } else if (y is double) {
		            return ((int)x)>=((double)y);
		        }
		    } else if (x is double) {
		        if (y is int) {
		            return ((double)x)>=((int)y);
		        } else if (y is double) {
		            return ((double)x)>=((double)y);
		        }
		    }
		
		    return bool2object(Compare(x, y) >= 0);
		}
		#endregion
		
		public static object Equal(object x, object y) {
			if (x == y) return TRUE;
			//!!!if (x is Str) return bool2object(x.Equals(y)); //???

			if (x is int) { return IntOps.Equals((int)x, y); }
			else if (x is double) { return FloatOps.Equals((double)x, y); }
			else if (x is long) { return Int64Ops.Equals((long)x, y); }
			else if (x is integer) { return LongOps.Equals((integer)x, y); }
			else if (x is Complex64) { return ComplexOps.Equals((Complex64)x, y); }

			return bool2object(x.Equals(y));

//		    if (x is int) {
//		        if (y is int) {
//		            return ((int)x)==((int)y);
//		        } else if (y is double) {
//		            return ((int)x)==((double)y);
//		        }
//		    } else if (x is double) {
//		        if (y is int) {
//		            return ((double)x)==((int)y);
//		        } else if (y is double) {
//		            return ((double)x)==((double)y);
//		        }
//		    }
//		    throw new NotImplementedException("Equal");
		}
		
		public static object NotEqual(object x, object y) {
			return Ops.Not(Equal(x, y));
			//???return bool2object(!x.Equals(y));
//		    if (x is int) {
//		        if (y is int) {
//		            return ((int)x)!=((int)y);
//		        } else if (y is double) {
//		            return ((int)x)!=((double)y);
//		        }
//		    } else if (x is double) {
//		        if (y is int) {
//		            return ((double)x)!=((int)y);
//		        } else if (y is double) {
//		            return ((double)x)!=((double)y);
//		        }
//		    }
//		
//		    throw new NotImplementedException("NotEqual");
		}


		public static int Compare(object x, object y) {
			if (x == y) return 0;
			//!!! This is going to be fun

			if (x is string && y is string) {
				return string.CompareOrdinal((string)x, (string)y); //??? is this the Python rule
			}


			IComparable c = x as IComparable;
			if (c != null) {
				try {
					return c.CompareTo(y);
				} catch (ArgumentException) {
					throw Ops.TypeError("can't compare {0} to {1} (IComparable)", Ops.StringRepr(x), Ops.StringRepr(y) );
				}
			}
			throw Ops.TypeError("can't compare {0} to {1}", Ops.StringRepr(x), Ops.StringRepr(y) );
		}

		public static int CompareArrays(object[] data0, int size0, object[] data1, int size1) {
			int size = Math.Min(size0, size1);
			for (int i=0; i < size; i++) {
				int c = Ops.Compare(data0[i], data1[i]);
				if (c != 0) return c;
			}
			if (size0 == size1) return 0;
			return size0 > size1 ? +1 : -1;
		}


		public static object PowerMod(object x, object y, object z) {
			object ret;
			if (x is int) {
				ret = IntOps.PowerMod((int)x, y, z);
				if (ret != NotImplemented) return ret;
//			} else if (x is double) {
//				ret = FloatOps.PowerMod((double)x, y, z);
//				if (ret != NotImplemented) return ret;
//			} else if (x is IronMath.Complex64) {
//				ret = ComplexOps.PowerMod((IronMath.Complex64)x, y, z);
//				if (ret != NotImplemented) return ret;
//			} else if (x is IronMath.integer) {
//				ret = LongOps.PowerMod((IronMath.integer)x, y, z);
//				if (ret != NotImplemented) return ret;
			}
		
//			ret = GetDynamicType(x).Power(x, y);
//			if (ret != NotImplemented) return ret;
//			ret = GetDynamicType(y).ReversePower(y, x);
//			if (ret != NotImplemented) return ret;
			throw Ops.TypeError("unsupported operand type(s) for power with modulus: '{0}' and '{1}'",
				GetDynamicType(x).__name__, GetDynamicType(y).__name__);
		}

		public static IEnumerator GetEnumerator(object o) {
			if (o is string) return StringOps.GetEnumerator((string)o);
			else if (o is IEnumerator) return (IEnumerator)o;
			else if (o is IEnumerable) return ((IEnumerable)o).GetEnumerator();

			return new PythonEnumerator(Ops.Invoke(o, "__iter__"));
//			object ret;
//			if (Ops.TryToInvoke(o, "__iter__", out ret)) throw new NotImplementedException(); //return ret;
//
//			else throw Ops.TypeError("{0} is not enumerable", StringRepr(o));
		}

		public static int Id(object o) {
			return SystemUtils.IdentityHashCode(o);
		}


		public static string HexId(object o) {
			return string.Format("0x{0:X8}", Id(o));
		}

		public static int Hash(object o) {
			if (o is int) return (int)o;
			if (o is double) return (int)(double)o; //??? fuzzy

			return o.GetHashCode();
		}

		public static object Hex(object o) {
			if (o is int) return "0x" + ((int)o).ToString("x");
			else if (o is long) return "0x" + ((long)o).ToString("x") + "L";
			else if (o is integer) return "0x" + ((integer)o).ToString(16) + "L";

			return Invoke(o, "__hex__");
		}
		public static object Oct(object o) {
			if (o is int) return "0" + integer.make((int)o).ToString(8);  //!!! horribly inefficient
			if (o is long) return "0" + integer.make((long)o).ToString(8) + "L";  //!!! horribly inefficient
			else if (o is integer) return "0" + ((integer)o).ToString(8) + "L";

			return Invoke(o, "__oct__");
		}


		private static object[] EMPTY = new object[0];
		#region Generated Call Ops
		public const int MAX_CALL_ARGS = 4;
		
		public static object Call(object func) {
		    Function f = func as Function;
		    if (f != null) return f.Call();
		
		    IFastCallable ifc = func as IFastCallable;
		    if (ifc != null) return ifc.Call();
		
		    ICallable ic = func as ICallable;
		    if (ic != null) return ic.Call(EMPTY);
		
		    return Ops.Call(func, EMPTY);
		}
		
		public static object Call(object func, object arg0) {
//			Function1 f1 = func as Function1;
//			if (f1 != null) return f1.target(arg0);
//
//			Method m = func as Method;
//			if (m != null) {
//				Function2 t2 = m.func as Function2;
//				if (t2 != null) return t2.target(m.inst, arg0);
//
//				BuiltinFunction bf = m.func as BuiltinFunction;
//				if (bf != null) return bf.target2(m.inst, arg0);
//				//!!! else
//			}


		    Function f = func as Function;
		    if (f != null) return f.Call(arg0);
		
		    IFastCallable ifc = func as IFastCallable;
		    if (ifc != null) return ifc.Call(arg0);
		
		    ICallable ic = func as ICallable;
		    if (ic != null) return ic.Call(new object[] { arg0 });
		
		    return Ops.Call(func, new object[] { arg0 });
		}
		
		public static object Call(object func, object arg0, object arg1) {
		    Function f = func as Function;
		    if (f != null) return f.Call(arg0, arg1);
		
		    IFastCallable ifc = func as IFastCallable;
		    if (ifc != null) return ifc.Call(arg0, arg1);
		
		    ICallable ic = func as ICallable;
		    if (ic != null) return ic.Call(new object[] { arg0, arg1 });
		
		    return Ops.Call(func, new object[] { arg0, arg1 });
		}
		
		public static object Call(object func, object arg0, object arg1, object arg2) {
		    Function f = func as Function;
		    if (f != null) return f.Call(arg0, arg1, arg2);
		
		    IFastCallable ifc = func as IFastCallable;
		    if (ifc != null) return ifc.Call(arg0, arg1, arg2);
		
		    ICallable ic = func as ICallable;
		    if (ic != null) return ic.Call(new object[] { arg0, arg1, arg2 });
		
		    return Ops.Call(func, new object[] { arg0, arg1, arg2 });
		}
		
		public static object Call(object func, object arg0, object arg1, object arg2, object arg3) {
		    Function f = func as Function;
		    if (f != null) return f.Call(arg0, arg1, arg2, arg3);
		
		    IFastCallable ifc = func as IFastCallable;
		    if (ifc != null) return ifc.Call(arg0, arg1, arg2, arg3);
		
		    ICallable ic = func as ICallable;
		    if (ic != null) return ic.Call(new object[] { arg0, arg1, arg2, arg3 });
		
		    return Ops.Call(func, new object[] { arg0, arg1, arg2, arg3 });
		}
		#endregion

		public static object Call(object func, params object[] args) {
			ICallable ic = func as ICallable;
			if (ic != null) return ic.Call(args);

			return Invoke(func, "__call__", args);
		}

		public static object Call(object func, object[] args, string[] names) {
			IFancyCallable ic = func as IFancyCallable;
			if (ic != null) return ic.Call(args, names);

			throw new Exception("this object is not callable with keyword parameters");
		}

		public static object CallWithArgsTuple(object func, object[] args, object argsTuple) {
			Tuple tp = argsTuple as Tuple;
			if (tp != null) {
				object[] nargs = new object[args.Length+tp.Count];
				for (int i=0; i < args.Length; i++) nargs[i] = args[i];
				for (int i=0; i < tp.Count; i++) nargs[i+args.Length] = tp[i];
				return Call(func, nargs);
			}

			List allArgs = List.MakeEmptyList(args.Length + 10);
			IEnumerator e = Ops.GetEnumerator(argsTuple);
			while (e.MoveNext()) allArgs.append(e.Current);

			return Call(func, allArgs.GetObjectArray());
		}

//		public static object GetSlice(object o, object start, object stop) {
//			//Console.Out.WriteLine("slice: " + o + ", " + o.GetType());
//			if (o is ISequence) {
//				int starti, stopi;
//				if (start == null) starti = 0;
//				else starti = object2int(start);
//				if (stop == null) stopi = int.MaxValue;
//				else stopi = object2int(stop);
//
//				return ((ISequence)o).GetSlice(starti, stopi);
//			} else if (o is string) {
//				int starti, stopi;
//				if (start == null) starti = 0;
//				else starti = (int)start;
//				if (stop == null) stopi = int.MaxValue;
//				else stopi = (int)stop;
//
//				return StringOps.GetSlice((string)o, starti, stopi);
//			}
//			
//			return Invoke(o, "__getslice__", start, stop);
//		}

		public static object GetIndex(object o, object index) {
			ISequence seq = o as ISequence;
			if (seq != null) {
				if (index is int) return seq.__getitem__((int)index);
				else if (index is Slice) return seq.__getitem__((Slice)index);
				//???
			}

			IMapping map = o as IMapping;
			if (map != null) {
				return map.__getitem__(index);
			}

			string s = o as string;
			if (s != null) {
				if (index is int) return StringOps.__getitem__(s, (int)index);
				else if (index is Slice) return StringOps.__getitem__(s, (Slice)index);
				//???
			}

			return GetDynamicType(o).__getitem__(o, index);
		}

		public static void SetIndex(object o, object index, object value) {
			IMutableSequence seq = o as IMutableSequence;
			if (seq != null) {
				if (index is int) { seq.__setitem__((int)index, value); return; }
				else if (index is Slice) { seq.__setitem__((Slice)index, value); return; }
				//???
			}

			IMapping map = o as IMapping;
			if (map != null) {
				map.__setitem__(index, value);
				return;
			}

			GetDynamicType(o).__setitem__(o, index, value);
		}

		public static void SetIndexStackHelper(object value, object o, object index) {
			SetIndex(o, index, value);
		}

		public static void DelIndex(object o, object index) {
			IMutableSequence seq = o as IMutableSequence;
			if (seq != null) {
				if (index is int) { seq.__delitem__((int)index); return; }
				else if (index is Slice) { seq.__delitem__((Slice)index); return; }
				//???
			}

			IMapping map = o as IMapping;
			if (map != null) {
				map.__delitem__(index);
				return;
			}

			GetDynamicType(o).__delitem__(o, index);
		}

		public static bool GetAttr(object o, string name, out object ret) {
			try {
				ICustomAttributes ids = o as ICustomAttributes;
				if (ids != null) {
					ret = ids.__getattribute__(name);
					return ret != Ops.Missing;
				}

				return GetDynamicType(o).GetAttr(o, name, out ret);
			} catch (PythonAttributeError) {
				ret = null;
				return false;
			}
		}

		public static object GetAttr(object o, string name) {
			ICustomAttributes ids = o as ICustomAttributes;
			if (ids != null) {
				object ret = ids.__getattribute__(name);
				if (ret != Ops.Missing) {
					//if (ret == null) Console.WriteLine("got null: " + name);
					return ret;
				}
				if (o is DynamicType) {
					throw Ops.AttributeError("type object '{0}' has no attribute '{1}'",
						((DynamicType)o).__name__, name);
				} else {
					throw Ops.AttributeError("'{0}' object has no attribute '{1}'", GetDynamicType(o).__name__, name);
			
				}
			}

			return GetDynamicType(o).GetAttr(o, name);
		}

		public static void SetAttr(object o, string name, object value) {
			ICustomAttributes ids = o as ICustomAttributes;
			
			if (ids != null) {
				ids.__setattr__(name, value);
				return;
			}

			GetDynamicType(o).SetAttr(o, name, value);
		}

		public static void SetAttrStackHelper(object value, object o, string name) {
			SetAttr(o, name, value);
		}

		public static void DelAttr(object o, string name) {
			ICustomAttributes ids = o as ICustomAttributes;
			
			if (ids != null) {
				ids.__delattr__(name);
				return;
			}

			GetDynamicType(o).DelAttr(o, name);
		}

		public static List GetAttrNames(object o) {
			ICustomAttributes ids = o as ICustomAttributes;
			
			if (ids != null) {
				return ids.__attrs__();
			}

			return GetDynamicType(o).GetAttrNames(o);
		}
			

		public static void CheckInitialized(object o) {
			if (o is Uninitialized) throw Ops.NameError("name '{0}' not defined", ((Uninitialized)o).name);
		}


		public static object GetDescriptor(object o, object instance, object context) {
			Function f = o as Function;
			if (f != null) return f.__get__(instance, context);

			IDescriptor id = o as IDescriptor;
			if (id != null) return id.__get__(instance, context);

			if (!(o is ISuperDynamicObject)) return o;   //???

			//!!! This is much more expensive 'all the time' than I'd like
			object ret;
			if (TryToInvoke(o, "__get__", out ret, instance, context)) return ret;

			return o;
		}

		public static bool SetDescriptor(object o, object instance, object value) {
			IDataDescriptor id = o as IDataDescriptor;
			if (id != null) {
				id.__set__(instance, value);
				return true;
			}

			//!!! need to add generic __set__

			return false;
		}

		public static bool DelDescriptor(object o, object instance) {
			IDataDescriptor id = o as IDataDescriptor;
			if (id != null) {
				id.__delete__(instance);
				return true;
			}

			//!!! add generic __delete__

			return false;
		}

		public static object Invoke(object target, string name, params object[] args) {
			object meth = GetAttr(target, name);
			return Call(meth, args);
		}

		public static bool TryToInvoke(object target, string name, out object ret, params object[] args) {
			object meth;
			if (GetAttr(target, name, out meth)) {
				ret = Call(meth, args);
				return true;
			} else {
				ret = null;
				return false;
			}
		}

		private static void Write(object f, string text) {
			Ops.Invoke(f, "write", text);
		}

		private static void WriteSoftspace(object f) {
			if (CheckSoftspace(f)) {
				SetSoftspace(f, FALSE);
				Write(f, " ");
			}
		}

		private static void SetSoftspace(object f, object value) {
			Ops.SetAttr(f, "softspace", value);
		}

		private static bool CheckSoftspace(object f) {
			return Ops.IsTrue(Ops.GetAttr(f, "softspace"));
		}


		public static void PrintNewline() {
			PrintNewlineWithDest(sys.stdout);
		}

		public static void PrintNewlineWithDest(object dest) {
			Write(dest, "\n");
			SetSoftspace(dest, FALSE);
		}

		public static void Print(object o) {
			PrintWithDest(sys.stdout, o);
		}

		public static void PrintComma(object o) {
			PrintCommaWithDest(sys.stdout, o);
		}

		public static void PrintWithDest(object dest, object o) {
			WriteSoftspace(dest);
			Write(dest,  o == null ? "None" : o.ToString());
			Write(dest, "\n");
		}


		public static void PrintCommaWithDest(object dest, object o) {
			WriteSoftspace(dest);
			string s = o == null ? "None" : o.ToString();

			Write(dest, s);
			SetSoftspace(dest, !s.EndsWith("\n"));
		}


		public static void PrintNotNoneRepr(object o) {
			if (o != null) Print(Ops.StringRepr(o));
		}

		// import spam.eggs
		public static void Import(module mod, string fullName) {
			mod.__setattr__(fullName, mod.Import(fullName, true));
		}

		// import spam as ham
		public static void ImportAs(module mod, string fullName, string asName) {
			mod.__setattr__(asName, mod.Import(fullName, true));
		}

		// from spam import eggs1, eggs2
		public static void ImportFrom(module mod, string fullName, string[] names) {
			ImportFromAs(mod, fullName, names, names);
		}


		// from spam import eggs1 as ham1, eggs2 as ham2
		public static void ImportFromAs(module mod, string fullName, string[] names, string[] asNames) {
			object fromObj = mod.Import(fullName, false);

			for (int i=0; i < names.Length; i++) {
				object impObj = Importer.ImportFrom(fromObj, names[i]);

				//				if (item == null) {
				//					throw Py.ImportError("no such name {0} in {1}", names[i], mod);
				//				}

				string asName;
				if (asNames[i] == null) asName = names[i];
				else asName = asNames[i];

				SetAttr(mod, asName, impObj);
			}
		}

		// from spam import *
		public static void ImportStar(module mod, string fullName) {
			object fromObj = mod.Import(fullName, false);
			
			foreach (string name in Ops.GetAttrNames(fromObj)) {
				mod.__setattr__(name, GetAttr(fromObj, name));
			}
		}

		private static object FindMetaclass(Tuple bases, IDictionary dict) {
			// If dict['__metaclass__'] exists, it is used. 
			object metaclass = dict["__metaclass__"];
			if (metaclass != null) return metaclass;

			//Otherwise, if there is at least one base class, its metaclass is used
			if (bases.Count > 0) {
				//!!! add rule that we will choose non-classic classes before classic ones
				return Ops.GetDynamicType(bases[0]);
			}

			//Otherwise, if there's a global variable named __metaclass__, it is used.
			//!!!if (module.__getattr__(Names.__metaclass__, out metaclass)) return metaclass;

			//Otherwise, the classic metaclass (types.ClassType) is used.
			return GetDynamicTypeFromType(typeof(OldClass));
		}

		public static object MakeClass(string mod, string name, Tuple bases, IDictionary vars) {
			object metaclass = FindMetaclass(bases, vars);
			if (metaclass == GetDynamicTypeFromType(typeof(OldClass))) {
				return new OldClass(mod, name, bases, vars);
			} else if (metaclass == GetDynamicTypeFromType(typeof(ReflectedType)) || metaclass == GetDynamicTypeFromType(typeof(UserType))) {
				return UserType.MakeClass(mod, name, bases, vars);
			} else if (metaclass is UserType) {
                object ret = ((UserType)metaclass).init.Call(name, bases, vars);
				if (ret is ISuperDynamicObject) {
					((ISuperDynamicObject)ret).SetDynamicType((UserType)metaclass);
				}
				return ret;
			} else {
				throw new NotImplementedException();
//				object[] newArgs = new object[args.Length-1];
//				Array.Copy(args, 1, newArgs, 0, newArgs.Length);
//				object ret = targetType.init.Call(newArgs);
//
//				return ret;
//				//return Ops.Call(metaclass, metaclass, name, bases, vars);
//				return Ops.Invoke(metaclass, "__new__", metaclass, name, bases, vars);
			}
		}


		public static void Exec(object code, module mod) {
			Exec(code, mod.__dict__);
		}

		public static void Exec(object code, object globals) {
			Exec(code, globals, globals);
		}

		public static void Exec(object code, object locals, object globals) {
			if (code is String) {
				Parser p =Parser.fromString((string)code);
				Stmt s = p.parseStmt();
				code = SnippetMaker.generate(s, "<exec>");
			}
			FrameCode fc = (FrameCode)code;
			Frame frame = new Frame(null, (IDictionary)globals, (IDictionary)locals);
			fc.Run(frame);
		}

		public static void Raise() {
			throw (Exception)sys.exc_value; //??? could it be this easy
			//throw new NotImplementedException("re-raise");
		}

		public static void Raise(object type, object value, object traceback) {
			//!!! ignoring way too much
			if (type is Exception) throw (Exception)type;
			ReflectedType rt = type as ReflectedType;
			if (rt != null) {
				if (value == null) {
					throw (Exception)rt.Call();
				} else {
					throw (Exception)rt.Call(value);
				}
			}


			throw new NotImplementedException("throwing non-exception " + type);
		}

		public static object ExtractException(Exception e) {
			//!!! there are a lot more options...
			sys.exc_value = e;
			sys.exc_type = GetDynamicType(e);

			return e;
		}
//			PyObject type, exc;
//
//			PythonStringException pse = e as PythonStringException;
//			if (pse != null) {
//				exc = pse.pyException;
//				type = pse.excType;
//			} else {
//				PythonException pe = e as PythonException;
//				if (pe != null) exc = pe.pyException;
//				else exc = Py.make(e);
//				//Console.WriteLine("exc: {0} __class__: {1}", exc, exc.__class__);
//				type = exc.__class__;
//			}
//
//			// set values in sys...
//			sys.exc_type = type;
//			sys.exc_value = exc;
//
//			//!!!sys.exc_traceback = new PyTraceback(e);
//			return exc;
//		}

		//!!! going through thread-locals in sys module is an expensive choice...
		public static bool CheckException(object exc, object test) {
			object exc_type = GetDynamicType(exc);
			if (__builtin__.isinstance(exc, test)) return true;
			return false;
//			PyObject type = sys.exc_type;
//			//Console.WriteLine("test: " + test + " of " + sys.exc_type);
//			if (is_(test, type).__nonzero__() || __builtin__.isinstance(test, type)) {
//				return true;
//			}
//			return false;
		}


		public static int FixSliceIndex(int v, int len) {
			if (v < 0) {
				v += len;
				if (v < 0) return 0;
				else return v;
			}
			if (v > len) return len;
			return v;
		}

		public static int FixIndex(int v, int len) {
			if (v < 0) {
				v += len;
				if (v < 0) {
					throw Ops.IndexError("index out of range: {0}", v-len);
				}
			} else if (v >= len) {
				throw Ops.IndexError("index out of range: {0}", v);
			}
			return v;
		}

		#region Generated Exception Factories
		
		public static Exception ValueError(string format, params object[] args) {
		    return new PythonValueError(string.Format(format, args));
		}
		
		public static Exception ImportError(string format, params object[] args) {
		    return new PythonImportError(string.Format(format, args));
		}
		
		public static Exception RuntimeError(string format, params object[] args) {
		    return new PythonRuntimeError(string.Format(format, args));
		}
		
		public static Exception UnicodeTranslateError(string format, params object[] args) {
		    return new PythonUnicodeTranslateError(string.Format(format, args));
		}
		
		public static Exception KeyError(string format, params object[] args) {
		    return new PythonKeyError(string.Format(format, args));
		}
		
		public static Exception StopIteration(string format, params object[] args) {
		    return new PythonStopIteration(string.Format(format, args));
		}
		
		public static Exception PendingDeprecationWarning(string format, params object[] args) {
		    return new PythonPendingDeprecationWarning(string.Format(format, args));
		}
		
		public static Exception EnvironmentError(string format, params object[] args) {
		    return new PythonEnvironmentError(string.Format(format, args));
		}
		
		public static Exception LookupError(string format, params object[] args) {
		    return new PythonLookupError(string.Format(format, args));
		}
		
		public static Exception OSError(string format, params object[] args) {
		    return new PythonOSError(string.Format(format, args));
		}
		
		public static Exception DeprecationWarning(string format, params object[] args) {
		    return new PythonDeprecationWarning(string.Format(format, args));
		}
		
		public static Exception UnicodeError(string format, params object[] args) {
		    return new PythonUnicodeError(string.Format(format, args));
		}
		
		public static Exception UnicodeEncodeError(string format, params object[] args) {
		    return new PythonUnicodeEncodeError(string.Format(format, args));
		}
		
		public static Exception FloatingPointError(string format, params object[] args) {
		    return new PythonFloatingPointError(string.Format(format, args));
		}
		
		public static Exception ReferenceError(string format, params object[] args) {
		    return new PythonReferenceError(string.Format(format, args));
		}
		
		public static Exception NameError(string format, params object[] args) {
		    return new PythonNameError(string.Format(format, args));
		}
		
		public static Exception OverflowWarning(string format, params object[] args) {
		    return new PythonOverflowWarning(string.Format(format, args));
		}
		
		public static Exception IOError(string format, params object[] args) {
		    return new PythonIOError(string.Format(format, args));
		}
		
		public static Exception SyntaxError(string format, params object[] args) {
		    return new PythonSyntaxError(string.Format(format, args));
		}
		
		public static Exception FutureWarning(string format, params object[] args) {
		    return new PythonFutureWarning(string.Format(format, args));
		}
		
		public static Exception SystemExit(string format, params object[] args) {
		    return new PythonSystemExit(string.Format(format, args));
		}
		
		public static Exception EOFError(string format, params object[] args) {
		    return new PythonEOFError(string.Format(format, args));
		}
		
		public static Exception StandardError(string format, params object[] args) {
		    return new PythonStandardError(string.Format(format, args));
		}
		
		public static Exception TabError(string format, params object[] args) {
		    return new PythonTabError(string.Format(format, args));
		}
		
		public static Exception ZeroDivisionError(string format, params object[] args) {
		    return new PythonZeroDivisionError(string.Format(format, args));
		}
		
		public static Exception SystemError(string format, params object[] args) {
		    return new PythonSystemError(string.Format(format, args));
		}
		
		public static Exception IndentationError(string format, params object[] args) {
		    return new PythonIndentationError(string.Format(format, args));
		}
		
		public static Exception AssertionError(string format, params object[] args) {
		    return new PythonAssertionError(string.Format(format, args));
		}
		
		public static Exception UnicodeDecodeError(string format, params object[] args) {
		    return new PythonUnicodeDecodeError(string.Format(format, args));
		}
		
		public static Exception TypeError(string format, params object[] args) {
		    return new PythonTypeError(string.Format(format, args));
		}
		
		public static Exception IndexError(string format, params object[] args) {
		    return new PythonIndexError(string.Format(format, args));
		}
		
		public static Exception RuntimeWarning(string format, params object[] args) {
		    return new PythonRuntimeWarning(string.Format(format, args));
		}
		
		public static Exception KeyboardInterrupt(string format, params object[] args) {
		    return new PythonKeyboardInterrupt(string.Format(format, args));
		}
		
		public static Exception UserWarning(string format, params object[] args) {
		    return new PythonUserWarning(string.Format(format, args));
		}
		
		public static Exception SyntaxWarning(string format, params object[] args) {
		    return new PythonSyntaxWarning(string.Format(format, args));
		}
		
		public static Exception MemoryError(string format, params object[] args) {
		    return new PythonMemoryError(string.Format(format, args));
		}
		
		public static Exception UnboundLocalError(string format, params object[] args) {
		    return new PythonUnboundLocalError(string.Format(format, args));
		}
		
		public static Exception ArithmeticError(string format, params object[] args) {
		    return new PythonArithmeticError(string.Format(format, args));
		}
		
		public static Exception Warning(string format, params object[] args) {
		    return new PythonWarning(string.Format(format, args));
		}
		
		public static Exception NotImplementedError(string format, params object[] args) {
		    return new PythonNotImplementedError(string.Format(format, args));
		}
		
		public static Exception AttributeError(string format, params object[] args) {
		    return new PythonAttributeError(string.Format(format, args));
		}
		
		public static Exception OverflowError(string format, params object[] args) {
		    return new PythonOverflowError(string.Format(format, args));
		}
		
		public static Exception WindowsError(string format, params object[] args) {
		    return new PythonWindowsError(string.Format(format, args));
		}
		#endregion


		public static Exception StopIteration() {
			return StopIteration("");
		}
	}
}
