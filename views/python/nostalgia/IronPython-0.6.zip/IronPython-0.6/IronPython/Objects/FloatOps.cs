/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Text;
using System.Collections;

using IronMath;

namespace IronPython.Objects {
	public class FloatOps {
		public static ReflectedType MakeDynamicType() {
			return new OpsReflectedType("float", typeof(double), typeof(FloatOps), null); //!!!typeof(ExtensibleInt));
		}

		public static object Make(object o) {
			if (o is string) return LiteralParser.ParseFloat((string)o);
			return Ops.object2double(o);
		}

		private static object TrueDivide(double x, double y) {
			return x / y;
		}

		public static object Abs(double x) {
			return Math.Abs(x);
		}

		private static object Power(double x, double y) {
			return Math.Pow(x, y);
		}

		public static object Divide(double x, object other) {
			return TrueDivide(x, other);
		}

		public static object Equals(double x, object other) {
			if (other is int) return Ops.bool2object(x == (int)other);
			else if (other is double) return Ops.bool2object(x == (double)other);
			else if (other is integer) return Ops.bool2object(x == (integer)other);
			else if (other is Complex64) return Ops.bool2object(x == (Complex64)other);

			return Ops.NotImplemented;
		}

		#region Generated FloatOps
		
		public static object Add(double x, object other) {
		    if (other is int) return x + ((int)other);
		    if (other is long) return x + ((long)other);
		    if (other is Complex64) return x +  ((Complex64)other);
		    if (other is double) return x +  ((double)other);
		    if (other is integer) return x +  ((integer)other);
		    return Ops.NotImplemented;
		}
		
		
		public static object Subtract(double x, object other) {
		    if (other is int) return x - ((int)other);
		    if (other is long) return x - ((long)other);
		    if (other is Complex64) return x -  ((Complex64)other);
		    if (other is double) return x -  ((double)other);
		    if (other is integer) return x -  ((integer)other);
		    return Ops.NotImplemented;
		}
		
		
		public static object Power(double x, object other) {
		    if (other is int) return Power(x , ((int)other));
		    if (other is long) return Power(x , ((long)other));
		    if (other is Complex64) return Power(x , ((Complex64)other));
		    if (other is double) return Power(x ,((double)other));
		    if (other is integer) return Power(x , ((integer)other));
		    return Ops.NotImplemented;
		}
		
		
		public static object Multiply(double x, object other) {
		    if (other is int) return x * ((int)other);
		    if (other is long) return x * ((long)other);
		    if (other is Complex64) return x *  ((Complex64)other);
		    if (other is double) return x *  ((double)other);
		    if (other is integer) return x *  ((integer)other);
		    return Ops.NotImplemented;
		}
		
		
		public static object FloorDivide(double x, object other) {
		    if (other is int) return x / ((int)other);
		    if (other is long) return x / ((long)other);
		    if (other is Complex64) return x /  ((Complex64)other);
		    if (other is double) return x /  ((double)other);
		    if (other is integer) return x /  ((integer)other);
		    return Ops.NotImplemented;
		}
		
		
		public static object TrueDivide(double x, object other) {
		    if (other is int) return TrueDivide(x , ((int)other));
		    if (other is long) return TrueDivide(x , ((long)other));
		    if (other is Complex64) return TrueDivide(x , ((Complex64)other));
		    if (other is double) return TrueDivide(x ,((double)other));
		    if (other is integer) return TrueDivide(x , ((integer)other));
		    return Ops.NotImplemented;
		}
		
		
		public static object Mod(double x, object other) {
		    if (other is int) return x % ((int)other);
		    if (other is long) return x % ((long)other);
		    if (other is Complex64) return x %  ((Complex64)other);
		    if (other is double) return x %  ((double)other);
		    if (other is integer) return x %  ((integer)other);
		    return Ops.NotImplemented;
		}
		
		#endregion
	}
}
