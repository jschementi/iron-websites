/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;
using System.Text;

using System.Reflection;

namespace IronPython.Objects {
	public class StringDynamicType:OpsReflectedType {
		public StringDynamicType():base("str", typeof(string), typeof(StringOps), typeof(ExtensibleString)) {
		}


		//!!! figure out how to move these up to the super class
		public override object Add(object self, object other) {
			string s = other as string;
			if (s == null) return Ops.NotImplemented;
			return ((string)self) + s;
		}

		public override object Multiply(object self, object other) {
			if (other is int) {
				return StringOps.Multiply((string)self, (int)other);
			}
			return Ops.NotImplemented;
		}

		public override object Mod(object self, object other) {
			return Ops.ToPython(new StringFormatter( (string)self, other).format());
		}
	}

	public class ExtensibleString:ICodeFormattable {
		public string _value;
		public ExtensibleString(string _value) { this._value = _value; }

		public override string ToString() {
			return _value;
		}
		#region ICodeFormattable Members

		public virtual string ToCodeString() {
			return StringOps.Quote(_value);
		}

		#endregion
	}


	public class StringOps {
//		public static PyObject __new__(PyType type) {
//			return __new__(type, "");
//		}
//
//		public static PyObject __new__(PyType type, string x) {
//			if (type == pytype) return make(x);
//			return type.MakeNew(pytype, x);
//		}

		private class PythonStringEnumerator:IEnumerator {
			private string s;
			private int i=-1;
			public PythonStringEnumerator(string s) {
				this.s = s;
				this.i = i;
			}
			#region IEnumerator Members

			public void Reset() {
				i=0;
			}

			public object Current {
				get {
					return Ops.char2string(s[i]);
				}
			}

			public bool MoveNext() {
				i++;
				return i < s.Length;
			}

			#endregion

		}


		public static IEnumerator GetEnumerator(string s) {
			//!!! make an enumerator that produces strings instead of chars
			return new PythonStringEnumerator(s);
		}

		private static byte[] ToByteArray(string s) {
			byte[] ret = new byte[s.Length];
			for (int i=0; i < s.Length; i++) {
				ret[i] = (byte)s[i]; //!!! what about overflows
			}
			return ret;
		}

		private static string FromByteArray(byte[] bytes) {
			StringBuilder b = new StringBuilder(bytes.Length);
			for (int i=0; i < bytes.Length; i++) {
				b.Append( (char)bytes[i]);
			}
			return b.ToString();
		}

		public static object Make(object x) {
			if (x is string) {
				//!!!return Make((string)x, null);
				// check ascii
				string s = (string)x;
				for (int i=0; i < s.Length; i++) {
					if (s[i] > '\x80') return Make(s, null);
				}
				return s;
			}
			return x.ToString();
		}

		private static Dict aliases = MakeAliasesDict();

		private static Dict MakeAliasesDict() {
			Dict d = new Dict();
			//!!! generate this from aliases for completeness
			d["646"] = "ascii";
			d["latin-1"] = "iso-8859-1";
			d["latin1"] = "iso-8859-1";
			d["utf8"] = "utf-8";
			d["us"] = "ascii";
			d["us-ascii"] = "ascii";

			return d;
		}

		public static Encoding DefaultEncoding = Encoding.ASCII; //!!!
		public static Encoding GetEncoding(string encoding) {
			if (encoding == null) return DefaultEncoding;
			encoding = encoding.ToLower().Replace('_', '-');

			string newName = (string)aliases[encoding];
			if (newName != null) encoding = newName;

			return Encoding.GetEncoding(encoding);
		}


		public static object Make(string s, string encoding) {
			return decode(s, encoding);
		}

		public static string decode(string s) {
			return decode(s, null);
		}
		public static string RawDecode(string s, string encoding) {
			Encoding e = GetEncoding(encoding);
			return e.GetString(ToByteArray(s));
		}


		public static string decode(string s, string encoding) {
			string ret = RawDecode(s, encoding);

			//??? This is some very expensive checking to match Python's error behavior
			//??? It would be very nice to find a better way
			string expectedIn = RawEncode(ret, encoding);
			if (s != expectedIn) {
				throw Ops.UnicodeDecodeError("{0} codec can't decode {1} (looks like {2})",
					encoding, Ops.StringRepr(s), Ops.StringRepr(expectedIn));
			}

			return ret;
		}

		public static string RawEncode(string s, string encoding) {
			Encoding e = GetEncoding(encoding);
			return FromByteArray(e.GetBytes(s));
		}

		public static string encode(string s, string encoding) {
			string ret = RawEncode(s, encoding);

			//???(see ??? in decode for checking)
			string expectedIn = RawDecode(ret, encoding);
			if (s != expectedIn) {
				throw Ops.UnicodeEncodeError("{0} codec can't encode {1} (looks like {2})",
					encoding, Ops.StringRepr(s), Ops.StringRepr(expectedIn));
			}

			return ret;
		}


		public static string Multiply(int count, string s) {
			return Multiply(s, count);
		}

		public static string Multiply(string s, int count) {
			int sz = s.Length;
			if (sz == 1) return new string(s[0], count);

			StringBuilder ret = new StringBuilder(sz*count);
			ret.Insert(0, s, count);
			// the above code is MUCH faster than the simple loop
			//for (int i=0; i < count; i++) ret.Append(s);
			return ret.ToString();
		}

		public static int __len__(string s) {
			return s.Length;
		}

		public static string __getitem__(string s, int index) {
			return Ops.char2string(s[Ops.FixIndex(index, s.Length)]);
		}

		public static string __getitem__(string s, Slice slice) {
			int start, stop, step;
			slice.indices(s.Length, out start, out stop, out step);
			if (step == 1) {
				return s.Substring(start, stop-start);
			} else {
				int icnt = (stop-start)/step;
				char[] newData = new char[icnt];
				int index=0;
				if (step > 0) {
					for(int i=start; i < stop; i+=step) {
						newData[index++] = s[i];
					}
				} else {
					for(int i=start-1; i >= stop; i-=step) {
						newData[index++] = s[i];
					}
				}
				return new string(newData);
			}
		}


//		public object Add(object other) {
//			Str o = other as Str;
//			if (o == null) return Py.NotImplemented;
//			return Str.make(string.Concat(_value, o._value));
//		}


//		public override PyObject rawGet(int index) {
//			return make(_value[index]);
//		}
//
//		public override PyObject __not__() {
//			return PyBoolean.make(_value.Length == 0);
//		}
//
//
//		public override PyObject __mul__(int count) {
//			int N = this._value.Length;
//			if (N == 1) return Str.make(new string(_value[0], count));
//
//			StringBuilder ret = new StringBuilder(N*count);
//			for (int i=0; i < count; i++) ret.Append(_value);
//			return new Str(ret.ToString());
//		}
//		public override bool __nonzero__() {
//			return _value.Length > 0;
//		}
//
//

//
//		public override bool __contains__(PyObject item) {
//			Str s = item as Str;
//			if (s == null || s._value.Length != 1) return false;
//			char ch = Py.asChar(item); //!!! redundant checks
//			return _value.IndexOf(ch) != -1;
//		}
//
//
//		//!!! this plus same style in PyInteger = ~8% pystone boost
//		public override PyObject __eq__(PyObject other) {
//			if (other == this) return PyBoolean.make(true);
//			Str o = other as Str;
//			if (o == null) return Py.NotImplemented;
//			return PyBoolean.make(o._value == _value);
//		}
//
//		//TODO expand to full rich comparision set
//		public override int __cmp__(PyObject other) {
//			//!!! this comparision doesn't match Python's results for cased compares
//			Str o = other as Str;
//			if (o == null) return base.__cmp__(other);
//			return _value.CompareTo(o._value);
//		}
//
//		public override int __hash__() {
//			return GetHashCode();
//		}
//
//		public override PyInteger __int__() {
//			String s = _value.Trim();
//			int radix = 10;
////			if (s[0] == '0') {
////				if (s.Length == 1) return PyInteger.make(0);
////				if (s[1] == 'x' || s[1] == 'X') {
////					s = s.Substring(2, s.Length-2);
////					radix = 16;
////				} else {
////					s = s.Substring(1, s.Length-1);
////					radix = 8;
////				}
////			}
//			return (PyInteger)Values.ConstantValue.makeInt(s, radix).getPyObject();
//		}
//
//		public override PyObject __str__() {
//			return this;
//		}
//
		public static string Quote(string s) {

			bool isUnicode = false;
			StringBuilder b = new StringBuilder(s.Length+5);
			char quote = '\'';
			if (s.IndexOf('\'') != -1 && s.IndexOf('\"') == -1) {
				quote = '\"';
			}
			b.Append(quote);
			foreach (char ch in s) {
				if (ch > 255) isUnicode = true;
				switch (ch) {
					case '\\': b.Append("\\\\"); break;
					case '\t': b.Append("\\t"); break;
					case '\n': b.Append("\\n"); break;
					case '\r': b.Append("\\r"); break;
					default:
						if (ch == quote) {
							b.Append('\\'); b.Append(ch);
						} else if (ch < ' ' || ch >= 0x7f) {
							b.AppendFormat("\\x{0:x2}", (int)ch);
						} else {
							b.Append(ch);
						}
						break;
				}
			}
			b.Append(quote);
			if (isUnicode) return "u" + b.ToString();
			return b.ToString();
		}


		public static string capitalize(string _value) {
			if (_value.Length == 0) return _value;
			return Char.ToUpper(_value[0]) + _value.Substring(1).ToLower();
		}

		public static string center(string _value, int width) {
			int spaces = width-_value.Length;
			if (spaces <= 0) return _value;

			StringBuilder ret = new StringBuilder(width);
			ret.Append(' ', spaces/2);
			ret.Append(_value);
			ret.Append(' ', (spaces+1)/2);
			return ret.ToString();
		}

		public static int count(string _value, string sub) {
			return count(_value, sub, 0, _value.Length);
		}

		public static int count(string _value, string sub, int start) {
			return count(_value, sub, start, _value.Length);
		}

		public static int count(string _value, string ssub, int start, int end) {			
			string v = _value;
			if (v.Length == 0) return 0;

			start = Ops.FixSliceIndex(start, _value.Length);
			end = Ops.FixSliceIndex(end, _value.Length);

			int count = 0;
			while (true) {
				int index = v.IndexOf(ssub, start, end-start);
				if (index == -1) break;
				count++;
				start = index+ssub.Length;
			}
			return count;
		}

		//!!! decode, encode

		public static bool endswith(string _value, string suffix) { //!!!, int start, int end) {
			return _value.EndsWith(suffix);
		}

		public static string expandtabs(string _value) {
			return expandtabs(_value, 8);
		}

		public static string expandtabs(string _value, int tabsize) {
			StringBuilder ret = new StringBuilder(_value.Length*2);
			string v = _value;
			int col = 0;
			for (int i=0; i < v.Length; i++) {
				char ch = v[i];
				switch (ch) {
					case '\n': case '\r': col = 0; ret.Append(ch); break;
					case '\t':
						int tabs = tabsize-(col%tabsize);
						ret.Append(' ', tabs);
						break;
					default:
						col++;
						ret.Append(ch);
						break;
				}
			}
			return ret.ToString();
		}

		public static int find(string _value, string sub) {
			return _value.IndexOf(sub);
		}

		public static int find(string _value, string sub, int start) {
			return _value.IndexOf(sub, Ops.FixSliceIndex(start, _value.Length));
		}

		public static int find(string _value, string sub, int start, int end) {
			start = Ops.FixSliceIndex(start, _value.Length);
			end = Ops.FixSliceIndex(end, _value.Length);

			return _value.IndexOf(sub, start, end-start);
		}

		public static int index(string _value, string sub) {
			return index(_value, sub, 0, _value.Length);
		}

		public static int index(string _value, string sub, int start) {
			return index(_value, sub, start, _value.Length);
		}

		public static int index(string _value, string sub, int start, int end) {
			int ret = find(_value, sub, start, end);
			if (ret == -1) throw Ops.ValueError("substring {0} not found in {1}", sub, _value);
			return ret;
		}

		public static bool isalnum(string _value) {
			if (_value.Length == 0) return false;
			string v = _value;
			for (int i=v.Length-1; i >= 0; i--) {
				if (!Char.IsLetterOrDigit(v, i)) return false;
			}
			return true;
		}

		public static bool isalpha(string _value) {
			if (_value.Length == 0) return false;
			string v = _value;
			for (int i=v.Length-1; i >= 0; i--) {
				if (!Char.IsLetter(v, i)) return false;
			}
			return true;
		}

		public static bool isdigit(string _value) {
			if (_value.Length == 0) return false;
			string v = _value;
			for (int i=v.Length-1; i >= 0; i--) {
				if (!Char.IsDigit(v, i)) return false;
			}
			return true;
		}

		public static bool isspace(string _value) {
			if (_value.Length == 0) return false;
			string v = _value;
			for (int i=v.Length-1; i >= 0; i--) {
				if (!Char.IsWhiteSpace(v, i)) return false;
			}
			return true;
		}

		public static bool islower(string _value) {
			if (_value.Length == 0) return false;
			string v = _value;
			bool hasLower = false;
			for (int i=v.Length-1; i >= 0; i--) {
				if (!hasLower && Char.IsLower(v, i)) hasLower = true;
				if (Char.IsUpper(v, i)) return false;
			}
			return hasLower;
		}

		public static bool isupper(string _value) {
			if (_value.Length == 0) return false;
			string v = _value;
			bool hasUpper = false;
			for (int i=v.Length-1; i >= 0; i--) {
				if (!hasUpper && Char.IsUpper(v, i)) hasUpper = true;
				if (Char.IsLower(v, i)) return false;
			}
			return hasUpper;
		}

		//!!! istitle

		public static string join(string _value, IEnumerator seq) {
			StringBuilder ret = new StringBuilder();
			if (!seq.MoveNext()) return "";

			ret.Append(seq.Current.ToString());
			while (seq.MoveNext()) {
				ret.Append(_value);
				ret.Append(seq.Current.ToString());
			}
			return ret.ToString();
		}

		public static string ljust(string _value, int width) {
			int spaces = width-_value.Length;
			if (spaces <= 0) return _value;

			StringBuilder ret = new StringBuilder(width);
			ret.Append(_value);
			ret.Append(' ', spaces);
			return ret.ToString();
		}

		public static string lower(string _value) {
			return _value.ToLower();
		}

		public static readonly char[] WHITESPACE = new char[] { ' ', '\t', '\n', '\r', '\f' };
		public static string lstrip(string _value) {
			return _value.TrimStart(WHITESPACE);
		}

		public static string lstrip(string _value, string chars) {
			if (chars == null) return lstrip(_value);
			return _value.TrimStart(chars.ToCharArray());
		}

		private static string replaceEmpty(string _value, string new_, int maxsplit) {
			if (maxsplit == 0) return _value;

			string v = _value;
			int max = maxsplit > v.Length ? v.Length : maxsplit;
			StringBuilder ret = new StringBuilder(v.Length*(new_.Length+1));
			for (int i=0; i < max; i++) {
				ret.Append(new_);
				ret.Append(v[i]);
			}
			if (maxsplit > max) {
				ret.Append(new_);
			}

			return ret.ToString();
		}


		public static string replace(string _value, string old, string new_) {
			if (old.Length == 0) return replaceEmpty(_value, new_, _value.Length+1);
			return _value.Replace(old, new_);
		}

		public static string replace(string _value, string old, string new_, int maxsplit) {
			if (maxsplit == -1) return replace(_value, old, new_);

			if (old.Length == 0) return replaceEmpty(_value, new_, maxsplit);

			string v = _value;
			StringBuilder ret = new StringBuilder(v.Length);

			int index;
			int start = 0;

			while (maxsplit > 0 && (index = v.IndexOf(old, start)) != -1) {
				ret.Append(v.Substring(start, index-start));
				ret.Append(new_);
				start = index+old.Length;
				maxsplit--;
			}
			ret.Append(v.Substring(start));

			return ret.ToString();
		}

		public static int rfind(string _value, string sub) {
			return rfind(_value, sub, 0, _value.Length);
		}

		public static int rfind(string _value, string sub, int start) {
			return rfind(_value, sub, start, _value.Length);
		}

		public static int rfind(string _value, string sub, int start, int end) {
			if (sub.Length == 0) return _value.Length;

			start = Ops.FixSliceIndex(start, _value.Length);
			end = Ops.FixSliceIndex(end, _value.Length);
			//Console.WriteLine("count {0}, {1}, {2}", end-start-sub._value.Length, _value.Length, start);
			return _value.LastIndexOf(sub, end-1, end-start);
		}

		public static int rindex(string _value, string sub) {
			return rindex(_value, sub, 0, _value.Length);
		}

		public static int rindex(string _value, string sub, int start) {
			return rindex(_value, sub, start, _value.Length);
		}

		public static int rindex(string _value, string sub, int start, int end) {
			int ret = rfind(_value, sub, start, end);
			if (ret == -1) throw Ops.ValueError("substring {0} not found in {1}", sub, _value);
			return ret;
		}

		public static string rjust(string _value, int width) {
			int spaces = width-_value.Length;
			if (spaces <= 0) return _value;

			StringBuilder ret = new StringBuilder(width);
			ret.Append(' ', spaces);
			ret.Append(_value);
			return ret.ToString();
		}

		public static string rstrip(string _value) {
			return _value.TrimEnd(WHITESPACE);
		}

		public static string rstrip(string _value, string chars) {
			if (chars == null) return rstrip(_value);
			return _value.TrimEnd(chars.ToCharArray());
		}

		private static List split(string _value, char[] seps) {
			string[] r = _value.Split(seps);
			List ret = List.MakeEmptyList(r.Length);    
			foreach (string s in r) ret.Add(s); //Str.make(s));  //!!! more evidence that multple strings is bad
			return ret;
		}

		public static List split(string _value) {
			return split(_value, (char[])null);
		}

		public static List split(string _value, string sep) {
			if (sep == null) return split(_value);

			if (sep.Length == 0) {
				throw new Exception("empty separator"); //Py.ValueError("empty separator");
			} else if (sep.Length == 1) {
				return split(_value, new char[] { sep[0] } );
			} else {
				throw new NotImplementedException("split with non-char separator");
			}
		}

		public static List split(string _value, string sep, int maxsplit) {
			if (maxsplit == -1) return split(_value, sep);

			throw new NotImplementedException("maxsplit");
		}
//			
//		//!!! split with non-char sep and with maxsplits
//		//!!! splitlines
//
		public static bool startswith(string _value, string suffix) { //!!!, int start, int end) {
			return _value.StartsWith(suffix);
		}

		public static string strip(string _value) {
			return _value.Trim();
		}

		public static string strip(string _value, string chars) {
			if (chars == null) return strip(_value);
			return _value.Trim(chars.ToCharArray());
		}

		public static string swapcase(string _value) {
			StringBuilder ret = new StringBuilder(_value);
			for (int i=0; i < ret.Length; i++) {
				char ch = ret[i];
				if (Char.IsUpper(ch)) ret[i] = Char.ToLower(ch);
				else if (Char.IsLower(ch)) ret[i] = Char.ToUpper(ch);
			}
			return ret.ToString();
		}

		//!!! title

		//!!! translate

		public static string upper(string _value) {
			return _value.ToUpper();
		}

		private static bool isSign(char ch) {
			return ch == '+' || ch == '-';
		}

		public static string zfill(string _value, int width) {
			int spaces = width-_value.Length;
			if (spaces <= 0) return _value;

			StringBuilder ret = new StringBuilder(width);
			if (_value.Length > 0 && isSign(_value[0])) {
				ret.Append(_value[0]);
				ret.Append('0', spaces);
				ret.Append(_value.Substring(1));
			} else {
				ret.Append('0', spaces);
				ret.Append(_value);
			}
			return ret.ToString();
		}


		// do string % operator
//		public override PyObject __mod__(PyObject other) {
//			throw new NotImplementedException();
//			//!!!return new StringFormatter(value, other).format();
//		}
//
//		
//		public override bool toObject(Type asType, out object ret) {
//			if (asType == typeof(string)) ret = _value;
//			else return base.toObject(asType, out ret);
//			return true;
//		}

		// Directly override a few object methods for performance benefits
//		public override bool Equals(Object other) {
//			Str o = other as Str;
//			if (o == null) return false;
//			if (_interned && o._interned) return (object)this == (object)o;
//			else return this._value == o._value;
//		}
//
//		public override string ToString() {
//			return _value;
//		}
//
//
//		public override int GetHashCode() {
//			if (_hash == -1) _hash = _value.GetHashCode();
//			return _hash;
//		}


//
//		public static PyObject __getitem__(PyObject self, PyObject key) {
//			return (Str.checkCast(self)).__getitem__(key);
//		}
	}

}
