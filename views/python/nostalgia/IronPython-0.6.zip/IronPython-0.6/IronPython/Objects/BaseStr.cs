/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;
using System.Text;

using System.Reflection;

namespace IronPython.Objects {
	public abstract class BaseStr {
		protected bool isInterned = false;
		protected int hashCode = -1; //!!! find a good safe value here
		public string _value;
		public BaseStr(string _value) {
			this._value = _value;
		}

		public abstract BaseStr MakeStr(string s);

//		private class BaseStrEnumerator:IEnumerator {
//			private BaseStr s;
//			private int i=-1;
//			public BaseStrEnumerator(BaseStr s) {
//				this.s = s;
//				this.i = i;
//			}
//			#region IEnumerator Members
//
//			public void Reset() {
//				i=0;
//			}
//
//			public object Current {
//				get {
//					return BaseStr.char2string(s[i]);
//				}
//			}
//
//			public bool MoveNext() {
//				i++;
//				return i < s.Length;
//			}
//
//			#endregion
//		}
//
//		public IEnumerator GetEnumerator() {
//			//!!! make an enumerator that produces strings instead of chars
//			return new BaseStrEnumerator(_value);
//		}

//		private static byte[] ToByteArray(string s) {
//			byte[] ret = new byte[s.Length];
//			for (int i=0; i < s.Length; i++) {
//				ret[i] = (byte)s[i]; //!!! what about overflows
//			}
//			return ret;
//		}
//
//		private static string FromByteArray(byte[] bytes) {
//			StringBuilder b = new StringBuilder(bytes.Length);
//			for (int i=0; i < bytes.Length; i++) {
//				b.Append( (char)bytes[i]);
//			}
//			return b.ToString();
//		}
//
//		public static object Make(object x) {
//			if (x is string) {
//				//!!!return Make((string)x, null);
//				// check ascii
//				string s = (string)x;
//				for (int i=0; i < s.Length; i++) {
//					if (s[i] > '\x80') return Make(s, null);
//				}
//				return s;
//			}
//			return x.ToString();
//		}
//
//		private static Dict aliases = MakeAliasesDict();
//
//		private static Dict MakeAliasesDict() {
//			Dict d = new Dict();
//			//!!! generate this from aliases for completeness
//			d["646"] = "ascii";
//			d["latin-1"] = "iso-8859-1";
//			d["utf8"] = "utf-8";
//			d["us"] = "ascii";
//			d["us-ascii"] = "ascii";
//
//			return d;
//		}
//
//		public static Encoding DefaultEncoding = Encoding.ASCII; //!!!
//		public static Encoding GetEncoding(string encoding) {
//			if (encoding == null) return DefaultEncoding;
//			encoding = encoding.ToLower().Replace('_', '-');
//
//			string newName = (string)aliases[encoding];
//			if (newName != null) encoding = newName;
//
//			return Encoding.GetEncoding(encoding);
//		}
//
//
//		public static object Make(string s, string encoding) {
//			return decode(s, encoding);
//		}
//
//		public static string decode(string s) {
//			return decode(s, null);
//		}
//		public static string RawDecode(string s, string encoding) {
//			Encoding e = GetEncoding(encoding);
//			return e.GetString(ToByteArray(s));
//		}
//
//
//		public static string decode(string s, string encoding) {
//			string ret = RawDecode(s, encoding);
//
//			//??? This is some very expensive checking to match Python's error behavior
//			//??? It would be very nice to find a better way
//			string expectedIn = RawEncode(ret, encoding);
//			if (s != expectedIn) {
//				throw Ops.UnicodeDecodeError("{0} codec can't decode {1} (looks like {2})",
//					encoding, Ops.StringRepr(s), Ops.StringRepr(expectedIn));
//			}
//
//			return ret;
//		}
//
//		public static string RawEncode(string s, string encoding) {
//			Encoding e = GetEncoding(encoding);
//			return FromByteArray(e.GetBytes(s));
//		}
//
//		public static string encode(string s, string encoding) {
//			string ret = RawEncode(s, encoding);
//
//			//???(see ??? in decode for checking)
//			string expectedIn = RawDecode(ret, encoding);
//			if (s != expectedIn) {
//				throw Ops.UnicodeEncodeError("{0} codec can't encode {1} (looks like {2})",
//					encoding, Ops.StringRepr(s), Ops.StringRepr(expectedIn));
//			}
//
//			return ret;
//		}


		public static string GetSlice(string s, int istart, int istop) {
//			int istart, istop;
//			if (start == Py.None) istart = 0;
//			else istart = getSliceIndex(start);
//
//			if (stop == Py.None) istop = _value.Length;
//			else istop = getSliceIndex(stop);
			istart = Ops.FixSliceIndex(istart, s.Length);
			istop = Ops.FixSliceIndex(istop, s.Length);
			return s.Substring(istart, istop-istart);
		}

		public static string Multiply(int count, string s) {
			return Multiply(s, count);
		}

		public static string Multiply(string s, int count) {
			int sz = s.Length;
			if (sz == 1) return new string(s[0], count);

			StringBuilder ret = new StringBuilder(sz*count);
			ret.Insert(0, s, count);
			// the above code is MUCH faster than the simple loop
			//for (int i=0; i < count; i++) ret.Append(s);
			return ret.ToString();
		}

		public static int __len__(string s) {
			return s.Length;
		}

		public static string GetItem(string s, int index) {
			return Ops.char2string(s[index]);//!!! correct negative support
		}




		public BaseStr capitalize() {
			return MakeStr(StringOps.capitalize(_value));
		}

		public BaseStr center(int width) {
			return MakeStr(StringOps.center(_value, width));
		}

		public int count(string sub) {
			return StringOps.count(_value, sub);
		}

		public int count(string sub, int start) {
			return StringOps.count(_value, sub, start);
		}

		public int count(string ssub, int start, int end) {			
			return StringOps.count(_value, ssub, start, end);
		}

		//!!! decode, encode

		public bool endswith(string suffix) { //!!!, int start, int end) {
			return StringOps.endswith(_value, suffix);
		}

		public BaseStr expandtabs() {
			return MakeStr(StringOps.expandtabs(_value));
		}

		public BaseStr expandtabs(int tabsize) {
			return MakeStr(StringOps.expandtabs(_value, tabsize));
		}

		public int find(string sub) {
			return StringOps.find(_value, sub);
		}

		public int find(string sub, int start) {
			return StringOps.find(_value, sub, start);
		}

		public int find(string sub, int start, int end) {
			return StringOps.find(_value, sub, start, end);
		}

		public int index(string sub) {
			return index(sub, 0, _value.Length);
		}

		public int index(string sub, int start) {
			return index(sub, start, _value.Length);
		}

		public int index(string sub, int start, int end) {
			return StringOps.index(_value, sub, start, end);
		}

		public bool isalnum() {
			return StringOps.isalnum(_value);
		}

		public bool isalpha() {
			return StringOps.isalpha(_value);
		}

		public bool isdigit() {
			return StringOps.isdigit(_value);
		}

		public bool isspace() {
			return StringOps.isspace(_value);
		}

		public bool islower() {
			return StringOps.islower(_value);
		}

		public bool isupper() {
			return StringOps.isupper(_value);
		}

		//!!! istitle

		public BaseStr join(IEnumerator seq) {
			return MakeStr(StringOps.join(_value, seq));
		}

		public BaseStr ljust(int width) {
			return MakeStr(StringOps.ljust(_value, width));
		}

		public BaseStr lower() {
			return MakeStr(StringOps.lower(_value));
		}

		public BaseStr lstrip() {
			return MakeStr(StringOps.lstrip(_value));
		}

		public BaseStr lstrip(string chars) {
			return MakeStr(StringOps.lstrip(_value, chars));
		}


		public BaseStr replace(string old, string new_) {
			return MakeStr(StringOps.replace(_value, old, new_));
		}

		public BaseStr replace(string old, string new_, int maxsplit) {
			return MakeStr(StringOps.replace(_value, old, new_, maxsplit));
		}

		public int rfind(string sub) {
			return StringOps.rfind(_value, sub);
		}

		public int rfind(string sub, int start) {
			return StringOps.rfind(_value, sub, start);
		}

		public int rfind(string sub, int start, int end) {
			return StringOps.rfind(_value, sub, start, end);
		}

		public int rindex(string sub) {
			return StringOps.rindex(_value, sub);
		}

		public int rindex(string sub, int start) {
			return StringOps.rindex(_value, sub, start);
		}

		public int rindex(string sub, int start, int end) {
			return StringOps.rindex(_value, sub, start, end);
		}

		public BaseStr rjust(int width) {
			return MakeStr(StringOps.rjust(_value, width));
		}

		public BaseStr rstrip() {
			return MakeStr(StringOps.rstrip(_value));
		}

		public BaseStr rstrip(string chars) {
			return MakeStr(StringOps.rstrip(_value, chars));
		}

		//!!! This need to be customized !!!
		public List split() {
			return StringOps.split(_value);
		}

		public List split(string sep) {
			return StringOps.split(_value, sep);
		}

		public List split(string sep, int maxsplit) {
			return StringOps.split(_value, sep, maxsplit);
		}
//			
//		//!!! split with non-char sep and with maxsplits
//		//!!! splitlines
//
		public bool startswith(string suffix) { //!!!, int start, int end) {
			return StringOps.startswith(_value, suffix);
		}

		public BaseStr strip() {
			return MakeStr(StringOps.strip(_value));
		}

		public BaseStr strip(string chars) {
			return MakeStr(StringOps.strip(_value, chars));
		}

		public BaseStr swapcase() {
			return MakeStr(StringOps.swapcase(_value));
		}

		//!!! title

		//!!! translate

		public BaseStr upper() {
			return MakeStr(StringOps.upper(_value));
		}

		public BaseStr zfill(int width) {
			return MakeStr(StringOps.zfill(_value, width));
		}



		public override string ToString() {
			return _value;
		}

		public override bool Equals(object obj) {
			BaseStr s = obj as BaseStr;
			if (s == null) return false;

			return _value.Equals(s._value);
		}

		public override int GetHashCode() {
			if (hashCode == -1) hashCode = _value.GetHashCode();
			return hashCode;
		}
	}


	public class Str:BaseStr,ICodeFormattable {
		private static Hashtable strings = new Hashtable();
		public static Str intern(string s) {
			Str ret = (Str)strings[s];
			if (ret == null) {
				ret = new Str(s);
				ret.isInterned = true;
				ret.GetHashCode();
				strings[s] = ret;
			}
			return ret;
		}

		public Str(string s):base(s) {}

		public Str _intern() {
			return intern(_value);
		}

		public override BaseStr MakeStr(string s) {
			return new Str(s);
		}

		public override int GetHashCode() {
			return base.GetHashCode();
		}

		public override bool Equals(object obj) {
			Str s = obj as Str;
			if (s == null) return base.Equals(obj);

			if (isInterned && s.isInterned) return this == obj;
			return _value.Equals(s._value); //??? would using hashCode be helpful ???
		}
		#region ICodeFormattable Members

		public string ToCodeString() {
			return StringOps.Quote(_value);
		}

		#endregion
	}

	public class UniStr:BaseStr,ICodeFormattable {
		private static Hashtable strings = new Hashtable();
		public static UniStr intern(string s) {
			UniStr ret = (UniStr)strings[s];
			if (ret == null) {
				ret = new UniStr(s);
				ret.isInterned = true;
				ret.GetHashCode();
				strings[s] = ret;
			}
			return ret;
		}

		public UniStr(string s):base(s) {}

		public UniStr _intern() {
			return intern(_value);
		}

		public override BaseStr MakeStr(string s) {
			return new UniStr(s);
		}

		public override int GetHashCode() {
			return base.GetHashCode();
		}

		public override bool Equals(object obj) {
			UniStr s = obj as UniStr;
			if (s == null) return base.Equals(obj);

			if (isInterned && s.isInterned) return this == obj;
			return _value.Equals(s._value); //??? would using hashCode be helpful ???
		}
		#region ICodeFormattable Members

		public string ToCodeString() {
			return "u" + StringOps.Quote(_value);
		}

		#endregion
	}
}
