/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;
using System.Collections.Specialized;
using System.Text;

namespace IronPython.Objects
{
	public class ModuleDictionary:IMapping,IEnumerable,IDictionary {
		public module mod;

		public ModuleDictionary(module mod) {
			this.mod = mod;
		}

		public override string ToString() {
			StringBuilder buf = new StringBuilder();
			buf.Append("{");

			bool first = true;
			foreach (object key in keys()) {
				if (this[key] == this) continue; //!!! don't be recursive

				if (first) { first = false; }
				else { buf.Append(", "); }
				buf.Append(Ops.StringRepr(key));
				buf.Append(":");
				buf.Append(Ops.StringRepr(this[key]));
			}
			buf.Append("}");
			return buf.ToString();
		}

		public List keys() {
			return List.Make(mod.__attrs__());
		}
		public List values() {
			List keys = this.keys();
			List ret = List.MakeEmptyList(keys.Count);
			foreach (object key in keys) {
				ret.append( this[key] );
			}

			return ret;
		}
		public List items() {
			List keys = this.keys();
			List ret = new List();

			foreach (object key in keys) {
				ret.append( Tuple.MakeTuple(key, this[key]) );
			}

			return ret;
		}


		public virtual int __len__() {
			return keys().Count;
		}

		public virtual bool __contains__(object key) {
			return get(key, Ops.Missing) != Ops.Missing;
		}

		public virtual object get(object key) {
			return __getitem__(key);
		}

		public virtual object get(object key, object defaultValue) {
			return __getitem__(key);
//			if (data.Contains(key)) return data[key];
//			return defaultValue;
		}

//		public virtual object setdefault(object key, object defaultValue) {
//			if (data.Contains(key)) return data[key];
//			data[key] = defaultValue;
//			return defaultValue;
//		}

		public virtual object __getitem__(object key) {
			object ret = this[key];
			if (ret == Ops.Missing) throw Ops.IndexError("missing key {0}", key);
			return ret;
		}

		public virtual void __setitem__(object key, object value) {
			this[key] = value;
		}

		public virtual void __delitem__(object key) {
			throw new NotImplementedException();
		}

		IEnumerator IEnumerable.GetEnumerator() {
			//!!! this is a hack to allow modification of the dict while iterating over the keys
			return keys().GetEnumerator();  //!!! there's a performance price here that's higher than I'd like
			//return this.Keys.GetEnumerator();
			//return this.Keys.GetEnumerator();
		}


		#region IDictionary Members

		public bool IsReadOnly {
			get {
				return false;
			}
		}

		public IDictionaryEnumerator GetEnumerator() {
			// TODO:  Add ModuleDictionary.GetEnumerator implementation
			return null;
		}

		public object this[object key] {
			get {
				return mod.__getattribute__((string)key);
			}
			set {
				mod.__setattr__((string)key, value);
			}
		}

		public void Remove(object key) {
			// TODO:  Add ModuleDictionary.Remove implementation
		}

		public bool Contains(object key) {
			// TODO:  Add ModuleDictionary.Contains implementation
			return false;
		}

		public void Clear() {
			// TODO:  Add ModuleDictionary.Clear implementation
		}

		public ICollection Values {
			get {
				// TODO:  Add ModuleDictionary.Values getter implementation
				return null;
			}
		}

		public void Add(object key, object value) {
			// TODO:  Add ModuleDictionary.Add implementation
		}

		public ICollection Keys {
			get {
				// TODO:  Add ModuleDictionary.Keys getter implementation
				return null;
			}
		}

		public bool IsFixedSize {
			get {
				// TODO:  Add ModuleDictionary.IsFixedSize getter implementation
				return false;
			}
		}

		#endregion

		#region ICollection Members

		public bool IsSynchronized {
			get {
				// TODO:  Add ModuleDictionary.IsSynchronized getter implementation
				return false;
			}
		}

		public int Count {
			get {
				// TODO:  Add ModuleDictionary.Count getter implementation
				return 0;
			}
		}

		public void CopyTo(Array array, int index) {
			// TODO:  Add ModuleDictionary.CopyTo implementation
		}

		public object SyncRoot {
			get {
				// TODO:  Add ModuleDictionary.SyncRoot getter implementation
				return null;
			}
		}

		#endregion

	}
}
