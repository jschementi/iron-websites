/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Text;
using System.Collections;

namespace IronPython.Objects {
	[PythonType("xrange")]
	public class XRange:ISequence,IEnumerable {
		internal readonly int start, stop, step;

		public XRange(int stop): this(0, stop, 1) {}
		public XRange(int start, int stop): this(start, stop, 1) {}

		public XRange(int start, int stop, int step) {
			this.start = start; this.stop = stop; this.step = step;
		}


		#region ISequence Members

		public int __len__() {
			return (stop-start)/step;
		}

		public bool __contains__(object item) {
			throw new NotImplementedException();
		}

		public object __getitem__(int index) {
			int ind = index*step+start;
			if (ind < start || ind >= stop) throw Ops.IndexError("out of range {0}", index);
			return Ops.int2object(ind);
		}

		public object __add__(object other) {
			throw new NotImplementedException();
		}

		public object __mul__(int count) {
			throw new NotImplementedException();
		}

		public object __getitem__(Slice slice) {
			throw new NotImplementedException();
		}

		#endregion

		public IEnumerator GetEnumerator() {
			return new XRangeIterator(this); 
		}
		
		public override string ToString() {
			if (step == 1) {
				if (start == 0) {
					return string.Format("xrange({0})", stop);
				} else {
					return string.Format("xrange({0}, {1})", start, stop);
				}
			} else {
				return string.Format("xrange({0}, {1}, {2})", start, stop, step);
			}
		}
	}
	public class XRangeIterator:IEnumerator {
		private XRange l;
		private int value;
		public XRangeIterator(XRange l) {
			this.l = l;
			value = l.start-l.step;
		}

		public object Current {
			get { return Ops.int2object(value); }
		}

		public bool MoveNext() {
			value += l.step;
			return value < l.stop;
		}

		public void Reset() {
			value = l.start-l.step;
		}
	}
}
