/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Text;
using System.Collections;

using IronMath;

namespace IronPython.Objects {
	public class LongOps {
		public static ReflectedType MakeDynamicType() {
			return new OpsReflectedType("long", typeof(integer), typeof(LongOps), null); //typeof(ExtensibleInt));
		}

		public static object Make(string s, int radix) {
			return LiteralParser.ParseBigInteger( s, radix);
		}		

		public static object Make(object o) {
			if (o is string) return LiteralParser.ParseBigInteger( (string) o, 10);

			if (o is IronMath.integer) return (IronMath.integer)o;
			else if (o is int) return (long) (int)o; //IronMath.integer.make( (int)o);
			//else if (o is double) return IronMath.integer.make( (double)o);

			throw new NotImplementedException();
		}

		private static object TrueDivide(integer x, int y) {
			throw new NotImplementedException();
		}

		public static object Abs(integer x) {
			return x.abs();
		}

		private static object Power(integer x, int y) {
			return x.pow(y); //y.AsInt32());
		}

		public static object Divide(integer x, object other) {
			return FloorDivide(x, other);
		}

		public static object Equals(integer x, object other) {
			if (other is int) return Ops.bool2object(x == (integer)(int)other);
			else if (other is long) return Ops.bool2object(x == (integer)(long)other);
			else if (other is double) return Ops.bool2object(x == (double)other);
			else if (other is integer) return Ops.bool2object((integer)x == (integer)other);
			else if (other is Complex64) return Ops.bool2object(x == (Complex64)other);

			return Ops.NotImplemented;
		}


		#region Generated LongOps
		
		public static object Add(integer x, object other) {
		    if (other is int) return x + ((int)other);
		    if (other is long) return x + ((long)other);
		    if (other is Complex64) return x +  ((Complex64)other);
		    if (other is double) return x +  ((double)other);
		    if (other is integer) return x +  ((integer)other);
		    return Ops.NotImplemented;
		}
		
		
		public static object Subtract(integer x, object other) {
		    if (other is int) return x - ((int)other);
		    if (other is long) return x - ((long)other);
		    if (other is Complex64) return x -  ((Complex64)other);
		    if (other is double) return x -  ((double)other);
		    if (other is integer) return x -  ((integer)other);
		    return Ops.NotImplemented;
		}
		
		
		public static object Power(integer x, object other) {
		    if (other is int) return Power(x, (int)other);
		    return Ops.NotImplemented;
		}
		
		
		public static object Multiply(integer x, object other) {
		    if (other is int) return x * ((int)other);
		    if (other is long) return x * ((long)other);
		    if (other is Complex64) return x *  ((Complex64)other);
		    if (other is double) return x *  ((double)other);
		    if (other is integer) return x *  ((integer)other);
		    return Ops.NotImplemented;
		}
		
		
		public static object FloorDivide(integer x, object other) {
		    if (other is int) return x / ((int)other);
		    if (other is long) return x / ((long)other);
		    if (other is Complex64) return x /  ((Complex64)other);
		    if (other is double) return x /  ((double)other);
		    if (other is integer) return x /  ((integer)other);
		    return Ops.NotImplemented;
		}
		
		
		public static object TrueDivide(integer x, object other) {
		    if (other is int) return TrueDivide(x, (int)other);
		    return Ops.NotImplemented;
		}
		
		
		public static object Mod(integer x, object other) {
		    if (other is int) return x % ((int)other);
		    if (other is long) return x % ((long)other);
		    if (other is Complex64) return x %  ((Complex64)other);
		    if (other is double) return x %  ((double)other);
		    if (other is integer) return x %  ((integer)other);
		    return Ops.NotImplemented;
		}
		
		
		public static object LeftShift(integer x, object other) {
		    if (other is int) return x << (int)other;
		    return Ops.NotImplemented;
		}
		
		
		public static object RightShift(integer x, object other) {
		    if (other is int) return x >> (int)other;
		    return Ops.NotImplemented;
		}
		
		
		public static object BitwiseAnd(integer x, object other) {
		    if (other is integer) return x & (integer)other;
			if (other is long) return x & (long)other;
		    if (other is int) return x & (int)other;
		    return Ops.NotImplemented;
		}
		
		
		public static object BitwiseOr(integer x, object other) {
		    if (other is integer) return x | (integer)other;
			if (other is long) return x | (long)other;
		    if (other is int) return x | (int)other;
		    return Ops.NotImplemented;
		}
		
		
		public static object Xor(integer x, object other) {
		    if (other is integer) return x ^ (integer)other;
			if (other is long) return x ^ (long)other;
		    if (other is int) return x ^ (int)other;
		    return Ops.NotImplemented;
		}
		
		#endregion
	}
}
