/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;
using System.IO;

using System.Reflection;

namespace IronPython.Objects {
	[PythonType("package#")]
	public class ReflectedPackage:ICustomAttributes {
		private static Dict dict = new Dict(100);
		//private static Dict types = new Dict(1000);

		//!!! This loads too many assemblies
		private static void LoadDir(string dirname, bool recurse) {
			foreach (string name in Directory.GetFiles(dirname, "*.dll")) {
				LoadAssemblyFromFile(name, true);
			}
			if (recurse) {
				foreach (string name in Directory.GetDirectories(dirname)) {
					LoadDir(name, true);
				}
			}
		}

		public static void LoadAssemblyFromFile(string name, bool failSilently) {
			//Console.Out.WriteLine("Loading: " + name);
			Assembly assem = null;
			try {
				assem = Assembly.LoadFrom(name);
			} catch {
				//Console.Out.WriteLine("Failed to load {0}", name);
			}
			if (assem == null) {
				if (failSilently) return;
				throw Ops.RuntimeError("Could not load assembly {0}", name);
			}
			InitAssembly(assem);
		}

		public static void LoadAssemblyWithPartialName(string name, bool failSilently) {
			Assembly assem = null;
			try {
				assem = Assembly.LoadWithPartialName(name);
			} catch {
				//Console.Out.WriteLine("Failed to load {0}", name);
			}
			if (assem == null) {
				if (failSilently) return;
				throw Ops.RuntimeError("Could not load assembly {0}", name);
			}
			InitAssembly(assem);
		}

		private static void InitAssembly(Assembly assem) {
            foreach (Type type in assem.GetTypes()) {
				if (type.Namespace == null) continue;
				ReflectedPackage p = GetOrMakeTopPackage(type.Namespace);
				p.__dict__[type.Name] = Ops.GetDynamicTypeFromType(type); //!!! maybe do this more lazily
			}
		}



		private static bool initialized = false;
		private static void Initialize() {
			if (initialized) return;
			initialized = true;

			LoadAssemblyWithPartialName("mscorlib", true);
			LoadAssemblyWithPartialName("System", true);
			LoadAssemblyWithPartialName("System.Drawing", true);
			LoadAssemblyWithPartialName("System.Windows.Forms", true);
			LoadAssemblyWithPartialName("System.Xml", true);

			LoadAssemblyWithPartialName("gtk-sharp", true);

//			Assembly a = Assembly.Load("mscorlib.dll");
//			InitAssembly(a);
//
//			//Console.WriteLine("dir: " + a.Location);
//
//			string dirname = Path.GetDirectoryName(a.Location);
//			LoadDir(dirname, false);
//
//			string gacname = Path.Combine(Path.Combine(dirname, "mono"), "gac");
//			if (Directory.Exists(gacname)) {
//				LoadDir(gacname, true);
//			}

			//LoadAssembly("AgentServerObjects");
			
//			Assembly.LoadFrom(Path.GetDirectoryName(a.Location)+"\\System.dll");
//			//Assembly.LoadFrom(Path.GetDirectoryName(a.Location)+"\\System.Drawing.dll");
//			//Assembly.LoadFrom(Path.GetDirectoryName(a.Location)+"\\System.Windows.Forms.dll");
//			Assembly.LoadFrom(Path.GetDirectoryName(a.Location)+"\\System.Xml.dll");
//			Assembly.LoadFrom(Path.GetDirectoryName(a.Location)+"\\AgentServerObjects.dll");
//			Assembly.LoadFrom(Path.GetDirectoryName(a.Location)+"\\AgentToy.dll");


			//Assembly.LoadFrom("C:\\Mono-1.0\\lib\\mono\\gtk-sharp\\gtk-sharp.dll");
		}

		private static ReflectedPackage GetOrMakePackage(string name, Dict dict) {
			ReflectedPackage ret;
			if (!dict.Contains(name)) {
				ret = new ReflectedPackage(name);
				dict[name] = ret;
			} else {
				ret = (ReflectedPackage)dict[name];
			}
			return ret;
		}

		private static ReflectedPackage GetOrMakeTopPackage(string ns) {
			//if (ns.StartsWith("System.Windows")) Console.WriteLine(ns);
			string[] pieces = ns.Split('.');
			ReflectedPackage ret = GetOrMakePackage(pieces[0], dict);
			
			for (int i=1; i < pieces.Length; i++) {
				ret = ret.GetOrMakePackage(pieces[i]);
			}
			return ret;
		}

		public static ReflectedPackage GetPackage(string name) {
			Initialize();
			return (ReflectedPackage)dict[name];
		}

		public Dict __dict__;
		public string __name__;
		public ReflectedPackage(string name) {
			__name__ = name;
			__dict__ = new Dict();
		}

		private ReflectedPackage GetOrMakePackage(string name) {
			return GetOrMakePackage(name, __dict__);
		}

		public override string ToString() {
			return string.Format("<package# '{0}'>", __name__);
		}

		#region ICustomAttributes Members

		public object __getattribute__(string name) {
			object ret = __dict__[name];
			if (ret == null) return Ops.Missing;
			return ret;
		}

		public void __setattr__(string name, object value) {
			__dict__[name] = value;
		}

		public void __delattr__(string name) {
			throw new NotImplementedException();
		}

		public List __attrs__() {
			return __dict__.keys();
		}

		#endregion
	}
}
