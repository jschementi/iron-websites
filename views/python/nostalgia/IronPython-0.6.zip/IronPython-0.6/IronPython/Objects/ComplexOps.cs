/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Text;
using System.Collections;

using IronMath;

namespace IronPython.Objects {
	public class ComplexOps {
		public static ReflectedType MakeDynamicType() {
			return new OpsReflectedType("complex", typeof(Complex64), typeof(ComplexOps), null); //!!!typeof(ExtensibleInt));
		}

		public static object Make(object o) {
			if (o is string) return LiteralParser.ParseImaginary((string)o);
			if (o is Complex64) return o;
			return Complex64.MakeReal(Ops.object2double(o));
		}

		public static object Make(double r, double i) {
			return new Complex64(r, i);
		}

		private static object TrueDivide(Complex64 x, Complex64 y) {
			return x / y;
		}

		public static object Abs(Complex64 x) {
			return x.Abs();
		}

		private static object Power(Complex64 x, Complex64 y) {
			throw new NotImplementedException();
		}

		public static object Divide(Complex64 x, object other) {
			return TrueDivide(x, (Complex64)other);
		}

		public static object Equals(Complex64 x, object other) {
			if (other is int) return Ops.bool2object(x == (int)other);
			else if (other is double) return Ops.bool2object(x == (double)other);
			else if (other is integer) return Ops.bool2object(x == (integer)other);
			else if (other is Complex64) return Ops.bool2object(x == (Complex64)other);

			return Ops.NotImplemented;
		}

		#region Generated ComplexOps
		
		public static object Add(Complex64 x, object other) {
		    if (other is int) return x + ((int)other);
		    if (other is long) return x + ((long)other);
		    if (other is Complex64) return x +  ((Complex64)other);
		    if (other is double) return x +  ((double)other);
		    if (other is integer) return x +  ((integer)other);
		    return Ops.NotImplemented;
		}
		
		
		public static object Subtract(Complex64 x, object other) {
		    if (other is int) return x - ((int)other);
		    if (other is long) return x - ((long)other);
		    if (other is Complex64) return x -  ((Complex64)other);
		    if (other is double) return x -  ((double)other);
		    if (other is integer) return x -  ((integer)other);
		    return Ops.NotImplemented;
		}
		
		
		public static object Power(Complex64 x, object other) {
		    if (other is int) return Power(x , ((int)other));
		    if (other is long) return Power(x , ((long)other));
		    if (other is Complex64) return Power(x , ((Complex64)other));
		    if (other is double) return Power(x ,((double)other));
		    if (other is integer) return Power(x , ((integer)other));
		    return Ops.NotImplemented;
		}
		
		
		public static object Multiply(Complex64 x, object other) {
		    if (other is int) return x * ((int)other);
		    if (other is long) return x * ((long)other);
		    if (other is Complex64) return x *  ((Complex64)other);
		    if (other is double) return x *  ((double)other);
		    if (other is integer) return x *  ((integer)other);
		    return Ops.NotImplemented;
		}
		
		
		public static object FloorDivide(Complex64 x, object other) {
		    if (other is int) return x / ((int)other);
		    if (other is long) return x / ((long)other);
		    if (other is Complex64) return x /  ((Complex64)other);
		    if (other is double) return x /  ((double)other);
		    if (other is integer) return x /  ((integer)other);
		    return Ops.NotImplemented;
		}
		
		
		public static object TrueDivide(Complex64 x, object other) {
		    if (other is int) return x / ((int)other);
		    if (other is long) return x / ((long)other);
		    if (other is Complex64) return x /  ((Complex64)other);
		    if (other is double) return x /  ((double)other);
		    if (other is integer) return x /  ((integer)other);
		    return Ops.NotImplemented;
		}
		
		
		public static object Mod(Complex64 x, object other) {
		    if (other is int) return x % ((int)other);
		    if (other is long) return x % ((long)other);
		    if (other is Complex64) return x %  ((Complex64)other);
		    if (other is double) return x %  ((double)other);
		    if (other is integer) return x %  ((integer)other);
		    return Ops.NotImplemented;
		}
		
		#endregion
	}
}
