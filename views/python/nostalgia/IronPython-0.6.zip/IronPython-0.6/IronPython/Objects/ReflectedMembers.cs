/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Reflection;
using System.Collections;
using System.Collections.Specialized;


using IronPython.AST;
using IronPython.Modules;
using IronMath;

namespace IronPython.Objects {

	public abstract class ReflectedMethodBase:ICallable {
		private static int totalReflectedCalls = 0;
		private static Dict reflectedCalls = new Dict();

		public static void DumpReflectedCalls() {
			const double CALL_TIME = 20e-6;
			const double THROW_TIME = 12e-6;
			List items = reflectedCalls.items();
			items.sort();
			foreach (object item in items) {
				Console.WriteLine(item.ToString());
			}
			if (totalReflectedCalls > 0) {
				Console.WriteLine("Total reflected calls = {0} (~{1} secs)", totalReflectedCalls, totalReflectedCalls*CALL_TIME);
			}
//			if (PythonExceptionNew.count > 0) {
//				Console.WriteLine("Total PythonExceptions = {0} (~{1} secs)", PythonExceptionNew.count, PythonExceptionNew.count*THROW_TIME);
//			}
		}

		public static void NoteCall(object key) {
			if (!Options.TRACK_REFLECT_CALLS) return;
			totalReflectedCalls++;
			string name = key.ToString();
			object v = reflectedCalls[name];
			if (v == null) reflectedCalls[name] = 1;
			else reflectedCalls[name] = ((int)v) + 1;
		}

		private void NoteCall() {
			NoteCall(this);
		}


		internal MethodBase[] infos;

		protected ReflectedMethodBase(MethodBase[] infos) {
			this.infos = infos;
		}

		protected ReflectedMethodBase(MethodBase info): this(new MethodBase[] {info}) { }

		public string __name__ {
			get { return infos[0].Name; }
		}

		public int GetMaxArgs() {
			int maxArgs = 0;
			foreach (MethodBase mi in infos) {
				maxArgs = Math.Max(maxArgs, mi.GetParameters().Length);
			}
			return maxArgs;
		}


		public void Add(MethodBase info) {
			MethodBase[] ni = new MethodBase[infos.Length+1];
			infos.CopyTo(ni, 0);
			ni[infos.Length] = info;
			infos = ni;
		}

		protected abstract object GetInstance();

		#region ICallable Members

		public static bool IsParamArray(ParameterInfo pi) {
			return pi.IsDefined(typeof(ParamArrayAttribute), false);
		}

		//??? These helper methods might be faster if we used a special structure to cache their results
		private object[] BindArgs(MethodBase info, ref object instance, object[] args) {
			ParameterInfo[] pis = info.GetParameters();
			object[] ret = new object[pis.Length];

			int argi = 0;

			if (info.IsStatic) {
				instance = null;
			} else if (info.IsConstructor) {
				instance = null;
			} else if (instance == null) {
				if (!Ops.ConvertTo(args[argi++], info.DeclaringType, out instance)) return null;
			}

			for (int parami = 0; parami < pis.Length; parami++) {
				ParameterInfo pi = pis[parami];
				if (pi.IsOut) continue;  //??? arrays are filled with null on initialization

				if (IsParamArray(pi)) {
					//!!! add error checking and non-object arrays
					object[] parg = new object[args.Length-argi];
					int i=0;
					while (argi < args.Length) parg[i++] = args[argi++];
					ret[parami] = parg;
					continue;
				}
				if (argi >= args.Length) {
					if (pi.DefaultValue == DBNull.Value) return null;
					else ret[parami] = pi.DefaultValue;
				} else {
					if (!Ops.ConvertTo(args[argi++], pi.ParameterType, out ret[parami])) return null;
				}
			}

			if (argi == args.Length) return ret;
			else return null;
		}

		private int CountByRefs(ParameterInfo[] pis) {
			int ret = 0;
			foreach(ParameterInfo pi in pis) {
				if (pi.ParameterType.IsByRef) ret++;
			}
			return ret;
		}

		private object MakeReturnValue(MethodBase info, object ret, object[] args) {
			int byRefCount = CountByRefs(info.GetParameters());
			if (byRefCount == 0) return Ops.ToPython(ReflectOptimizer.GetReturnType(info), ret);

			int retValueIndex = 0;
			object[] retValues;

			if (info is MethodInfo && ((MethodInfo)info).ReturnType != typeof(void)) {
				retValues = new object[byRefCount+1];
				retValues[retValueIndex++] = Ops.ToPython(ReflectOptimizer.GetReturnType(info), ret);
			} else {
				retValues = new object[byRefCount];
			}

			ParameterInfo[] pis = info.GetParameters();
			for (int i=0; i < pis.Length; i++) {
				if (pis[i].ParameterType.IsByRef) {
					retValues[retValueIndex++] = Ops.ToPython(pis[i].ParameterType, args[i]);
				}
			}

			if (retValues.Length == 1) return retValues[0];
			return Tuple.MakeTuple(retValues);
		}

		public virtual object Call(params object[] args) {
			NoteCall();
			//Console.WriteLine("calling reflected: " + this);
			//!!! this code assumes that infos have been sorted
			foreach (MethodBase info in infos) {
				object instance = GetInstance();
				object[] oargs = BindArgs(info, ref instance, args);
				if (oargs != null) {
					object ret;
					try {
						if (info is ConstructorInfo) {
							ret = ((ConstructorInfo)info).Invoke(oargs);
						} else {
							ret = info.Invoke(instance, oargs);
						}
					} catch (TargetInvocationException tie) {
						throw tie.InnerException;
					}
					return MakeReturnValue(info, ret, oargs);
				}
			}

			throw new Exception(string.Format("bad args to this method {0}", this));
		}
		#endregion
	}


	public class ReflectedConstructor:ReflectedMethodBase {
		public ReflectedConstructor(ConstructorInfo info):base(info) { }

		protected override object GetInstance() { return null; }

		public override string ToString() {
			return string.Format("<constructor# for {0}>", infos[0].DeclaringType.FullName);
		}

	}

	public class ReflectedMethod:ReflectedMethodBase,IDescriptor {
		public readonly object instance;

		public ReflectedMethod(MethodInfo info): base(info) { }

		protected ReflectedMethod(MethodBase[] infos, object instance): base(infos) {
			this.instance = instance;
		}

		protected override object GetInstance() { return instance; }

		public override string ToString() {
			return string.Format("<method# {0} on {1}>", ((MethodInfo)infos[0]).Name, infos[0].DeclaringType.FullName);
		}

		#region IDescriptor Members

		public virtual object __get__(object instance, object context) {
			if (instance != null) {
				return new ReflectedMethod(infos, instance);
			} else {
				return this;
			}
		}

		#endregion
	}

	
	public class ReflectedField:IDataDescriptor {
		public readonly FieldInfo info;

		public ReflectedField(FieldInfo info) {
			this.info = info;
		}

		public object __get__(object instance, object context) {
			ReflectedMethodBase.NoteCall(this);
			if (instance == null) {
				if (info.IsStatic) return Ops.ToPython(info.GetValue(null));
				else return this;
			} else {
				return Ops.ToPython(info.GetValue(instance)); //.toObject(info.DeclaringType, "get ")));
			}
		}

		private void DoSet(object instance, object val) {
			ReflectedMethodBase.NoteCall(this);
			info.SetValue(instance, Ops.ConvertTo(val, info.FieldType)); //val.toObject(info.FieldType, "set "));
		}

		public void __set__(object instance, object value) {
			if (instance == null) {
				if (info.IsStatic) {
					DoSet(null, value);
				} else {
					throw Ops.TypeError("instance field");
				}
			} else {
				DoSet(instance, value); //.toObject(info.DeclaringType, "set "), val);
			}
		}

		public void __delete__(object instance) {
			throw Ops.TypeError("can't delete field on built-in object");
		}

		public override string ToString() {
			return string.Format("<field# {0} on {1}>", info.Name, info.DeclaringType.Name);
		}
	}


	public class ReflectedProperty:IDataDescriptor {
		public readonly PropertyInfo info;

		public ReflectedProperty(PropertyInfo info) {
			this.info = info;
		}

		public object __get__(object instance, object context) {
			ReflectedMethodBase.NoteCall(this);
			if (!info.CanRead) throw Ops.TypeError("writeonly attribute");
			if (instance == null) {
				if (info.GetGetMethod().IsStatic) return Ops.ToPython(info.GetGetMethod().Invoke(null, new object[0]));
				else return this;
			} else {
				return Ops.ToPython(info.GetGetMethod().Invoke(instance, new object[0]));
			}
		}

		private void DoSet(object instance, object val) {
			ReflectedMethodBase.NoteCall(this);
			if (!info.CanWrite) throw Ops.TypeError("readonly attribute");
			info.GetSetMethod().Invoke(instance,
				new object[] {Ops.ConvertTo(val, info.PropertyType)});
		}

		public void __set__(object instance, object value) {
			if (instance == null) {
				if (info.GetSetMethod().IsStatic) {
					DoSet(null, value);
				} else {
					throw Ops.TypeError("instance property");
				}
			} else {
				DoSet(instance, value); //.toObject(info.DeclaringType, "set "), val);
			}
		}

		public void __delete__(object instance) {
			throw Ops.TypeError("can't delete property on built-in object");
		}

		public override string ToString() {
			return string.Format("<property# {0} on {1}>", info.Name, info.DeclaringType.Name);
		}
	}

	[PythonType("event#")]
	public class ReflectedEvent:IDescriptor {
		public readonly EventInfo info;
		//public readonly Type eventHandlerType;  //!!!TODO
		public readonly object instance;


		public ReflectedEvent(EventInfo info, object instance) {
			this.info = info;
			//info.EventHandlerType = DelegateMaker.MakeDelegateType(info.EventHandlerType);
			this.instance = instance;
		}

		public object __iadd__(object func) {
			Delegate handler = func as Delegate;
			if (handler == null) {
				PythonEventHandler peh = new PythonEventHandler(func); //eventHandlerType.GetConstructor(new Type[] { typeof(object)}).Invoke(new object[] {instance});
				handler = Delegate.CreateDelegate(info.EventHandlerType, peh, "Handle");
			}
			info.AddEventHandler(instance, handler);
			return null;
		}

		public object __get__(object instance, object context) {
			if (instance != null) {
				return new ReflectedEvent(info, instance);
			} else {
				return this;
			}
		}

		public override string ToString() {
			return string.Format("<event# {0} on {1}>", info.Name, info.DeclaringType.Name);
		}
	}

	public class PythonEventHandler {
		protected object func;
		public PythonEventHandler(object func) {
			this.func = func;
		}

		public void Handle() {
			Ops.Call(func);
		}

		public void Handle(object sender, EventArgs e) {
			Ops.Call(func, sender, e);
		}
	}
}
