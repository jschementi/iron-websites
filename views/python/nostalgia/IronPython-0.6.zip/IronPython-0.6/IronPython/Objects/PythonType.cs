/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;

using System.Collections;
using System.Reflection;

namespace IronPython.Objects
{
	/// <summary>
	/// Summary description for PythonType.
	/// </summary>
	[PythonType("type")]
	public abstract class PythonType:DynamicType,IDynamicObject,ICallable,ICustomAttributes {
		public static object Make(object metaclass, string name, Tuple bases, IDictionary dict) {
			//!!!
			return UserType.MakeClass("<unknown>", name, bases, dict);
		}

		public static object Make(object o) {
			return Ops.GetDynamicType(o);
		}

		//public object __new__;
		public ICallable init = null;
		private List subclasses = new List();
		public readonly Type type;
		public Dict dict;


		public MethodWrapper __getitem__F;
		public MethodWrapper __setitem__F; // = new MethodWrapper(new MethodWrapperGetter(get__setitem__));
//		//public static MethodWrapper get__setitem__(PythonType pt) { return pt.__setitem__F; }
//
		public MethodWrapper __cmp__F;

		public MethodWrapper __repr__F;
		public MethodWrapper __str__F;
		
		public MethodWrapper __getattribute__F;
		public MethodWrapper __getattr__F;
		public MethodWrapper __setattr__F;


		public PythonType(Type type) {
			this.type = type;
		}

		internal static int GetMaxArgs(ICallable c) {
			if (c is ReflectedMethodBase) return ((ReflectedMethodBase)c).GetMaxArgs();
			else if (c is BuiltinFunction) return ((BuiltinFunction)c).GetMaxArgs();
			else return 10;
		}

		public virtual void Initialize() { }

		protected void AddProtocolWrappers() {
			if (type == typeof(object)) {
				AddProtocolWrappersForObject();
				return;
			}

			__getitem__F = MethodWrapper.Make(this, "__getitem__");
			__setitem__F = MethodWrapper.Make(this, "__setitem__");
			
			__getattribute__F = MethodWrapper.Make(this, "__getattribute__");
			__getattr__F = MethodWrapper.Make(this, "__getattr__");
			__setattr__F = MethodWrapper.Make(this, "__setattr__");

			__cmp__F = MethodWrapper.Make(this, "__cmp__");
			__repr__F = MethodWrapper.Make(this, "__repr__");
			__str__F = MethodWrapper.Make(this, "__str__");
		}

		protected void AddProtocolWrappersForObject() {
			__getitem__F = MethodWrapper.MakeUndefined(this, "__getitem__");
			__setitem__F = MethodWrapper.MakeUndefined(this, "__setitem__");

			__getattribute__F = MethodWrapper.MakeForObject(this, "__getattribute__", new CallTarget2(GetAttributeMethod));
			__getattr__F = MethodWrapper.MakeUndefined(this, "__getattr__");
			__setattr__F = MethodWrapper.MakeForObject(this, "__setattr__", new CallTarget3(SetAttrMethod));

			__cmp__F = MethodWrapper.MakeUndefined(this, "__cmp__"); //!!!
			__str__F = MethodWrapper.MakeForObject(this, "__str__", new CallTarget1(StrMethod));
			__repr__F = MethodWrapper.MakeForObject(this, "__repr__", new CallTarget1(ReprMethod));
		}

		public static object ReprMethod(object self) {
			return string.Format("<{0} object at {1}>", Ops.GetDynamicType(self).__name__, Ops.HexId(self));
		}

		public static object StrMethod(object self) {
			return Ops.Repr(self);
		}

		public static object GetAttributeMethod(object self, object name) {
			ISuperDynamicObject s = self as ISuperDynamicObject;
			if (s != null) {
				object ret;
				if (((UserType)s.GetDynamicType()).BaseGetAttr(s, (string)name, out ret)) return ret;
			}
//			ICustomAttributes ca = self as ICustomAttributes;
//			if (ca != null) {
//				object ret = ca.__getattribute__((string)name);
//				if (ret != Ops.Missing) return ret;
//			}
			throw Ops.AttributeError("no attribute {0}", name); //??? better message
		}

		public static object SetAttrMethod(object self, object name, object value) {
			ISuperDynamicObject s = self as ISuperDynamicObject;
			if (s == null) throw new NotImplementedException();
			((UserType)s.GetDynamicType()).BaseSetAttr(s, (string)name, value);
			return null;
		}


		public List __subclasses__() {
			return subclasses;
		}

		public virtual Tuple __bases__ {
			get { throw new NotImplementedException(); }
			set { throw new NotImplementedException(); }
		}

		public virtual Type GetTypeToExtend() {
			return type;
		}

		public void AddSubclass(PythonType subclass) {
			subclasses.Add(subclass);
			//!!! propogation is needed
		}

		//!!! this should be field specific
		public void UpdateFromBases() {
			__getitem__F.UpdateFromBases(__bases__);
			__setitem__F.UpdateFromBases(__bases__);
			
			__getattribute__F.UpdateFromBases(__bases__);
			__getattr__F.UpdateFromBases(__bases__);
			__setattr__F.UpdateFromBases(__bases__);

			__cmp__F.UpdateFromBases(__bases__);
			__repr__F.UpdateFromBases(__bases__);
			__str__F.UpdateFromBases(__bases__);
		}

		public void UpdateSubclasses() {
			foreach (PythonType pt in subclasses) {
				pt.UpdateFromBases();
				pt.UpdateSubclasses();
			}
		}


		protected object LookupSlot(string name) {
			object slot = RawGetSlot(name);
			if (slot != null) return slot;
			return LookupSlotInBases(name);
		}

		internal object LookupSlotInBases(string name) {
			
			object ret = null;
			foreach (PythonType rt in __bases__) {
				object slot = rt.LookupSlot(name);
				if (slot != null) {
					ret = slot; //!!! using last overriding MRO rule here, need real MRO
				}
			}
			return ret;
		}

		//!!! uses null to signal not found
		internal object RawGetSlot(string name) {
			Initialize();

			if ((object)name == (object)"__dict__") { return dict; }

			if ((object)name == (object)"__getattribute__") { return __getattribute__F; }
			if ((object)name == (object)"__getattr__") { return __getattr__F; }
			if ((object)name == (object)"__setattr__") { return __setattr__F; }
			if ((object)name == (object)"__cmp__") { return __cmp__F; }
			if ((object)name == (object)"__repr__") { return __repr__F; }
			//if ((object)name == (object)"__setitem__" && !__setitem__F.IsSuperTypeMethod()) { return __setitem__F; }

			//??? order is weird
			object ret = dict[name];
			if (ret != null) return ret;
			
			return null;
		}

		protected virtual void RawSetSlot(string name, object value) {
			dict[name] = value;
		}

//		internal void RawSetSlot(string name, object value) {
//			Initialize();
//			dict[name] = value;
//		}
//
//		internal void RawRemoveSlot(string name) {
//			Initialize();
//			dict.Remove(name);
//		}
	
		public virtual object Call(params object[] args) { throw new NotImplementedException(); }
		public virtual DynamicType GetDynamicType() { throw new NotImplementedException(); }

		public override string Repr(object self) {
			//!!!
			Initialize();
			return (string)__repr__F.Invoke(self);
		}


		#region ICustomAttributes Members

		public object __getattribute__(string name) {
			if (name == "__subclasses__") {
				//!!! super expensive
				return new ReflectedMethod(typeof(ReflectedType).GetMethod("__subclasses__")).__get__(this, null);
			}
			object slot = LookupSlot(name); //???RawGetSlot(name);
			if (slot != null) {
				return Ops.GetDescriptor(slot, null, this);
			}

			if (name == "__name__") { return __name__; }
			if (name == "__bases__") { return __bases__; }

			return Ops.Missing;
		}

		public void __setattr__(string name, object value) {
			if (name == "__bases__") __bases__ = (Tuple)value;
			//			if (name == "__bases__") { __bases__ = (Tuple)value; return;}
			//			if (name == "__getattribute__") { __getattribute__ = value; return; }
			//			if (name == "__setattr__") { __setattr__ = value; return; }
			//			if (name == "__cmp__") { __cmp__ = value; return; }
			//			if (name == "__setitem__") { __setitem__ = value; return; }


			object slot = RawGetSlot(name);
			if (slot != null) {
				if (Ops.SetDescriptor(slot, null, value)) return;
			}

			RawSetSlot(name, value);
		}


		public void __delattr__(string name) {
//			if (name == "__getattribute__") { __getattribute__ = null; return; }
//			if (name == "__setattr__") { __setattr__ = null; return; }

			object slot = RawGetSlot(name);
			if (slot != null) {
				if (Ops.DelDescriptor(slot, null)) return;
			} 

			//!!! do something here
//			if (isUserType) {
//				RawRemoveSlot(name);
//			} else {
//				throw Ops.TypeError("can't del attributes of built-in/extension type '{0}'", __name__);
//			}	
		}

		public List __attrs__() {
			Initialize();
			List ret = dict.keys();
			ret.sort();
			return ret;
		}

		#endregion

		public override List GetAttrNames(object self) {
			return __attrs__(); //??? my object has my attrs
		}

	}

	public delegate MethodWrapper MethodWrapperGetter(PythonType pt);

	public class MethodWrapper:ICallable,IDataDescriptor {
		FieldInfo myField;
		private PythonType pythonType;
		private string name;

		private bool isObjectMethod, isBuiltinMethod, isSuperTypeMethod;
		private object func = null;
		private Function funcAsFunc = null;

		public static MethodWrapper Make(PythonType pt, string name) {
			MethodWrapper ret = new MethodWrapper(pt, name);
			if (pt.dict.Contains(name)) {
				ret.SetDeclaredMethod(pt.dict[name]);
			} else {
				ret.UpdateFromBases(pt.__bases__);
			}

			//pt.dict[name] = ret; //???

			return ret;
		}

		public static MethodWrapper MakeUndefined(PythonType pt, string name) {
			return new MethodWrapper(pt, name);
		}

		public static MethodWrapper MakeForObject(PythonType pt, string name, Delegate func) {
			MethodWrapper ret = new MethodWrapper(pt, name);
			ret.isObjectMethod = true;
			ret.isBuiltinMethod = true;
			ret.isSuperTypeMethod = false;

			ret.func = BuiltinFunction.FromDelegate(func);
			ret.funcAsFunc = ret.func as Function;

			//pt.dict[name] = ret;

			return ret;
		}

		//public static MethodWrapper MakeDefault() { return new MethodWrapper(null, true, true); }

		public MethodWrapper(PythonType pt, string name) {
			this.pythonType = pt;
			this.name = name;
			this.myField = typeof(PythonType).GetField(name+"F");
			this.isObjectMethod = true;
			this.isBuiltinMethod = true;
			this.isSuperTypeMethod = true;
		}

		public void SetDeclaredMethod(object m) {
			//Console.WriteLine("set declared {0} as {1} on {2}", m, name, pythonType);
			this.func = m;
			this.funcAsFunc = m as Function;
			this.isObjectMethod = pythonType.type == typeof(object);
			this.isBuiltinMethod = pythonType is ReflectedType;
			this.isSuperTypeMethod = false;

			//!!! the dictionary should be bound to this in a more sophisticated way
			pythonType.dict[this.name] = m;
		}



		public void UpdateFromBases(Tuple bases) {
			if (!isSuperTypeMethod) return;

			foreach (PythonType baseType in bases) {
				baseType.Initialize();
				//!!! do MRO thing here
				UpdateFromBase((MethodWrapper)myField.GetValue(baseType));
			}
		}

		private void UpdateFromBase(MethodWrapper mw) {
			//if (mw == null) return; //!!!
			func = mw.func;
			funcAsFunc = mw.func as Function;
			isObjectMethod = mw.isObjectMethod;
			isBuiltinMethod = mw.isBuiltinMethod;
			isSuperTypeMethod = true;
		}

		public object Invoke(object self) {
			if (func == null) throw Ops.AttributeError("{0} not defined on instance of {1}", name, pythonType.__name__);
			if (funcAsFunc != null) return funcAsFunc.Call(self);
			return Ops.Call(Ops.GetDescriptor(func, self, pythonType));
		}
		public object Invoke(object self, object arg1) {
			if (func == null) throw Ops.AttributeError("{0} not defined on instance of {1}", name, pythonType.__name__);
			if (funcAsFunc != null) return funcAsFunc.Call(self, arg1);
			return Ops.Call(Ops.GetDescriptor(func, self, pythonType), arg1);
		}
		public object Invoke(object self, object arg1, object arg2) {
			if (func == null) throw Ops.AttributeError("{0} not defined on instance of {1}", name, pythonType.__name__);
			if (funcAsFunc != null) return funcAsFunc.Call(self, arg1, arg2);
			return Ops.Call(Ops.GetDescriptor(func, self, pythonType), arg1, arg2);
		}

//		public object Invoke(params object[] args) {
//			if (func == null) throw Ops.AttributeError("{0} not defined on instance of {1}", name, pythonType.__name__);
//			return Ops.Call(func, args); //!!! all sorts of binding questions
//		}

		public bool IsObjectMethod() {
			return isObjectMethod;
		}

		public bool IsBuiltinMethod() {
			return isBuiltinMethod;
		}

		public bool IsSuperTypeMethod() {
			return isSuperTypeMethod;
		}


		#region ICallable Members

		public object Call(params object[] args) {
			if (func == null) throw Ops.AttributeError("{0} not defined on instance of {1}", name, pythonType.__name__);
			return Ops.Call(func, args);
		}

		#endregion

		#region IDataDescriptor Members

		public object __get__(object instance, object owner) {
			if (func == null) throw Ops.AttributeError("{0} not defined on instance of {1}", name, pythonType.__name__);
			if (instance != null) return new Method(func, instance);
			else return func;
		}

		public void __set__(object instance, object value) {
			SetDeclaredMethod(value);
			pythonType.UpdateSubclasses();
		}
		public void __delete__(object instance) {
			if (isSuperTypeMethod) {
				throw new NotImplementedException();
			}

			func = null;
			funcAsFunc = null;
			isSuperTypeMethod = true;
			this.UpdateFromBases(pythonType.__bases__);
			pythonType.UpdateSubclasses();
		}

		#endregion
	}

}
