/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Text;

namespace IronPython.Objects {
	[PythonType("super")]
	public class Super:IDynamicObject,ICustomAttributes {
		public readonly PythonType __thisclass__;
		public readonly object __self__;

		public Super(PythonType thisclass): this(thisclass, null) {}
		public Super(PythonType thisclass, object self) {
			this.__thisclass__ = thisclass;
			this.__self__ = self;
		}

		public override string ToString() {
			return string.Format("<super: {0}, {1}>", Ops.StringRepr(__thisclass__), Ops.StringRepr(__self__));
		}


		#region ICustomAttributes Members

		public object __getattribute__(string name) {
			object slot = __thisclass__.LookupSlotInBases(name);
			if (slot != null) {
				return Ops.GetDescriptor(slot, __self__, this);
			}
			return Ops.Missing;
		}

		public void __setattr__(string name, object value) {
			throw new NotImplementedException();
		}


		public void __delattr__(string name) {
			throw new NotImplementedException();
		}

		public List __attrs__() {
			throw new NotImplementedException();
		}

		#endregion

		#region IDynamicObject Members
		public DynamicType GetDynamicType() {
			return Ops.GetDynamicTypeFromType(typeof(Super));
		}
		#endregion
	}
}
