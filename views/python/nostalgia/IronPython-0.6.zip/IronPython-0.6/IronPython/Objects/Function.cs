/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;
using System.Collections.Specialized;

using System.Reflection;

using IronPython.AST;

namespace IronPython.Objects {

	public delegate object CallTargetN(params object[] args);

	#region Generated CallTargets
	public delegate object CallTarget0();
	public delegate object CallTarget1(object arg0);
	public delegate object CallTarget2(object arg0, object arg1);
	public delegate object CallTarget3(object arg0, object arg1, object arg2);
	public delegate object CallTarget4(object arg0, object arg1, object arg2, object arg3);
	#endregion

	#region Generated FunctionNs
	[PythonType(typeof(Function))]
	public class Function0:Function {
	    private CallTarget0 target;
	    public Function0(module globals, string name, CallTarget0 target, string[] argNames, object[] defaults): base(globals, name, argNames, defaults) {
	        this.target = target;
	    }
	    public override MethodInfo GetMethod() { return target.Method; }
	    public override object Call() {
	        return target();
	    }
	    public override object Call(params object[] args) {
	        switch(args.Length) {
	            case 0: return Call();
	            default: throw badArgCount(args.Length);
	        }
	    }
	}
	[PythonType(typeof(Function))]
	public class Function1:Function {
	    public CallTarget1 target;
	    public Function1(module globals, string name, CallTarget1 target, string[] argNames, object[] defaults): base(globals, name, argNames, defaults) {
	        this.target = target;
	    }
	    public override MethodInfo GetMethod() { return target.Method; }
	    public override object Call() {
	        if (defaults.Length >= 1) return target(defaults[defaults.Length-1]);
	        else throw badArgCount(0);
	    }
	    public override object Call(object arg0) {
			PushFrame();
			try {
				return target(arg0);
			} finally {
				PopFrame();
			}
	    }
	    public override object Call(params object[] args) {
	        switch(args.Length) {
	            case 0: return Call();
	            case 1: return Call(args[0]);
	            default: throw badArgCount(args.Length);
	        }
	    }
	}
	[PythonType(typeof(Function))]
	public class Function2:Function {
	    public CallTarget2 target;
	    public Function2(module globals, string name, CallTarget2 target, string[] argNames, object[] defaults): base(globals, name, argNames, defaults) {
	        this.target = target;
	    }
	    public override MethodInfo GetMethod() { return target.Method; }
	    public override object Call() {
	        if (defaults.Length >= 2) return target(defaults[defaults.Length-2], defaults[defaults.Length-1]);
	        else throw badArgCount(0);
	    }
	    public override object Call(object arg0) {
	        if (defaults.Length >= 1) return target(arg0, defaults[defaults.Length-1]);
	        else throw badArgCount(1);
	    }
	    public override object Call(object arg0, object arg1) {
			PushFrame();
			try {
				return target(arg0, arg1);
			} finally {
				PopFrame();
			}
	    }
	    public override object Call(params object[] args) {
	        switch(args.Length) {
	            case 0: return Call();
	            case 1: return Call(args[0]);
	            case 2: return Call(args[0], args[1]);
	            default: throw badArgCount(args.Length);
	        }
	    }
	}
	[PythonType(typeof(Function))]
	public class Function3:Function {
	    private CallTarget3 target;
	    public Function3(module globals, string name, CallTarget3 target, string[] argNames, object[] defaults): base(globals, name, argNames, defaults) {
	        this.target = target;
	    }
	    public override MethodInfo GetMethod() { return target.Method; }
	    public override object Call() {
	        if (defaults.Length >= 3) return target(defaults[defaults.Length-3], defaults[defaults.Length-2], defaults[defaults.Length-1]);
	        else throw badArgCount(0);
	    }
	    public override object Call(object arg0) {
	        if (defaults.Length >= 2) return target(arg0, defaults[defaults.Length-2], defaults[defaults.Length-1]);
	        else throw badArgCount(1);
	    }
	    public override object Call(object arg0, object arg1) {
	        if (defaults.Length >= 1) return target(arg0, arg1, defaults[defaults.Length-1]);
	        else throw badArgCount(2);
	    }
	    public override object Call(object arg0, object arg1, object arg2) {
	        return target(arg0, arg1, arg2);
	    }
	    public override object Call(params object[] args) {
	        switch(args.Length) {
	            case 0: return Call();
	            case 1: return Call(args[0]);
	            case 2: return Call(args[0], args[1]);
	            case 3: return Call(args[0], args[1], args[2]);
	            default: throw badArgCount(args.Length);
	        }
	    }
	}
	[PythonType(typeof(Function))]
	public class Function4:Function {
	    private CallTarget4 target;
	    public Function4(module globals, string name, CallTarget4 target, string[] argNames, object[] defaults): base(globals, name, argNames, defaults) {
	        this.target = target;
	    }
	    public override MethodInfo GetMethod() { return target.Method; }
	    public override object Call() {
	        if (defaults.Length >= 4) return target(defaults[defaults.Length-4], defaults[defaults.Length-3], defaults[defaults.Length-2], defaults[defaults.Length-1]);
	        else throw badArgCount(0);
	    }
	    public override object Call(object arg0) {
	        if (defaults.Length >= 3) return target(arg0, defaults[defaults.Length-3], defaults[defaults.Length-2], defaults[defaults.Length-1]);
	        else throw badArgCount(1);
	    }
	    public override object Call(object arg0, object arg1) {
	        if (defaults.Length >= 2) return target(arg0, arg1, defaults[defaults.Length-2], defaults[defaults.Length-1]);
	        else throw badArgCount(2);
	    }
	    public override object Call(object arg0, object arg1, object arg2) {
	        if (defaults.Length >= 1) return target(arg0, arg1, arg2, defaults[defaults.Length-1]);
	        else throw badArgCount(3);
	    }
	    public override object Call(object arg0, object arg1, object arg2, object arg3) {
	        return target(arg0, arg1, arg2, arg3);
	    }
	    public override object Call(params object[] args) {
	        switch(args.Length) {
	            case 0: return Call();
	            case 1: return Call(args[0]);
	            case 2: return Call(args[0], args[1]);
	            case 3: return Call(args[0], args[1], args[2]);
	            case 4: return Call(args[0], args[1], args[2], args[3]);
	            default: throw badArgCount(args.Length);
	        }
	    }
	}
	#endregion

	[PythonType("function")]
	public abstract class Function:IFastCallable,IFancyCallable,IDescriptor {
		//!!! cheating badly
		private static int depth = 0;
		private static int MAX_DEPTH = 1010;
		protected void PushFrame() {
			depth++;
			if (depth > MAX_DEPTH) throw Ops.RuntimeError("maximum recursion depth exceeded");
		}

		protected void PopFrame() {
			depth--;
		}


		public string[] argNames;
		//public PyTuple func_defaults;
		private string name;
		public object __doc__;
		private module func_module;

		//public PyObject __doc__ = PyString.intern("");

		//public PyObject func_code = Py.None;
		//!!! func_code

		//!!! reconcile with func_defaults
		protected readonly object[] defaults;

		public Function(module globals, string name, string[] argNames, object[] defaults) {
			this.argNames = argNames;
			this.defaults = defaults;
			this.name = name;

			this.func_module = globals;
		}

		public object func_globals {
			get { return func_module.__dict__; }
		}

		public string func_name { get { return name; } }
		public string __name__ { get { return name; } }

		public object func_doc { get { return __doc__; } }

		protected Exception badArgCount(int count) {
			//!!! include defaults and other info in this message
			throw Ops.TypeError("{0}() takes exactly {1} argument ({2} given)", name, argNames.Length, count);
		}

		public abstract MethodInfo GetMethod();





		#region IFastCallable Members

		public virtual object Call() {
			throw badArgCount(0);
		}

		public virtual object Call(object arg0) {
			throw badArgCount(1);
		}

		public virtual object Call(object arg0, object arg1) {
			throw badArgCount(2);
		}

		public virtual object Call(object arg0, object arg1, object arg2) {
			throw badArgCount(3);
		}

		public virtual object Call(object arg0, object arg1, object arg2, object arg3) {
			throw badArgCount(4);
		}

		#endregion

		#region ICallable Members

		public virtual object Call(params object[] args) {
			throw new NotImplementedException();
		}

		#endregion


		protected int FindParamIndex(string name) {
			for (int i=0; i < argNames.Length; i++) {
				if (name == argNames[i]) return i;
			}
			return -1;
		}

		protected int FindParamIndexOrError(string name) {
			int ret = FindParamIndex(name);
			if (ret != -1) return ret;
			throw Ops.TypeError("no parameter for " + name);
		}

		public virtual object Call(object[] args, string[] kwNames) {
			int nparams = argNames.Length;
			int nargs = args.Length-kwNames.Length;
			if (nargs > nparams) throw badArgCount(nparams);

			object[] inArgs = args;
			args = new object[nparams];
			for (int i=0; i < nargs; i++) args[i] = inArgs[i];

			for (int i=0; i < kwNames.Length; i++) {
				int paramIndex = FindParamIndexOrError(kwNames[i]);
				if (args[paramIndex] != null) {
					throw Ops.TypeError("multiple values for " + kwNames[i]);
				}
				args[paramIndex] = inArgs[nargs+i];
			}

			for (int i=0; i < nparams; i++) {
				if (args[i] == null) {
					int defaultIndex =  i - (nparams-defaults.Length);
					if (defaultIndex < 0) {
						throw Ops.TypeError("no value for " + argNames[i]);
					}
					args[i] = defaults[defaultIndex];
				}
			}

			return Call(args);
		}


		#region IDescriptor Members
		public object __get__(object instance, object context) {
			if (instance != null) return new Method(this, instance);
			else return this;
		}
		#endregion

		public override string ToString() {
			return string.Format("<function {0} at {1}>", func_name, Ops.HexId(this));
		}
	}

	[PythonType(typeof(Function))]
	public class FunctionN:Function {
		public CallTargetN target;

		public FunctionN(module globals, string name, CallTargetN target, string[] argNames, object[] defaults):base(globals, name, argNames, defaults) {
			this.target = target;
		}

		public override MethodInfo GetMethod() {
			return target.Method;
		}


		#region IFastCallable Members

		public override object Call() {
			return Call(new object[0]);
		}

		public override object Call(object arg0) {
			return Call(new object[] { arg0 });
		}

		public override object Call(object arg0, object arg1) {
			return Call(new object[] { arg0, arg1 });
		}

		public override object Call(object arg0, object arg1, object arg2) {
			return Call(new object[] { arg0, arg1, arg2 });
		}

		public override object Call(object arg0, object arg1, object arg2, object arg3) {
			return Call(new object[] { arg0, arg1, arg2, arg3 });
		}

		#endregion

		#region ICallable Members

		public override object Call(params object[] args) {
			int nparams = argNames.Length;
			int nargs = args.Length;
			if (nargs < nparams) {
				if (nargs + defaults.Length < nparams) {
					throw badArgCount(nparams);
				}
				object[] inArgs = args;
				args = new object[nparams];
				for (int i=0; i < nargs; i++) args[i] = inArgs[i];
				object[] defs = defaults;
				int di = defs.Length-1;
				for (int i=nparams-1; i >= nargs; i--) {
					args[i] = defs[di--];
				}
			} 
			else if (nargs > nparams) {
				throw badArgCount(nparams);
			}

			return target(args);
		}

		#endregion
	}

	[PythonType(typeof(Function))]
	public class FunctionX:FunctionN {
		private FuncDefFlags flags;
		int nparams, extraArgs=0;
		int argListPos=-1, kwDictPos=-1;
		public FunctionX(module globals, string name, CallTargetN target, string[] argNames, object[] defaults, FuncDefFlags flags):
			base(globals, name, target, argNames, defaults)
		{
			this.flags = flags;
			nparams = argNames.Length;

			if ((flags & FuncDefFlags.KwDict) != 0) {
				extraArgs++;
				nparams--;
				kwDictPos = nparams;
			}

			if ((flags & FuncDefFlags.ArgList) != 0) {
				extraArgs++;
				nparams--;
				argListPos = nparams;
			}
		}

		public override object Call(params object[] args) {
			int nargs = args.Length;
			object argList = null;
			object[] outArgs = new object[argNames.Length];

			if (nargs < nparams) {
				if (nargs + defaults.Length < nparams) {
					throw badArgCount(nparams);
				}
				for (int i=0; i < nargs; i++) outArgs[i] = args[i];
				object[] defs = defaults;
				int di = defs.Length-1;
				for (int i=nparams-1; i >= nargs; i--) {
					args[i] = defs[di--];
				}
			} else if (nargs > nparams) {
				if (argListPos >= 0) {
					for (int i=0; i < nparams; i++) outArgs[i] = args[i];

					object[] extraArgs = new object[nargs-nparams];
					for (int i=0; i < extraArgs.Length; i++) {
						extraArgs[i] = args[i+nparams];
					}
					argList = Tuple.Make(extraArgs);
				} else {
					throw badArgCount(nargs);
				}
			} else {
				for (int i=0; i < nargs; i++) outArgs[i] = args[i];
			}

			if (argListPos >= 0) {
				if (argList == null) argList = Tuple.MakeTuple();
				outArgs[argListPos] = argList;
			}
			if (kwDictPos >= 0) {
				outArgs[kwDictPos] = new Dict(); //PyDictionary.make();
			}

			return target(outArgs);
		}


		public override object Call(object[] args, string[] kwNames) {
			int nargs = args.Length-kwNames.Length;
			object argList = null;
			object[] outArgs = new object[argNames.Length];
			Dict kwDict = null;
			if (kwDictPos >= 0) {
				kwDict = new Dict();
				outArgs[kwDictPos] = kwDict;
			}

			for (int i=0; i < kwNames.Length; i++) {
				int paramIndex = FindParamIndex(kwNames[i]);
				if (paramIndex == -1) {
					kwDict[kwNames[i]] = args[nargs+i];
				} else {
					outArgs[paramIndex] = args[nargs+i];
				}
//				if (args[paramIndex] != null) {
//					throw Ops.TypeError("multiple values for " + kwNames[i]);
//				}
//				args[paramIndex] = inArgs[nargs+i];
			}

			if (nargs < nparams) {
				if (nargs + defaults.Length < nparams) {
					throw badArgCount(nparams);
				}
				for (int i=0; i < nargs; i++) outArgs[i] = args[i];
				object[] defs = defaults;
				int di = defs.Length-1;
				for (int i=nparams-1; i >= nargs; i--) {
					args[i] = defs[di--];
				}
			} else if (nargs > nparams) {
				if (argListPos >= 0) {
					for (int i=0; i < nparams; i++) outArgs[i] = args[i];

					object[] extraArgs = new object[nargs-nparams];
					for (int i=0; i < extraArgs.Length; i++) {
						extraArgs[i] = args[i+nparams];
					}
					argList = Tuple.Make(extraArgs);
				} else {
					throw badArgCount(nargs);
				}
			} else {
				for (int i=0; i < nargs; i++) outArgs[i] = args[i];
			}

			if (argListPos >= 0) {
				if (argList == null) argList = Tuple.MakeTuple();
				outArgs[argListPos] = argList;
			}

			return target(outArgs);
		}

//		public override PyObject __call__(PyObject[] args, PyString[] kwNames) {
//			PyObject[] outArgs = new PyObject[argNames.Length];
//			PyObject argList = null, kwDict = null;
//			if (kwDictPos >= 0) kwDict = PyDictionary.make();
//
//			int nargs = args.Length-kwNames.Length;
//			if (nargs <= nparams) {
//				for (int i=0; i < nargs; i++) outArgs[i] = args[i];
//			} else {
//				if (argListPos >= 0) {
//					for (int i=0; i < nparams; i++) outArgs[i] = args[i];
//
//					PyObject[] extraArgs = new PyObject[nargs-nparams];
//					for (int i=0; i < extraArgs.Length; i++) {
//						extraArgs[i] = args[i+nparams];
//					}
//					argList = PyTuple.make(extraArgs);
//				} else {
//					throw badArgCount(nargs);
//				}
//			}
//
//			for (int i=0; i < kwNames.Length; i++) {
//				int paramIndex = findParamIndex(kwNames[i]);
//				if (paramIndex == -1) {
//					kwDict.__setitem__(kwNames[i], args[nargs+i]);
//				} else {
//					if (outArgs[paramIndex] != null) {
//						throw Py.TypeError("multiple values for " + kwNames[i]);
//					}
//					outArgs[paramIndex] = args[nargs+i];
//				}
//			}
//
//			for (int i=0; i < nparams; i++) {
//				if (outArgs[i] == null) {
//					int defaultIndex =  i - (nparams-defaults.Length);
//					if (defaultIndex < 0) {
//						throw Py.TypeError("no value for " + argNames[i]);
//					}
//					outArgs[i] = defaults[defaultIndex];
//				}
//			}
//
//			if (argListPos >= 0) {
//				if (argList == null) argList = PyTuple.make();
//				outArgs[argListPos] = argList;
//			}
//			if (kwDictPos >= 0) {
//				outArgs[kwDictPos] = kwDict;
//			}
//
//			return target(outArgs);
//		}
	}

	public class Method:IFastCallable,IFancyCallable,IDescriptor {
		//??? can I type this to Function
		public object func;
		public object inst;

		public Method(object func, object inst) { this.func = func; this.inst = inst; }

		public string __name__ {
			get { return (string)Ops.GetAttr(func, "__name__"); }
		}

		private object[] AddInstToArgs(object[] args) {
			object[] nargs = new object[args.Length+1];
			args.CopyTo(nargs, 1);
			nargs[0] = inst;
			return nargs;
		}


		#region ICallable Members

		public object Call(params object[] args) {
			return Ops.Call(func, AddInstToArgs(args));
		}

		#endregion

		#region IFastCallable Members

		public object Call() {
			return Ops.Call(func, inst);
		}

		public object Call(object arg0) {
			Function f = func as Function;
			if (f != null) return f.Call(inst, arg0);
			return Ops.Call(func, inst, arg0);
		}

		public object Call(object arg0, object arg1) {
			return Ops.Call(func, inst, arg0, arg1);
		}
		public object Call(object arg0, object arg1, object arg2) {
			return Ops.Call(func, inst, arg0, arg1, arg2);
		}
		public object Call(object arg0, object arg1, object arg2, object arg3) {
			return Ops.Call(func, new object[] { inst, arg0, arg1, arg2, arg3 });
		}

		#endregion

		public object Call(object[] args, string[] names) {
			return Ops.Call(func, AddInstToArgs(args), names);

		}

		public override string ToString() {
			if (func is BuiltinFunction || func is ReflectedMethodBase) {
				if (inst != null) {
					return string.Format("<built-in method {0} of {1} object at {2}>", Ops.GetAttr(func, "__name__"),
						Ops.GetDynamicType(inst).__name__, Ops.HexId(inst));
			    }
			}

				if (inst != null) {
				return string.Format("<bound method {0}.{1} of {2}>", Ops.GetDynamicType(inst).__name__, 
						Ops.GetAttr(func, "__name__"), Ops.StringRepr(inst));
			} else {
				return string.Format("<method {0}>", func);
			}
		}
		#region IDescriptor Members
		public object __get__(object instance, object context) {
			return this;
		}
		#endregion
	}

	[PythonType(typeof(Function))]
	public class InterpFunction:ICallable {
		string[] argNames;
		string name;
		object[] defaults;

		Stmt body;
		module globals;

		public InterpFunction(string name, string[] argNames, object[] defaults, Stmt body, module globals) {
			this.name = name;
			this.argNames = argNames;
			this.defaults = defaults;
			this.body = body;

			this.globals = globals;
		}


		#region ICallable Members

		public object Call(params object[] args) {
			//if (argNames.Length != args.Length) throw new Exception("wrong number of args");

			NameEnv env = new NameEnv(globals, new HybridDictionary());
			int i=0;
			for (; i < args.Length; i++) {
				env.Set(argNames[i], args[i]);
			}

			int di = i-(argNames.Length-defaults.Length);

			while (i < argNames.Length) {
				env.Set(argNames[i++], defaults[di++]);
			}

			return body.Execute(env);
		}

		#endregion
	}

}
