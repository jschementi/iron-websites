/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Reflection;

namespace IronPython.Objects
{
	[PythonType("builtin_function_or_method")]
	public class BuiltinFunction:Function {
		public static BuiltinFunction Make(MethodInfo mi) {
			BuiltinFunction f = new BuiltinFunction(mi.Name, true);
			f.AddMethod(mi);
			return f;
		}

		public static BuiltinFunction FromDelegate(Delegate d) {
			BuiltinFunction f = new BuiltinFunction(d.Method.Name, true);
			f.AddMethod(d.Method); //!!! should just use the delegate directly
			return f;
		}


//		public static bool check(MethodInfo mi) {
//			if (!mi.IsStatic) return false;
//			if (mi.ReturnType != typeof(PyObject)) return false;
//
//			ParameterInfo[] parameters = mi.GetParameters();
//			if (parameters.Length == 1) {
//				if (parameters[0].ParameterType != typeof(PyObject[]) &&
//					parameters[0].ParameterType != typeof(PyObject)) return false;
//			} else {
//				if (parameters.Length > PyObject.MAX_CALL_ARGS) return false;
//				foreach (ParameterInfo pi in parameters) {
//					if (pi.ParameterType != typeof(PyObject)) return false;
//				}
//			}
//			return true;
//		}

		//!!! I'd like a few smaller versions of this
		public CallTargetN targetN;
		private bool isMethod;
		public BuiltinFunction(string name, bool isMethod): base(null, name, new string[0], new object[0]) {
			this.isMethod = isMethod;
		}

		public override MethodInfo GetMethod() {
			throw new NotImplementedException();
		}

		public int GetMaxArgs() {
			if (targetN != null) return int.MaxValue;
			if (target4 != null) return 4;
			if (target3 != null) return 3;
			if (target2 != null) return 2;
			if (target1 != null) return 1;
			return 0;
		}


		#region Generated BuiltinFunction targets
		public CallTarget0 target0;
		public override object Call() {
		    if (target0 != null) return target0();
		    else if (targetN != null) return targetN(new object[]{});
		    else throw badArgCount(0);
		}
		public CallTarget1 target1;
		public override object Call(object arg0) {
		    if (target1 != null) return target1(arg0);
		    else if (targetN != null) return targetN(new object[]{arg0});
		    else throw badArgCount(1);
		}
		public CallTarget2 target2;
		public override object Call(object arg0, object arg1) {
		    if (target2 != null) return target2(arg0, arg1);
		    else if (targetN != null) return targetN(new object[]{arg0, arg1});
		    else throw badArgCount(2);
		}
		public CallTarget3 target3;
		public override object Call(object arg0, object arg1, object arg2) {
		    if (target3 != null) return target3(arg0, arg1, arg2);
		    else if (targetN != null) return targetN(new object[]{arg0, arg1, arg2});
		    else throw badArgCount(3);
		}
		public CallTarget4 target4;
		public override object Call(object arg0, object arg1, object arg2, object arg3) {
		    if (target4 != null) return target4(arg0, arg1, arg2, arg3);
		    else if (targetN != null) return targetN(new object[]{arg0, arg1, arg2, arg3});
		    else throw badArgCount(4);
		}
		public override object Call(params object[] args) {
		    switch(args.Length) {
		        case 0: return Call();
		        case 1: return Call(args[0]);
		        case 2: return Call(args[0], args[1]);
		        case 3: return Call(args[0], args[1], args[2]);
		        case 4: return Call(args[0], args[1], args[2], args[3]);
		        default: if (targetN != null) return targetN(args);
		                 else throw badArgCount(args.Length);
		    }
		}
		#endregion

//		public override PyObject __get__(PyObject instance, PyObject owner) {
//			if (isMethod) return base.__get__(instance, owner);
//			else return this;
//		}


		public void AddMethod(MethodInfo mi) {
			//Console.WriteLine("adding: " + mi);
			ParameterInfo[] parameters = mi.GetParameters();
			if (parameters.Length == 1 && parameters[0].ParameterType == typeof(object[])) {
				targetN = (CallTargetN)Delegate.CreateDelegate(
					typeof(CallTargetN), mi);
				//Console.WriteLine("adding var args: " + mi);
				return;
			}

			switch (parameters.Length) {
					#region Generated BuiltinFunction delegates
					case 0: target0=(CallTarget0)Delegate.CreateDelegate(typeof(CallTarget0), mi); break;
					case 1: target1=(CallTarget1)Delegate.CreateDelegate(typeof(CallTarget1), mi); break;
					case 2: target2=(CallTarget2)Delegate.CreateDelegate(typeof(CallTarget2), mi); break;
					case 3: target3=(CallTarget3)Delegate.CreateDelegate(typeof(CallTarget3), mi); break;
					case 4: target4=(CallTarget4)Delegate.CreateDelegate(typeof(CallTarget4), mi); break;
					#endregion
				default:
					throw new NotImplementedException("too many parameters to " + mi);
			}
		}

		public override string ToString() {
			return string.Format("<built-in function {0}>", func_name);
		}
	}


}
