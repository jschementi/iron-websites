/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Text;
using System.Reflection;
using System.Diagnostics;

using IronPython.Objects;
using IronPython.AST;

using IronMath;



namespace IronPython.Objects {
	/// <summary>
	/// Summary description for ConstantValue.
	/// </summary>
	public class LiteralParser {
		public static string ParseString(string text, bool isRaw) {
			if (isRaw) return text;

			//PERFORMANCE-ISSUE ??? maybe optimize for the 0-escapes case
			StringBuilder buf = new StringBuilder(text.Length);
			int i = 0;
			int l = text.Length;
			while (i < l) {
				char ch = text[i++];
				if (ch == '\\') {
					ch = text[i++];
					switch(ch) {
						case 'a': buf.Append('\a'); continue;
						case 'b': buf.Append('\b'); continue;
						case 'f': buf.Append('\f'); continue;
						case 'n': buf.Append('\n'); continue;
						case 'r': buf.Append('\r'); continue;
						case 't': buf.Append('\t'); continue;
						case 'v': buf.Append('\v'); continue;
						case '\\': buf.Append('\\'); continue;
						case '\'': buf.Append('\''); continue;
						case '\"': buf.Append('\"'); continue;
						case 'u': //32 bit hex !!! or is that 16
							buf.Append((char)ParseInt(text.Substring(i, 4), 16));
							i += 4;
							continue;
						case 'U': //16-bit hex
							buf.Append((char)ParseInt(text.Substring(i, 4), 16));
							i += 4;
							continue;
						case 'x': //hex
							buf.Append((char)ParseInt(text.Substring(i, 2), 16));
							i += 2;
							continue;
						case '0': case '1': case '2': case '3': case '4':
						case '5': case '6': case '7':
							int val = ch-'0';
							if (i < l && char.IsDigit(text[i])) {
								val = val*8 + HexValue(text[i++]);
								if (i < l && char.IsDigit(text[i])) {
									val = val*8 + HexValue(text[i++]);
								}
							}
							
							buf.Append((char)val);
							continue;
						default:
							buf.Append("\\");
							buf.Append(ch);
							continue;
					}
				} else {
					buf.Append(ch);
				}
			}

			return buf.ToString();
		}


		private static int HexValue(char ch) {
			switch(ch) {
				case '0': return 0;
				case '1': return 1;
				case '2': return 2;
				case '3': return 3;
				case '4': return 4;
				case '5': return 5;
				case '6': return 6;
				case '7': return 7;
				case '8': return 8;
				case '9': return 9;
				case 'a': case 'A': return 10;
				case 'b': case 'B': return 11;
				case 'c': case 'C': return 12;
				case 'd': case 'D': return 13;
				case 'e': case 'E': return 14;
				case 'f': case 'F': return 15;
				//!!! need to support more values...
				default:
					throw new NotSupportedException("bad char for hex value: " + ch);
			}
		}
		private static int ParseInt(string text, int b) {
			//Console.WriteLine("text: " + text + ", " + b);
			int ret = 0;
			int m = 1;
			for (int i=text.Length-1; i >=0; i--) {
				//Console.WriteLine("i: " + i + ", " + text[i]);
				checked {
					ret += m*HexValue(text[i]);  // this is more generous than needed
					m *= b; // is this optimized???
				}
			}
			return ret;
		}

		public static object ParseInteger(string text, int b) {
			//!!! From experiments, CPython-1.3 appears to highly optimize this silly pattern
			//!!! Annoyingly, this has a small impact on parrotbench scores
			if (b == 0 && text.StartsWith("0x")) {
				int shift = 0;
				int ret = 0;
				for (int i=text.Length-1; i >= 2; i--) {
					ret |= HexValue(text[i]) << shift;
					shift += 4;
				}
				return ret;
			}

			if (b == 0) b = DetectRadix(ref text);
			try {
				return ParseInt(text, b);
			} catch (OverflowException) {
				integer ret = ParseBigInteger(text, b);
				int iret;
				if (ret.AsInt32(out iret)) return iret;
				long lret;
				if (ret.AsInt64(out lret)) return lret;
				return ret;
			}
		}

		private static int DetectRadix(ref string s) {
			if (s.StartsWith("0x") || s.StartsWith("0X")) {
				s = s.Substring(2);
				return 16;
			} else if (s.StartsWith("0")) {
				return 8;
			} else {
				return 10;
			}
		}


		public static object ParseBigIntegerForL(string text, int b) {
			integer r = ParseBigInteger(text, b);
			long ret;
			if (r.AsInt64(out ret)) return ret;
			return r;
		}

		public static integer ParseBigInteger(string text, int b) {
			if (b == 0) b = DetectRadix(ref text);
			//Console.WriteLine("text: " + text + ", " + b);
			integer ret = integer.ZERO;
			integer m = integer.ONE;

			int i = text.Length-1;
			if (text[i] == 'l' || text[i] == 'L') i -= 1;

			while (i >= 0) {
				char ch = text[i--];
				//Console.WriteLine("i: " + i + ", " + text[i]);
				ret += m*integer.make((uint)HexValue(ch)); // this is more generous than needed
				m = m*b; // is this optimized???
			}
			return ret;
		}


		public static double ParseFloat(string text) {
			return double.Parse(text); //??? is this fully Python compatible
		}

		public static Complex64 ParseImaginary(string text) {
			return Complex64.MakeImaginary( double.Parse(text.Substring(0, text.Length-1)) );
		}
	}
}
