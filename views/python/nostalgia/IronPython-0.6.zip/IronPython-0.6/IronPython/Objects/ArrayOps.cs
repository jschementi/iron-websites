/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Text;
using System.Collections;

using IronMath;

namespace IronPython.Objects {
	public class ArrayOps {
		public static bool Contains(object[] data, int size, object item) {
			return Array.IndexOf(data, item, 0, size) >= 0;
		}

		public static object[] Add(object[] data1, int size1, object[] data2, int size2) {			
			object[] ret = new object[size1 + size2];
			Array.Copy(data1, 0, ret, 0, size1);
			Array.Copy(data2, 0, ret, size1, size2);
			return ret;
		}

		public static object[] Multiply(object[] data, int size, int count) {
			int newCount = size*count;
			
			object[] ret = new object[newCount];
			Array.Copy(data, 0, ret, 0, size);

			// this should be extremely fast for large count as it uses the same algoithim as efficient integer powers
			// ??? need to test to see how large count and n need to be for this to be fastest approach
			int block=size;
			int pos = size;
			while (pos < newCount) {
				Array.Copy(ret, 0, ret, pos, Math.Min(block, newCount-pos));
				pos += block;
				block *= 2;
			}
			return ret;
		}

		public static object[] GetSlice(object[] data, int size, Slice slice) {
			int start, stop, step;
			slice.indices(size, out start, out stop, out step);

			if (step == 1) {
				int n = stop-start;
				object[] ret = new object[n];
				Array.Copy(data, start, ret, 0, n);
				return ret;
			} else {
				int n = (stop-start)/step;
				object[] ret = new object[n];
				int ri = 0;
				for (int i=start; i < stop; i+= step) {
					ret[ri++] = data[i];
				}
				return ret;
			}
		}

		public static string __repr__(Array a) {
			StringBuilder ret = new StringBuilder();
			ret.Append(a.GetType().FullName);
			ret.Append("(");
			for (int i=0; i < a.Length; i++) {
				if (i > 0) ret.Append(", ");
				ret.Append( Ops.StringRepr(a.GetValue(i)));
			}
			ret.Append(")");
			return ret.ToString();
		}
	}
}
