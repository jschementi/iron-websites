/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Text;
using System.IO;

namespace IronPython.Objects {
	[PythonType("file")]
	public class PythonFile {
//		public static PyObject __new__(PyType type, string filename) {
//			return __new__(type, filename, "r");
//		}
//
//		public static PyObject __new__(PyType type, string filename, string mode) {
//			return __new__(type, filename, mode, -1);
//		}
//
//		public static PyObject __new__(PyType type, string filename, string mode, int bufsize) {
//			FileShare fshare = FileShare.None; //!!! no one else can use file
//			FileMode fmode;
//			FileAccess faccess;
//			string inMode = mode;
//			//!!! universal newlines are TODO
//			bool binary = false, seekEnd = false;
//			if (mode.EndsWith("b")) {
//				binary = true;
//				mode = mode.Substring(0, mode.Length-1);
//			}
//
//			if (mode == "r") {
//				fmode = FileMode.Open; faccess = FileAccess.Read;
//			} else if (mode == "r+") {
//				fmode = FileMode.Open; faccess = FileAccess.ReadWrite;
//			} else if (mode == "w") {
//				fmode = FileMode.Create; faccess = FileAccess.Write;
//			} else if (mode == "w+") {
//				fmode = FileMode.Create; faccess = FileAccess.ReadWrite;
//			} else if (mode == "a") {
//				fmode = FileMode.Append; faccess = FileAccess.Write;
//			} else if (mode == "a+") {
//				fmode = FileMode.OpenOrCreate; faccess = FileAccess.ReadWrite;
//				seekEnd = true;
//			} else {
//				throw new NotImplementedException("bad mode: " + mode);
//			}
//
//			FileStream stream;
//			if (bufsize == -1) {
//				stream = new FileStream(filename, fmode, faccess, fshare);
//			} else {
//				stream = new FileStream(filename, fmode, faccess, fshare, bufsize);
//			}
//			if (seekEnd) stream.Seek(0, SeekOrigin.End);
//
//			return type.MakeNew(pytype, stream, inMode, binary); 
//		}

		public static PythonFile Make(string filename, string mode, int bufsize) {
			FileShare fshare = FileShare.None; //!!! no one else can use file
			FileMode fmode;
			FileAccess faccess;
			string inMode = mode;
			//!!! universal newlines are TODO
			bool binary = false, seekEnd = false;
			if (mode.EndsWith("b")) {
				binary = true;
				mode = mode.Substring(0, mode.Length-1);
			}

			if (mode == "r") {
				fmode = FileMode.Open; faccess = FileAccess.Read;
			} else if (mode == "r+") {
				fmode = FileMode.Open; faccess = FileAccess.ReadWrite;
			} else if (mode == "w") {
				fmode = FileMode.Create; faccess = FileAccess.Write;
			} else if (mode == "w+") {
				fmode = FileMode.Create; faccess = FileAccess.ReadWrite;
			} else if (mode == "a") {
				fmode = FileMode.Append; faccess = FileAccess.Write;
			} else if (mode == "a+") {
				fmode = FileMode.OpenOrCreate; faccess = FileAccess.ReadWrite;
				seekEnd = true;
			} else {
				throw new NotImplementedException("bad mode: " + mode);
			}

			FileStream stream;
			if (bufsize == -1) {
				stream = new FileStream(filename, fmode, faccess, fshare);
			} else {
				stream = new FileStream(filename, fmode, faccess, fshare, bufsize);
			}
			if (seekEnd) stream.Seek(0, SeekOrigin.End);

			return new PythonFile(stream, inMode, binary);
		}

		private readonly FileStream fstream;
		private readonly Stream stream;
		private readonly string mode;
		private readonly bool binary;

		private readonly StreamReader reader;
		private readonly StreamWriter writer;

		public bool softspace = false;

		public PythonFile(Stream stream, string mode, bool binary) {
			this.stream = stream;
			if (stream is FileStream) fstream = (FileStream)stream;
			this.mode = mode;
			this.binary = binary;
			if (stream.CanRead) reader = new StreamReader(stream, Encoding.ASCII);
			if (stream.CanWrite) writer = new StreamWriter(stream, Encoding.ASCII);
		}


		public void close() {
			flush();
			stream.Close(); 
		}

		public void flush() {
			if (writer != null) writer.Flush();
			stream.Flush();
		}

		public int fileno() {
			return (int)fstream.Handle;
		}

		public bool isatty() {
			return false;
		}

		public string read() {
			return read(-1);
		}

		public string read(int size) {
			string ret;
			if (size < 0) {
				ret = reader.ReadToEnd();
			} else {
				char[] buf = new char[size];
				int read = reader.Read(buf, 0, size);
				if (read == -1) return "";
				ret = new string(buf, 0, read);
			}
			return ret;
		}
//
//		public PyString readline() {
//			string line = reader.ReadLine();
//			if (line == null) {
//				return PyString.make("");
//			}
//
//			return PyString.make(line+"\n");
//		}
//
//		public PyString readline(int size) {
//			return readline(); //!!! optimization
//		}
//
//		public PyList readlines() {
//			PyList ret = new PyList();
//			PyObject line;
//			while (next(out line)) {
//				ret.append(line);
//			}
//			return ret;
//		}
//
//		public PyList readlines(int sizehint) {
//			return readlines(); //!!! optimize
//		}
			

		public void write(string s) {
			writer.Write(s);
			flush(); //!!! performance hazard
		}


		//!!! many more go here
//		public override bool next(out PyObject ret) {
//			ret = readline();
//			if (ret.__len__() == 0) return false;
//			else return true;
//		}
//		public override PyObject __iter__() {
//			return this;
//		}

		public override string ToString() {
			return string.Format("<file {0}, {1}>", fstream.Name, mode);
		}
	}
}
