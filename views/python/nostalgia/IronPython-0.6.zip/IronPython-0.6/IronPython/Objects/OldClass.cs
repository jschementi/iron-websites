/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;
using System.Collections.Specialized;

namespace IronPython.Objects {
	/// <summary>
	/// Summary description for OldClass.
	/// </summary>
	public class OldClass:DynamicType,ICallable,IDynamicObject {
		public Tuple __bases__;
		public string __module__;
		public IDictionary __dict__;

		public OldClass(string module, string name, Tuple bases, IDictionary dict) {
			__bases__ = bases; //!!! validate, maybe even sort
			__module__ = module == null ? "__builtin__" : module;
			__name__ = name;
			__dict__ = dict;
		}

		public object Lookup(string name) {
			object ret = __dict__[name];
			if (ret != null) return ret;

			foreach (OldClass c in __bases__) { //!!! subtle rules for this, need generics to be safe
				ret = c.Lookup(name);
				if (ret != null) return ret;
			}
			return null;
		}

		internal string FullName {
			get { return __module__ + '.' + __name__; }
		}

		public override string ToString() {
			return string.Format("<class {0} at {1}>", FullName, Ops.HexId(this));
		}

		#region ICallable Members

		public object Call(params object[] args) {
			OldInstance inst = new OldInstance(this);
			object dummy;
			Ops.TryToInvoke(inst, "__init__", out dummy, args);
			return inst;
		}

		#endregion

		#region IDynamicObject Members

		public bool GetSlot(string name, out object ret) {
			if (name == "__bases__") {
				ret = __bases__;
				return true;
			}

			ret = __dict__[name];
			if (ret != null) {
				ret = Ops.GetDescriptor(ret, null, this);
				return true;
			} else {
				return false;
			}
		}

		public void SetSlot(string name, object value) {
			__dict__[name] = value;
		}

		public void DelSlot(string name) {
			throw new NotImplementedException();
		}

		public DynamicType GetDynamicType() {
			return Ops.GetDynamicTypeFromType(typeof(OldClass));  //!!! pessimal
		}

		#endregion

		#region Generated OldClass Binary Ops
		
		public override object Add(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__add__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		public override object ReverseAdd(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__radd__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		
		}
		public override object InPlaceAdd(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__iadd__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		
		public override object Subtract(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__sub__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		public override object ReverseSubtract(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__rsub__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		
		}
		public override object InPlaceSubtract(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__isub__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		
		public override object Power(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__pow__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		public override object ReversePower(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__rpow__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		
		}
		public override object InPlacePower(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__ipow__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		
		public override object Multiply(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__mul__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		public override object ReverseMultiply(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__rmul__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		
		}
		public override object InPlaceMultiply(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__imul__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		
		public override object FloorDivide(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__floordiv__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		public override object ReverseFloorDivide(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__rfloordiv__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		
		}
		public override object InPlaceFloorDivide(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__ifloordiv__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		
		public override object Divide(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__div__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		public override object ReverseDivide(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__rdiv__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		
		}
		public override object InPlaceDivide(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__idiv__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		
		public override object Mod(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__mod__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		public override object ReverseMod(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__rmod__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		
		}
		public override object InPlaceMod(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__imod__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		
		public override object LeftShift(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__lshift__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		public override object ReverseLeftShift(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__rlshift__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		
		}
		public override object InPlaceLeftShift(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__ilshift__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		
		public override object RightShift(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__rshift__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		public override object ReverseRightShift(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__rrshift__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		
		}
		public override object InPlaceRightShift(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__irshift__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		
		public override object BitwiseAnd(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__and__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		public override object ReverseBitwiseAnd(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__rand__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		
		}
		public override object InPlaceBitwiseAnd(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__iand__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		
		public override object BitwiseOr(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__or__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		public override object ReverseBitwiseOr(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__ror__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		
		}
		public override object InPlaceBitwiseOr(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__ior__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		
		public override object Xor(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__xor__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		public override object ReverseXor(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__rxor__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		
		}
		public override object InPlaceXor(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__ixor__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		
		public override object LessThan(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__lt__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		
		public override object GreaterThan(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__gt__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		
		public override object LessThanOrEqual(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__le__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		
		public override object GreaterThanOrEqual(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__ge__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		
		public override object Equal(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__eq__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		
		public override object NotEqual(object self, object other) {
		    object func;
		    if (Ops.GetAttr(self, "__ne__", out func)) return Ops.Call(func, other);
		    return Ops.NotImplemented;
		}
		#endregion
	}

	public class OldInstance:IDynamicObject,ICustomAttributes,ICodeFormattable {
		public IDictionary __dict__;
		public OldClass __class__;


		public OldInstance(OldClass _class) {
			this.__class__ = _class;
			this.__dict__ = new HybridDictionary();
		}

		public string ToCodeString() {
			object ret;
			if (Ops.TryToInvoke(this, "__repr__", out ret)) return ret.ToString();

			return string.Format("<{0} instance at {1}>", __class__.FullName, Ops.HexId(this));
		}

		public override string ToString() {
			object ret;
			if (Ops.TryToInvoke(this, "__str__", out ret)) return ret.ToString();

			return ToCodeString();
		}


		#region ICustomAttributes Members

		public object __getattribute__(string name) {
			if (name == "__class__") return __class__;

			object ret;

			if (__dict__ != null) {
				ret = __dict__[name];
				if (ret != Ops.Missing && ret != null) return ret;
			}
 
			ret = __class__.Lookup(name);
			if (ret != null) {
				ret = Ops.GetDescriptor(ret, this, __class__);
				return ret;
			}

			return Ops.Missing;
		}

		public void __setattr__(string name, object value) {
			__dict__[name] = value;
		}


		public void __delattr__(string name) {
			throw new NotImplementedException();
		}

		public List __attrs__() {
			throw new NotImplementedException();
		}

		#endregion

		#region IDynamicObject Members

		public DynamicType GetDynamicType() {
			return __class__;
		}

		#endregion
	}
}
