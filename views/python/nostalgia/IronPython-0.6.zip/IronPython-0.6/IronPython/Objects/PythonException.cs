/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;

using IronPython.Modules;

namespace IronPython.Objects {
	/// <summary>
	/// Summary description for PythonException.
	/// </summary>
	public class PythonExceptionNew:Exception,ICodeFormattable {
		public static int count = 0;
		public readonly object[] args;
		public PythonExceptionNew(params object[] args):base(args.Length > 0 ? args[0].ToString() : "") {
			count++;
			//ReflectedMethodBase.NoteCall(this);
			this.args = args;
		}

		#region ICodeFormattable Members

		public string ToCodeString() {
			return string.Format("<{0} instance at {1}>", Ops.GetDynamicType(this).__name__, Ops.HexId(this));
		}

		#endregion
	}

	#region Generated PythonException Classes
	
	[PythonType("ValueError")]
	public class PythonValueError:PythonStandardError {
	        public PythonValueError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("ImportError")]
	public class PythonImportError:PythonStandardError {
	        public PythonImportError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("RuntimeError")]
	public class PythonRuntimeError:PythonStandardError {
	        public PythonRuntimeError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("UnicodeTranslateError")]
	public class PythonUnicodeTranslateError:PythonUnicodeError {
	        public PythonUnicodeTranslateError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("KeyError")]
	public class PythonKeyError:PythonLookupError {
	        public PythonKeyError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("StopIteration")]
	public class PythonStopIteration:PythonExceptionNew {
	        public PythonStopIteration(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("PendingDeprecationWarning")]
	public class PythonPendingDeprecationWarning:PythonWarning {
	        public PythonPendingDeprecationWarning(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("EnvironmentError")]
	public class PythonEnvironmentError:PythonStandardError {
	        public PythonEnvironmentError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("LookupError")]
	public class PythonLookupError:PythonStandardError {
	        public PythonLookupError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("OSError")]
	public class PythonOSError:PythonEnvironmentError {
	        public PythonOSError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("DeprecationWarning")]
	public class PythonDeprecationWarning:PythonWarning {
	        public PythonDeprecationWarning(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("UnicodeError")]
	public class PythonUnicodeError:PythonValueError {
	        public PythonUnicodeError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("UnicodeEncodeError")]
	public class PythonUnicodeEncodeError:PythonUnicodeError {
	        public PythonUnicodeEncodeError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("FloatingPointError")]
	public class PythonFloatingPointError:PythonArithmeticError {
	        public PythonFloatingPointError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("ReferenceError")]
	public class PythonReferenceError:PythonStandardError {
	        public PythonReferenceError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("NameError")]
	public class PythonNameError:PythonStandardError {
	        public PythonNameError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("OverflowWarning")]
	public class PythonOverflowWarning:PythonWarning {
	        public PythonOverflowWarning(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("IOError")]
	public class PythonIOError:PythonEnvironmentError {
	        public PythonIOError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("SyntaxError")]
	public class PythonSyntaxError:PythonStandardError {
	        public PythonSyntaxError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("FutureWarning")]
	public class PythonFutureWarning:PythonWarning {
	        public PythonFutureWarning(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("SystemExit")]
	public class PythonSystemExit:PythonExceptionNew {
	        public PythonSystemExit(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("EOFError")]
	public class PythonEOFError:PythonStandardError {
	        public PythonEOFError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("StandardError")]
	public class PythonStandardError:PythonExceptionNew {
	        public PythonStandardError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("TabError")]
	public class PythonTabError:PythonIndentationError {
	        public PythonTabError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("ZeroDivisionError")]
	public class PythonZeroDivisionError:PythonArithmeticError {
	        public PythonZeroDivisionError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("SystemError")]
	public class PythonSystemError:PythonStandardError {
	        public PythonSystemError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("IndentationError")]
	public class PythonIndentationError:PythonSyntaxError {
	        public PythonIndentationError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("AssertionError")]
	public class PythonAssertionError:PythonStandardError {
	        public PythonAssertionError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("UnicodeDecodeError")]
	public class PythonUnicodeDecodeError:PythonUnicodeError {
	        public PythonUnicodeDecodeError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("TypeError")]
	public class PythonTypeError:PythonStandardError {
	        public PythonTypeError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("IndexError")]
	public class PythonIndexError:PythonLookupError {
	        public PythonIndexError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("RuntimeWarning")]
	public class PythonRuntimeWarning:PythonWarning {
	        public PythonRuntimeWarning(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("KeyboardInterrupt")]
	public class PythonKeyboardInterrupt:PythonStandardError {
	        public PythonKeyboardInterrupt(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("UserWarning")]
	public class PythonUserWarning:PythonWarning {
	        public PythonUserWarning(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("SyntaxWarning")]
	public class PythonSyntaxWarning:PythonWarning {
	        public PythonSyntaxWarning(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("MemoryError")]
	public class PythonMemoryError:PythonStandardError {
	        public PythonMemoryError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("UnboundLocalError")]
	public class PythonUnboundLocalError:PythonNameError {
	        public PythonUnboundLocalError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("ArithmeticError")]
	public class PythonArithmeticError:PythonStandardError {
	        public PythonArithmeticError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("Warning")]
	public class PythonWarning:PythonExceptionNew {
	        public PythonWarning(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("NotImplementedError")]
	public class PythonNotImplementedError:PythonRuntimeError {
	        public PythonNotImplementedError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("AttributeError")]
	public class PythonAttributeError:PythonStandardError {
	        public PythonAttributeError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("OverflowError")]
	public class PythonOverflowError:PythonArithmeticError {
	        public PythonOverflowError(params object[] args):base(args) {
	        }
	}
	
	
	[PythonType("WindowsError")]
	public class PythonWindowsError:PythonOSError {
	        public PythonWindowsError(params object[] args):base(args) {
	        }
	}
	
	#endregion


//	[AttributeUsage(AttributeTargets.Parameter | AttributeTargets.Method, Inherited=true)]
//	public class PythonVarArgsAttribute:Attribute {
//		public PythonVarArgsAttribute() {
//		}
//	}
}
