/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;
using System.Collections.Specialized;
using System.Reflection;
using System.IO;

using System.Diagnostics;

using IronPython.AST;
using IronPython.Modules;


namespace IronPython.Objects {
	/// <summary>
	/// Summary description for time.
	/// </summary>
	public class module:IDynamicObject,ICustomAttributes {
		public const string ModuleFieldName = "myModule__py";

		private static module GetDeclaringModule(MethodBase mb) {
			Type t = mb.DeclaringType;
			FieldInfo fi = t.GetField(ModuleFieldName);
			if (fi == null) return null;
			return (module)fi.GetValue(null);
		}

		public static module LookupModuleOnStack() {
			StackTrace trace = new StackTrace();
			for (int i=trace.FrameCount-1; i >= 0; i--) {
				StackFrame frame = trace.GetFrame(i);
				module ret = GetDeclaringModule(frame.GetMethod());
				if (ret != null) return ret;
			}
			throw new NotImplementedException();
		}


		public ReflectedType __builtins__ = (ReflectedType)Ops.GetDynamicTypeFromType(typeof(__builtin__));

		private Dict internalDict = new Dict();

		public IDictionary __dict__;

		public object __name__;
		
		public module() {
			__name__ = GetType().Name;

			__dict__ = new ModuleDictionary(this);

			FieldInfo ti = GetType().GetField(ModuleFieldName);
			if (ti != null) ti.SetValue(null, this);

			InitializeBuiltins();
		}

		private void InitializeBuiltins() {
			foreach (FieldInfo fi in GetType().GetFields()) {
				if (fi.FieldType != typeof(object)) continue;
				if (!fi.IsStatic) continue;

				if (fi.Name == "__name__") {
					//Console.Out.WriteLine("name = {0}", __name__);
					fi.SetValue(null, __name__); //!!!"__main__"); //!!!
					continue;
				}

				if (fi.Name == "__debug__") {
					fi.SetValue(null, Options.DEBUG);
					continue;
				}

				object bi = __builtins__.RawGetSlot(fi.Name); //!!! wrong
				if (bi != null) {
					fi.SetValue(null, Ops.GetDescriptor(bi, null, __builtins__));
					continue;
				}

				if (fi.GetValue(null) == null) {
					fi.SetValue(null, new Uninitialized(fi.Name));
				}
			}
		}

		internal object Import(string fullName, bool keepTop) {
			//!!! still pretty simple
			object ret = Importer.ImportOne(fullName, keepTop);
			if (ret == null) throw Ops.ImportError("can't load {0}", fullName);
			return ret;
		}

		internal object ImportFrom(string name) {
			object ret = __getattribute__(name);
			if (ret != Ops.Missing) return ret;

			throw new NotImplementedException();
		}

		public virtual void init() {
		}

		#region IDynamicObject Members
		public DynamicType GetDynamicType() {
			throw new NotImplementedException();
		}
		#endregion

		#region ICustomAttributes Members

		public object __getattribute__(string name) {
			FieldInfo fi = GetType().GetField(name);
			if (fi != null) {
				return fi.GetValue(null);
			}

			object ret = internalDict.get(name, Ops.Missing);
			if (ret != Ops.Missing) return ret;

			return __builtins__.__getattribute__(name);
		}

		public void __setattr__(string name, object value) {
			//!!! ridiculously slow...
			FieldInfo fi = GetType().GetField(name);
			if (fi != null) fi.SetValue(null, value);
			else internalDict[name] = value;
		}

		public void __delattr__(string name) {
			throw new NotImplementedException();
		}

		public List __attrs__() {
			List ret = internalDict.keys();
			foreach (FieldInfo fi in GetType().GetFields()) {
				if (!fi.IsStatic || (fi.FieldType != typeof(object))) continue;
				object val = fi.GetValue(null);
				if (val is Uninitialized) continue;

				ret.append(fi.Name);
			}
			return ret;
		}
		#endregion
	}

	public class Importer {

//		internal static object importOne(PyModule mod, PyString fullName, bool keepTop) {
//			PyObject ret;
//			if (mod != null) {
//				string[] names = fullName.value.Split('.');
//				PyObject top = mod.tryToImportFromParent(PyString.make(names[0]));
//				if (top != null) {
//					PyObject bottom = top;
//					for (int i=1; i < names.Length; i++) {
//						bottom = bottom.importFrom(PyString.make(names[i]));
//					}
//
//					return keepTop ? top : bottom;
//				}
//			}
//
//			ret = importOne(fullName, keepTop);
//			if (ret != null) return ret;
//
//			throw Py.ImportError("{0} not found", fullName);
//		}
//
//
		public static object ImportFrom(object mod, string name) {
			if (mod is module) return ((module)mod).ImportFrom(name);
			else return Ops.GetAttr(mod, name);
		}
		
		internal static object ImportOne(string fullName, bool keepTop) {
			object ret = sys.modules[fullName];
			if (ret != null) return ret;

			string[] names = fullName.Split('.');

			object top = LoadTop(names[0]);
			if (top == null) return null;

			object bottom = top;
			for (int i=1; i < names.Length; i++) {
				bottom = ImportFrom(bottom, names[i]);
			}

			if (keepTop) return top;
			return bottom;
		}

		internal static object LoadTop(string name) {
			object ret;
			ret = LoadBuiltin(name);
			if (ret != null) return ret;

			ret = LoadFromPath(name, name, sys.path);
			if (ret != null) return ret;

			ret = LoadReflected(name);
			if (ret != null) return ret;

			return null;
		}


		static object LoadBuiltin(string name) {
			Type ty = Type.GetType("IronPython.Modules." + name);
			if (ty != null) {
				return Ops.GetDynamicTypeFromType(ty);
			}
			return null;
		}

		static object LoadReflected(string name) {
			return ReflectedPackage.GetPackage(name);
		}

		internal static object LoadFromPath(string name, string fullName, List path) {
			object ret = null;
			foreach (string dirname in path) {
				string pathname = Path.Combine(dirname, name);

				if (Directory.Exists(pathname)) {
					if (File.Exists(Path.Combine(pathname, "__init__.py"))) {
						ret = LoadPackage(fullName, pathname);
						break;
					}
				}
				//!!! add checked for pre-compiled
				string filename = pathname+".py";
				if (File.Exists(filename)) {
					ret = LoadFromSource(fullName, filename, null);
					break;
				}
			}
			return ret;
		}

		static object LoadFromSource(string fullName, string filename, List __path__) {
			//Console.WriteLine("found: " + filename);
			Parser parser = Parser.fromFile(filename);
			Stmt s = parser.parseFileInput();
			ModuleDef mod = new ModuleDef(Name.make(fullName), s);

			string outname = fullName+".exe"; //Path.Combine(dirname.value, name.value+".exe");
			module pmod = mod.Generate(filename);
			if (__path__ != null) pmod.__setattr__("__path__", __path__);

			//Put this in modules dict so we won't reload with circular imports
			sys.modules[fullName] = pmod;

			pmod.init();
			return pmod;
		}

		static object LoadPackage(string fullName, string dirname) {
			List __path__ = Ops.MakeList(dirname);
			object pmod = LoadFromSource(fullName, Path.Combine(dirname, "__init__.py"), __path__);
			return pmod;
		}
	}
}
