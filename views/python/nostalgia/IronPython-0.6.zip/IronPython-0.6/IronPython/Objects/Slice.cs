/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Text;

namespace IronPython.Objects {
	[PythonType("slice")]
	public class Slice {
		public readonly object start, stop, step;

		public Slice(object stop): this(null, stop, null) {}
		public Slice(object start, object stop): this(start, stop, null) {}
		public Slice(object start, object stop, object step) {
			this.start = start; this.stop = stop; this.step = step;
		}

		public Tuple indices(int len) {
			int istart, istop, istep;
			indices(len, out istart, out istop, out istep);
			return Tuple.MakeTuple(istart, istop, istep);
		}

		public void indices(int len, out int ostart, out int ostop, out int ostep) {
			if (start == null) ostart = 0;
			else ostart = Ops.FixSliceIndex(Ops.object2int(start), len);

			if (stop == null) ostop = len;
			else ostop = Ops.FixSliceIndex(Ops.object2int(stop), len);

			if (step == null) ostep = 1;
			else ostep = Ops.object2int(step);
		}

		public override string ToString() {
			return string.Format("slice({0}, {1}, {2})", Ops.StringRepr(start), Ops.StringRepr(stop), Ops.StringRepr(step));
		}
	}
}
