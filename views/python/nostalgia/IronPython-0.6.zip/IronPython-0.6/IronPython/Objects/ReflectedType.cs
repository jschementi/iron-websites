/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Reflection;
using System.Collections;
using System.Collections.Specialized;


using IronPython.AST;
using IronPython.Modules;
using IronMath;

namespace IronPython.Objects {
	/// <summary>
	/// Summary description for time.
	/// </summary>
	[PythonType(typeof(PythonType))]
	public class ReflectedType:PythonType,IFancyCallable {
//		public static ReflectedType MakeClass(string mod, string name, Tuple bases, IDictionary dict) {
//			return new ReflectedType(mod, name, bases, dict);
//		}
//
//		public ReflectedType(string name, Tuple bases, IDictionary dict):this("<unknown>", name, bases, dict) {}
//
//		protected ReflectedType(string mod, string name, Tuple bases, IDictionary dict):this(NewTypeMaker.GetNewType(mod, name, bases, dict)) {
//			this.isUserType = true;
//
//			
//			this.dict = new Dict();
////			Tuple keys = Tuple.Make(dict.Keys); //!!! should probably sort
////			DictFactory f = DictBuilder.GetCustomDictFactory(keys);
////			this.dict = f();
//
//			//!!! cut-and-paste from initialize
//			this.initialized = true;
//
//			foreach (MethodInfo mi in type.GetMethods()) {
//				if (mi.Name == "MakeNew") {
//					if (init == null) init = BuiltinFunction.Make(mi);
//					else ((BuiltinFunction)init).AddMethod(mi);
//				}
//			}
//			if (init == null) {
//				foreach (ConstructorInfo ci in type.GetConstructors()) {
//					AddReflectedConstructor(ci);
//				}
//			}
//		
//			this.CreateInitCode();
//
//			this.__name__ = name; //mod + '.' + name;
//			this.rawBases = bases;
//			foreach (ReflectedType baseType in bases) {
//				baseType.subclasses.Add(this);
//			}
//
//			//!!!newType.GetField("__class__").SetValue(null, rt);
//			//!!!Ops.RegisterDynamicType(newType, rt);
//
//			IDictionaryEnumerator i = dict.GetEnumerator();
//			while (i.MoveNext()) {
//				this.SetSlot((string)i.Key, i.Value);
//				//rt.dict[i.Key] = i.Value;
//			}
//		}

		public static ReflectedType FromType(Type type) {
			return new ReflectedType(type);
		}

		public ReflectedType effectivePythonType = null;

//		public static ReflectedType Make(string name, Tuple bases, IDictionary dict) {
//			return new ReflectedType(name, bases, dict);
//		}

		

//		public readonly Type type;
		//internal ICallable init = null; //Constructor init = null;
//		internal bool isUserType = false;

//		public Dict dict;

//		internal Tuple rawBases = null;

		// Constructor only makes the mapping between the Type and ReflectedType objects
		// All other initialization is done lazily only when needed
		public ReflectedType(Type type):base(type) {
			__name__ = GetName(type);
		}

		public override Tuple __bases__ {
			get {
				//!!! need to cache this to avoid Tuple creation overhead
				if (type.BaseType == null) return Tuple.MakeTuple();
				else return Tuple.MakeTuple(Ops.GetDynamicTypeFromType(type.BaseType)); //??? add interfaces
			}
			set {
				throw Ops.TypeError("can't set bases for built-in type");
			}
		}

		//This has Python's semantics that a type issubclassof itself, this is different than Type.IsSubclassOf
		public override bool IsSubclassOf(object other) {
			ReflectedType rt = other as ReflectedType;
			if (rt == null) return false;

			if (other == this) return true;

			if (type == rt.type || type.IsSubclassOf(rt.type)) return true;
			Type otherTypeToExtend = rt.GetTypeToExtend();
			if (otherTypeToExtend != null && otherTypeToExtend != rt.type) {
				if (type.IsSubclassOf(otherTypeToExtend) || type == otherTypeToExtend) return true;
			}

			if (effectivePythonType != null) return effectivePythonType.IsSubclassOf(other);
			return false;
		}

		private string GetName(Type type) {
			if (type == typeof(object)) { return "object"; } //???
			PythonTypeAttribute attr = (PythonTypeAttribute)
				Attribute.GetCustomAttribute(type, typeof(PythonTypeAttribute));
			if (attr != null) {
				if (attr.impersonateType != null) {
					this.effectivePythonType = (ReflectedType)Ops.GetDynamicTypeFromType(attr.impersonateType);
				}
				return attr.name;
			} else {
				return type.FullName;
			}
		}


		private bool initialized = false;
		public override void Initialize() {
			if (initialized) return;
			initialized = true;

			dict = new Dict();

			//!!! how to best handle inheritance...
			//??? Would it make things clearer or faster to use type.GetMembers()?
			foreach (ConstructorInfo ci in type.GetConstructors()) {
				AddReflectedConstructor(ci);
			}

			foreach (MethodInfo mi in type.GetMethods()) {
				AddReflectedMethod(mi);
			}

			foreach (FieldInfo fi in type.GetFields()) {
				AddReflectedField(fi);
			}

			foreach (PropertyInfo pi in type.GetProperties()) {
				AddReflectedProperty(pi);
			}

			foreach (EventInfo pi in type.GetEvents()) {
				AddReflectedEvent(pi);
			}

			foreach (Type ty in type.GetNestedTypes()) {
				// !!! todo
			}

			AddOps();

			AddPythonProtocolMethods();

			MaybeOptimizeMethods();

			CreateInitCode();

			AddProtocolWrappers();
		}

		protected void CreateInitCode() {
			// Build the appropriate __new__ method to expose to the world
			if (!dict.Contains("__new__")) {
				dict["__new__"] = new NewMethod(this);
			}
			if (dict.Contains("MakeNew")) init = (ICallable)dict["MakeNew"];
			if (dict.Contains("Make")) init = (ICallable)dict["Make"];
		}


		protected virtual void AddOps() {
		}

		private static bool ShouldOptimize(Type type) {
			//??? We need to figure out how much code to optimize

			if (!Options.OPTIMIZE_REFLECT_CALLS) return false;

			if (type == typeof(int)) return true;
			if (type == typeof(bool)) return true;
			if (type == typeof(double)) return true;
			if (type == typeof(string)) return true;
			if (type == typeof(object)) return true;

			if (type.FullName.StartsWith("IronPython.")) return true;
			if (type.FullName.StartsWith("IronMath.")) return true;

			return false;
		}


		protected virtual void MaybeOptimizeMethods() {
			if (ShouldOptimize(this.type)) {
				ReflectOptimizer.GenerateFunctions(this);
			}
		}


		private void AddReflectedConstructor(ConstructorInfo ci) {
			if (!ci.IsPublic) return; //???
			if (init == null) {
				init = new ReflectedConstructor(ci);
			} else {
				((ReflectedConstructor)init).Add(ci); //!!! dangerous cast
			}
		}

		private void AddReflectedMethod(MethodInfo mi) {
			object existingMethod = dict[mi.Name];
			if (existingMethod == null) {
				dict[mi.Name] = new ReflectedMethod(mi);
			} else if (existingMethod is ReflectedMethod) {
				((ReflectedMethod)existingMethod).Add(mi);
			} else {
				//!!!
				dict[mi.Name] = new ReflectedMethod(mi);
			}
		}

		private void AddReflectedField(FieldInfo fi) {
			dict[fi.Name] = new ReflectedField(fi);
		}

		private void AddReflectedProperty(PropertyInfo info) {
			dict[info.Name] = new ReflectedProperty(info);
		}

		private void AddReflectedEvent(EventInfo info) {
			dict[info.Name] = new ReflectedEvent(info, null);
		}

		public static object NextMethod(object self) {
			IEnumerator i = (IEnumerator)self;
			if (i.MoveNext()) return i.Current;
			throw Ops.StopIteration();
		}

		public static object ReprMethod(object self) {
			return self.ToString();
		}


		public static object GetMethod(object self, object instance, object context) {
			return ((IDescriptor)self).__get__(instance, context);
		}

		public static object CallMethod(object self, params object[] args) {
			return ((ICallable)self).Call(args);
		}

		private bool IsOptimizedMethod(ParameterInfo[] pis) {
			//if (true) return false; //!!! waiting on these to optimize later

			if (!Options.OPTIMIZE_REFLECT_CALLS) return false;

			foreach (ParameterInfo pi in pis) {
				if (pi.ParameterType != typeof(object)) return false;
			}
			return true;
		}

//		//??? don't like this design
		private void AddProtocolMethod(string pythonName, string methodName) {
			if (dict.Contains(pythonName)) return;

			MethodInfo mi = typeof(ReflectedType).GetMethod(methodName);
			object meth;
			if (IsOptimizedMethod(mi.GetParameters())) meth = BuiltinFunction.Make(mi);
			else meth = new ReflectedUnboundMethod(mi);
			if (meth == null) throw new NotImplementedException(methodName);
			dict[pythonName] = meth;
		}


		protected void AddPythonProtocolMethods() {
//			if (isUserType) return; // these are expected to be defined with Pythonic names in user types
//
//			//Console.WriteLine("Adding protocol methods for {0}", __name__);

			if (typeof(IEnumerator).IsAssignableFrom(type)) {
				AddProtocolMethod("next", "NextMethod");
			}

			MethodInfo toStringMethod = type.GetMethod("ToString", Type.EmptyTypes);
			if (toStringMethod != null && toStringMethod.DeclaringType != typeof(object)) {
				AddProtocolMethod("__repr__", "ReprMethod");
			}

			if (typeof(IDescriptor).IsAssignableFrom(type)) {
				AddProtocolMethod("__get__", "GetMethod");
			}
			if (typeof(ICallable).IsAssignableFrom(type)) {
				AddProtocolMethod("__call__", "CallMethod");
			}
//
//			AddProtocolMethod("__repr__", "ReprMethod");
//			AddProtocolMethod("__getattribute__", "GetAttributeMethod");
//			AddProtocolMethod("__setattr__", "SetAttrMethod");
		}


		public override string ToString() {
			if (effectivePythonType != null) return effectivePythonType.ToString();
			return string.Format("<type {0}>", Ops.StringRepr(__name__));
		}

		public override bool Equals(object obj) {
			if (effectivePythonType != null) {
				if ((object)effectivePythonType == obj) return true;
				if (obj is ReflectedType && (object)((ReflectedType)obj).effectivePythonType == (object)effectivePythonType) return true;
			}
			return (object)this == obj; 
		}


		public override bool GetAttr(object self, string name, out object ret) {
			object slot = RawGetSlot(name);
			if (slot != null) {
				ret = Ops.GetDescriptor(slot, self, this);
				return true;
			}

			if (name == "__class__") { ret = this; return true; }

			ret = null;
			return false;
		}

		public override void SetAttr(object self, string name, object value) {
			object slot = RawGetSlot(name);
			if (slot == null) {
				throw new Exception("no slot " + name);
			}
			Ops.SetDescriptor(slot, self, value);
		}

		public override void DelAttr(object self, string name) {
			object slot = RawGetSlot(name);
			if (slot == null) {
				throw new Exception("no slot " + name);
			}
			if (Ops.DelDescriptor(slot, self)) return;
			dict.Remove(name);
		}

		protected override void RawSetSlot(string name, object value) {
			throw Ops.TypeError("can't set attributes of built-in/extension type '{0}'", __name__);
		}




//		internal object RawGetSlot(string name) {
//			Initialize();
//			object ret = dict[name];
//			if (ret != null) return ret;
//
//			if ((object)name == (object)"__dict__") { return dict; }
//			if ((object)name == (object)"__getattribute__" && __getattribute__ != null) { return __getattribute__; }
//			if ((object)name == (object)"__setattr__" && __setattr__ != null) { return __setattr__; }
//			if ((object)name == (object)"__cmp__" && __cmp__ != null) { return __cmp__; }
//			if ((object)name == (object)"__setitem__" && __setitem__ != null) { return __setitem__; }
//			return null;
//		}
//
//		internal void RawSetSlot(string name, object value) {
//			Initialize();
//			dict[name] = value;
//		}
//
//		internal void RawRemoveSlot(string name) {
//			Initialize();
//			dict.Remove(name);
//		}		

		#region IDynamicObject Members
		public override DynamicType GetDynamicType() {
			return Ops.GetDynamicTypeFromType(typeof(ReflectedType)); //!!! stick in a static
		}
		#endregion

		#region ICallable Members
		public override object Call(params object[] args) {
			Initialize();
			return init.Call(args);
		}
		#endregion

		#region IFancyCallable Members

		object IronPython.Objects.IFancyCallable.Call(object[] args, string[] names) {
			Initialize();
			object[] newArgs = new object[args.Length - names.Length];
			Array.Copy(args, 0, newArgs, 0, newArgs.Length);
			object ret = init.Call(newArgs);
			for (int i=0; i < names.Length; i++) {
				Ops.SetAttr(ret, names[i], args[i+newArgs.Length]);
			}

			return ret;
		}

		#endregion
	}

	public class OpsReflectedType:ReflectedType {
		protected Type extensibleType;
		protected Type opsType;
		public OpsReflectedType(string name, Type baseType, Type opsType, Type extensibleType):base(baseType) {
			this.extensibleType = extensibleType;
			this.__name__ = name;
			this.opsType = opsType;
			
			//???Initialize();
		}

		public override Type GetTypeToExtend() {
			return extensibleType;
		}


		protected override void AddOps() {
			foreach (MethodInfo mi in opsType.GetMethods()) {
				AddReflectedUnboundMethod(mi);
			}
		}

		private void AddReflectedUnboundMethod(MethodInfo mi) {
			if (!mi.IsStatic) return;

			//Console.WriteLine("adding: " + mi);
			object existingMember = dict[mi.Name];
			if (existingMember == null || !(existingMember is ReflectedUnboundMethod)) { //??? this is destructive
				dict[mi.Name] = new ReflectedUnboundMethod(mi);
			} else {
				((ReflectedUnboundMethod)existingMember).Add(mi);
			}
		}

		public override bool IsSubclassOf(object other) {
			//!!! This is an ugly special case to handle the fact the Python bool extends Python int
			if (type == typeof(bool)) {
				ReflectedType rt = other as ReflectedType;
				if (rt == null) return false;
				return rt.type == typeof(bool) || rt.type == typeof(int);
			}
			return base.IsSubclassOf(other);
		}

	}


	public class ReflectedUnboundMethod:ReflectedMethod {
		public ReflectedUnboundMethod(MethodInfo info): base(info) { }

		private ReflectedUnboundMethod(MethodBase[] infos, object instance): base(infos, instance) {}

		protected override object GetInstance() { return null; }

		//!!! performance improvements by handling IFastCallable
		public override object Call(params object[] args) {
			if (instance == null) return base.Call (args);
			
			object[] nargs = new object[args.Length+1];
			nargs[0] = instance;
			args.CopyTo(nargs, 1);

			return base.Call(nargs);
		}


		#region IDescriptor Members

		public override object __get__(object instance, object context) {
			if (instance != null) {
				return new ReflectedUnboundMethod(infos, instance);
			} else {
				return this;
			}
		}

		#endregion
	}


	public class NewMethod:ICallable {
		private ReflectedType rt;
		public NewMethod(ReflectedType rt) {
			this.rt = rt;
		}

		#region ICallable Members

		public object Call(params object[] args) {
			PythonType targetType = (PythonType)Ops.ConvertTo(args[0], typeof(PythonType));
			
			//!!!
//			if (targetType.isUserType) {
//				if (!targetType.IsSubclassOf(rt)) {
//					throw Ops.TypeError("{0} is not a subclass of {1}", targetType.__name__, rt.__name__);
//				}
//			} else {
//				if (targetType != rt) {
//					throw Ops.TypeError("call is not safe");
//				}
//			}


			//!!! This is trying to capture the weirdness of __new__ methods in Python
			if (PythonType.GetMaxArgs(targetType.init) == 0) {// is ReflectedMethodBase && ((ReflectedMethodBase)targetType.init).GetMaxArgs() == 0) {
				return targetType.init.Call();
			} else {
				object[] newArgs = new object[args.Length-1];
				Array.Copy(args, 1, newArgs, 0, newArgs.Length);
				object ret = targetType.init.Call(newArgs);

//				if (ret is ISuperDynamicObject) {
//					((ISuperDynamicObject)ret).SetDynamicType(targetType);
//				}
				return ret;
			}
		}

		#endregion

		public override string ToString() {
			return string.Format("<method {0}.__new__>", rt.__name__);
		}
	}

}
