/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;

namespace IronPython.Objects {
	[PythonType("staticmethod")]
	public class StaticMethod:IDescriptor {
		private object func;

		public StaticMethod(object func) {
			this.func = func;
		}

		#region IDescriptor Members
		public object __get__(object instance, object owner) {
			return func;
		}
		#endregion
	}

	[PythonType("classmethod")]
	public class ClassMethod:IDescriptor {
		private object func;

		public ClassMethod(object func) {
			this.func = func;
		}

		#region IDescriptor Members
		public object __get__(object instance, object context) {
			return new Method(func, context);
		}
		#endregion
	}

	[PythonType("property")]
	public class Property:IDataDescriptor {
		public object fget, fset, fdel, __doc__;

		public Property(object fget):this(fget, null, null, null) {}
		public Property(object fget, object fset):this(fget, fset, null, null) {}
		public Property(object fget, object fset, object fdel):this(fget, fset, fdel, null) {}

		public Property(object fget, object fset, object fdel, object doc) {
			this.fget = fget; this.fset = fset; this.fdel = fdel; this.__doc__ = doc;
		}
		
		#region IDataDescriptor Members
		public object __get__(object instance, object context) {
			if (fget != null) return Ops.Call(fget, instance);
			throw Ops.AttributeError("unreadable attribute");
		}

		public void __set__(object instance, object value) {
			if (fset != null) {
				Ops.Call(fset, instance, value);
			} else {
				throw Ops.AttributeError("readonly attribute");
			}
		}
		public void __delete__(object instance) {
			if (fdel != null) {
				Ops.Call(fdel, instance);
			} else {
				throw Ops.AttributeError("undeletable attribute");
			}
		}
		#endregion
	}

}