/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;

namespace IronPython.Objects {

	public interface ICallable {
		object Call(params object[] args);
	}

	public interface IFancyCallable {
		object Call(object[] args, string[] names);
	}

	public interface IFastCallable:ICallable {
		#region Generated FastCallable methods
		object Call();
		object Call(object arg0);
		object Call(object arg0, object arg1);
		object Call(object arg0, object arg1, object arg2);
		object Call(object arg0, object arg1, object arg2, object arg3);
		#endregion
	}

	public interface IDynamicObject {
		DynamicType GetDynamicType();
	}

	public interface ISuperDynamicObject:IDynamicObject {
		Dict GetDict();
		void SetDict(Dict dict);

		void SetDynamicType(UserType newType);  //??? maybe PythonType
	}

	public interface ICustomAttributes {
		object __getattribute__(string name);
		void __setattr__(string name, object value);
		void __delattr__(string name);

		List __attrs__();  //!!! probably should be tuple
	}

	public interface ICodeFormattable {
		string ToCodeString();
	}

	public interface IDescriptor {
		object __get__(object instance, object owner);
	}

	public interface IDataDescriptor:IDescriptor {
		void __set__(object instance, object value);
		void __delete__(object instance);
	}

	public interface IPythonContainer {
		int __len__();
		bool __contains__(object value);
		//???object __iter__(); //??? this vs. IEnumerable
	}


	public interface ISequence:IPythonContainer {
		object __add__(object other);  //??? require that other be ISequence
		object __mul__(int count);

		object __getitem__(int index);
		object __getitem__(Slice slice);
		//??? Do we need backwards compat support for __*slice__ methods
	}

	public interface IMutableSequence:ISequence {
		void __setitem__(int index, object value);
		void __setitem__(Slice slice, object value);
		
		void __delitem__(int index);
		void __delitem__(Slice slice);
	}

	public interface IMapping:IPythonContainer {
		object get(object key);
		object get(object key, object defaultValue);

		object __getitem__(object key);
		void __setitem__(object key, object value);
		void __delitem__(object key);
	}
}
