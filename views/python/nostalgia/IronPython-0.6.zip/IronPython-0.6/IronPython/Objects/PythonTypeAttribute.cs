/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;

namespace IronPython.Objects
{
	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Interface, Inherited=false)]
	public class PythonTypeAttribute:Attribute {
		public readonly string name;
		public readonly Type impersonateType;
		public PythonTypeAttribute(string name) {
			this.name = name;
		}

		public PythonTypeAttribute(Type impersonateType) {
			this.impersonateType = impersonateType;
		}
	}
}
