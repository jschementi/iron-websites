/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;
using System.Collections.Specialized;

using System.Reflection;

using IronPython.AST;
using IronPython.Modules;

namespace IronPython.Objects {
	public class Frame {
		public IDictionary f_locals, f_globals;

		public ReflectedType __builtin__;

		public module __module__;

		public Frame(module mod) {
			__module__ = mod;
			f_globals = f_locals = mod.__dict__;
			__builtin__ = (ReflectedType)Ops.GetDynamicTypeFromType(typeof(__builtin__));
		}


		public Frame(module mod, IDictionary globals, IDictionary locals) {
			__module__ = mod;
			f_globals = globals;
			f_locals = locals;
			__builtin__ = (ReflectedType)Ops.GetDynamicTypeFromType(typeof(__builtin__));
		}

		public object GetLocal(string name) {
			return f_locals[name];
		}

		public void SetLocal(string name, object value) {
			f_locals[name] = value;
		}

		public object GetGlobal(string name) {
			object ret = f_globals[name];
			if (ret != Ops.Missing) return ret;
			ret = __builtin__.__getattribute__(name);
			if (ret != Ops.Missing) return ret;

			throw Ops.NameError("name '{0}' is not defined", name);
		}

		public void SetGlobal(string name, object value) {
			f_globals[name] = value;
		}
	}

	public abstract class FrameCode {
		public abstract object Run(Frame frame);

		public override string ToString() {
			return string.Format("<code {0}>", this.GetType().Name);
		}
	}
}
