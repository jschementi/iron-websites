/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Text;
using System.Collections;
using System.Reflection;

using IronMath;

namespace IronPython.Objects {

	public class Int64Ops {
		public static ReflectedType MakeDynamicType(ReflectedType integerType) {
			OpsReflectedType ret = new OpsReflectedType("long", typeof(long), typeof(Int64Ops), null); //typeof(ExtensibleInt));
			ret.effectivePythonType = integerType;
			return ret;
		}

//		public static int __cmp__(int self, object obj) {
//			int oi = Ops.object2int(obj);
//			return self == oi ? 0 : (self < oi ? -1 : +1);
//		}
//
//		public static object Make(string s, int radix) {
//			return LiteralParser.ParseInteger( s, radix);
//		}		
//
//		public static object Make(object o) {
//			if (o is string) return LiteralParser.ParseInteger( (string) o, 10);
//			if (o is double) return (int) (double)o;
//
//			return Ops.object2int(o);
//		}
	
		public static object Abs(long x) {
			return Math.Abs(x);
		}

		private static object TrueDivide(long x, long y) {
			return (double)x / (double)y;
		}
//
//		public static int PowerMod(int x, int power, int mod) {
//			if (power == 0) return 1;
//			if (power < 0) throw new ArgumentOutOfRangeException("power", power, "power must be >= 0");
//			long factor = x;
//			long result = 1;
//
//			while (power != 0) {
//				if ( (power & 1) != 0) result = result*factor % mod;
//				factor = factor*factor % mod; //???
//				power >>= 1;
//			}
//			return (int)result;
//		}
//
//		public static object PowerMod(int x, object y, object z) {
//			return PowerMod(x, (int)y, (int)z);
//		}
//
//		private static object Power(int x, int power) {
//			if (power == 0) return 1;
//			if (power < 0) throw new ArgumentOutOfRangeException("power", power, "power must be >= 0");
//			int factor = x;
//			int result = 1;
//			int savePower = power;
//			try {
//				checked {
//					while (power != 0) {
//						if ( (power & 1) != 0) result = result*factor;
//						factor = factor*factor;
//						power >>= 1;
//					}
//					return result;
//				}
//			} catch (OverflowException) {
//				return integer.make(x).pow(savePower);
//			}
//		}

		public static object Divide(long x, object other) {
			return FloorDivide(x, other);
		}

		public static object Equals(long x, object other) {
			if (other is int) return Ops.bool2object(x == (int)other);
			else if (other is long) return Ops.bool2object(x == (long)other);
			else if (other is double) return Ops.bool2object(x == (double)other);
			else if (other is integer) return Ops.bool2object((integer)x == (integer)other);
			else if (other is Complex64) return Ops.bool2object(x == (Complex64)other);

			return Ops.NotImplemented;
		}

		#region Generated Int64Ops
		
		public static object Add(long x, object other) {
		    if (other is int) {
		        int y = (int)other;
		        try {
		            return Ops.long2object(checked(x + y));
		        } catch (OverflowException) {
		            return integer.make(x) + y; //(integer)x + y;
		        }
		    } else if (other is long) {
		        long y = (long)other;
		        try {
		            return checked(x + y);
		        } catch (OverflowException) {
		            return integer.make(x) + y;
		        }
		    } else if (other is integer) {
		        return integer.make(x) + (integer)other;
		    } else if (other is double) {
		        return x + (double)other;
		    } else if (other is Complex64) {
		        return Complex64.MakeReal(x) + (Complex64)other;
		    }
		    return Ops.NotImplemented;
		}
		
		
		public static object Subtract(long x, object other) {
		    if (other is int) {
		        int y = (int)other;
		        try {
		            return Ops.long2object(checked(x - y));
		        } catch (OverflowException) {
		            return integer.make(x) - y; //(integer)x - y;
		        }
		    } else if (other is long) {
		        long y = (long)other;
		        try {
		            return checked(x - y);
		        } catch (OverflowException) {
		            return integer.make(x) - y;
		        }
		    } else if (other is integer) {
		        return integer.make(x) - (integer)other;
		    } else if (other is double) {
		        return x - (double)other;
		    } else if (other is Complex64) {
		        return Complex64.MakeReal(x) - (Complex64)other;
		    }
		    return Ops.NotImplemented;
		}
		
		
		public static object Power(long x, object other) {
		    return Ops.NotImplemented;
		}
		
		
		public static object Multiply(long x, object other) {
		    if (other is int) {
		        int y = (int)other;
		        try {
		            return Ops.long2object(checked(x * y));
		        } catch (OverflowException) {
		            return integer.make(x) * y; //(integer)x * y;
		        }
		    } else if (other is long) {
		        long y = (long)other;
		        try {
		            return checked(x * y);
		        } catch (OverflowException) {
		            return integer.make(x) * y;
		        }
		    } else if (other is integer) {
		        return integer.make(x) * (integer)other;
		    } else if (other is double) {
		        return x * (double)other;
		    } else if (other is Complex64) {
		        return Complex64.MakeReal(x) * (Complex64)other;
		    }
		    return Ops.NotImplemented;
		}
		
		
		public static object FloorDivide(long x, object other) {
		    if (other is int) {
		        int y = (int)other;
		        try {
		            return Ops.long2object(checked(x / y));
		        } catch (OverflowException) {
		            return integer.make(x) / y; //(integer)x / y;
		        }
		    } else if (other is long) {
		        long y = (long)other;
		        try {
		            return checked(x / y);
		        } catch (OverflowException) {
		            return integer.make(x) / y;
		        }
		    } else if (other is integer) {
		        return integer.make(x) / (integer)other;
		    } else if (other is double) {
		        return x / (double)other;
		    } else if (other is Complex64) {
		        return Complex64.MakeReal(x) / (Complex64)other;
		    }
		    return Ops.NotImplemented;
		}
		
		
		public static object TrueDivide(long x, object other) {
		    return Ops.NotImplemented;
		}
		
		
		public static object Mod(long x, object other) {
		    if (other is int) {
		        int y = (int)other;
		        try {
		            return Ops.long2object(checked(x % y));
		        } catch (OverflowException) {
		            return integer.make(x) % y; //(integer)x % y;
		        }
		    } else if (other is long) {
		        long y = (long)other;
		        try {
		            return checked(x % y);
		        } catch (OverflowException) {
		            return integer.make(x) % y;
		        }
		    } else if (other is integer) {
		        return integer.make(x) % (integer)other;
		    } else if (other is double) {
		        return x % (double)other;
		    } else if (other is Complex64) {
		        return Complex64.MakeReal(x) % (Complex64)other;
		    }
		    return Ops.NotImplemented;
		}
		
		
		public static object LeftShift(long x, object other) {
			if (other is int) {
				int y = (int)other;
				//!!!
				if (y > 63) return integer.make(x) << y;
				long ret = x << y;
				if (ret < x) return integer.make(x) << y;
				return Ops.long2object(ret);
			}
		    return Ops.NotImplemented;
		}
		
		
		public static object RightShift(long x, object other) {
		    if (other is int) {
		        int y = (int)other;
		        try {
		            return Ops.long2object(checked(x >> y));
		        } catch (OverflowException) {
		            return integer.make(x) >> y;
		        }
		    }
		    return Ops.NotImplemented;
		}
		
		
		public static object BitwiseAnd(long x, object other) {
		    if (other is int) {
		        int y = (int)other;
		        try {
		            return Ops.long2object(checked(x & y));
		        } catch (OverflowException) {
		            return integer.make(x) & y;
		        }
		    } else if (other is long) {
		        long y = (long)other;
		        try {
		            return checked(x & y);
		        } catch (OverflowException) {
		            return integer.make(x) & y;
		        }
		    } else if (other is integer) {
		        return integer.make(x) & (integer)other;
		    }
		    return Ops.NotImplemented;
		}
		
		
		public static object BitwiseOr(long x, object other) {
		    if (other is int) {
		        int y = (int)other;
		        try {
		            return Ops.long2object(checked(x | y));
		        } catch (OverflowException) {
		            return integer.make(x) | y;
		        }
		    } else if (other is long) {
		        long y = (long)other;
		        try {
		            return checked(x | y);
		        } catch (OverflowException) {
		            return integer.make(x) | y;
		        }
		    } else if (other is integer) {
		        return integer.make(x) | (integer)other;
		    }
		    return Ops.NotImplemented;
		}
		
		
		public static object Xor(long x, object other) {
		    if (other is int) {
		        int y = (int)other;
		        try {
		            return Ops.long2object(checked(x ^ y));
		        } catch (OverflowException) {
		            return integer.make(x) ^ y;
		        }
		    } else if (other is long) {
		        long y = (long)other;
		        try {
		            return checked(x ^ y);
		        } catch (OverflowException) {
		            return integer.make(x) ^ y;
		        }
		    } else if (other is integer) {
		        return integer.make(x) ^ (integer)other;
		    }
		    return Ops.NotImplemented;
		}
		
		#endregion
	}
}
