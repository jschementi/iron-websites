/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Reflection;
using System.Collections;
using System.Collections.Specialized;


using IronPython.AST;
using IronPython.Modules;
using IronMath;

namespace IronPython.Objects {
	/// <summary>
	/// Summary description for time.
	/// </summary>
	[PythonType(typeof(PythonType))]
	public class UserType:PythonType {
		public static UserType MakeClass(string mod, string name, Tuple bases, IDictionary dict) {
			return new UserType(mod, name, bases, dict);
		}

		public object __module__;
//		private Dict dict;
		private Tuple bases;
		//internal ICallable init = null;

		public UserType(string name, Tuple bases, IDictionary dict):this("<unknown>", name, bases, dict) {}

		protected UserType(string mod, string name, Tuple bases, IDictionary dict):base(NewTypeMaker.GetNewType(mod, name, bases, dict)) {			
			this.dict = new Dict();
//			Tuple keys = Tuple.Make(dict.Keys); //!!! should probably sort
//			DictFactory f = DictBuilder.GetCustomDictFactory(keys);
//			this.dict = f();

			foreach (MethodInfo mi in type.GetMethods()) {
				if (mi.Name == "MakeNew") {
					if (init == null) init = BuiltinFunction.Make(mi);
					else ((BuiltinFunction)init).AddMethod(mi);
				}
			}
			if (init == null) {
				throw new NotImplementedException("no MakeNew found");
			}

			this.__name__ = name;
			this.__module__ = mod;
			this.bases = bases;

			foreach (PythonType baseType in bases) {
				baseType.AddSubclass(this);
			}

			//!!!newType.GetField("__class__").SetValue(null, rt);

			IDictionaryEnumerator i = dict.GetEnumerator();
			while (i.MoveNext()) {
				this.dict[i.Key] = i.Value;
				//???this.__setattr__((string)i.Key, i.Value);
				//rt.dict[i.Key] = i.Value;
			}

			AddProtocolWrappers();
		}

		public override Type GetTypeToExtend() {
			return type.BaseType;  //!!! this is not a very satisfactory answer...
		}

		public override Tuple __bases__ {
			get { return bases; }
			set {
				//!!! lots of validation to be done here
				bases = value;
				UpdateFromBases();
			}
		}

		public override bool IsSubclassOf(object other) {
			ReflectedType rt = other as ReflectedType;
			if (rt != null) {
				return type == rt.type || type.IsSubclassOf(rt.type) 
					|| type == rt.GetTypeToExtend() || type.IsSubclassOf(rt.GetTypeToExtend());  //!!! inefficient in most cases
			}

			if (this.Equals(other)) return true;

			foreach (PythonType baseType in bases) {
				if (baseType.IsSubclassOf(other)) return true;
			}
			return false;
		}

		public override string ToString() {
			return string.Format("<class '{0}.{1}'>", __module__, __name__);
		}

//		public bool TryToInvoke(out object ret, object self, string name, params object[] args) {
//			object func;
//			if (GetAttr(self, name, out func)) {
//				ret = Ops.Call(func, args);
//				return true;
//			} else {
//				ret = null;
//				return false;
//			}
//		}
//

		private Dict GetInitializedDict(ISuperDynamicObject self) {
			Dict d = self.GetDict();
			if (d == null) {
				d = new Dict();
				self.SetDict(d);
			}
			return d;
		}

		public override bool GetAttr(object self, string name, out object ret) {
			if (__getattribute__F.IsObjectMethod()) {
				return BaseGetAttr((ISuperDynamicObject)self, name, out ret);
			} else {
				ret = __getattribute__F.Invoke(self, name);
				return true;
			}
		}

		public bool BaseGetAttr(ISuperDynamicObject self, string name, out object ret) {
			Dict d = self.GetDict();
			if (d != null) {
				ret = d.get(name, Ops.Missing);
				if (ret != Ops.Missing) {
					if (self is ReflectedType) ret = Ops.GetDescriptor(ret, null, self);  //???
					return true; 
				}
			}

			object slot = LookupSlot(name);
			if (slot != null) {
				ret = Ops.GetDescriptor(slot, self, this);
				return true;
			}

			if ((object)name == (object)"__dict__") {
				ret = GetInitializedDict(self);
				return true;
			}

			if ((object)name == (object)"__class__") { ret = this; return true; }

			if (!__getattr__F.IsObjectMethod()) {
				ret = __getattr__F.Invoke(self, name);
				return true;
			}

			ret = null;
			return false;
		}

		public override void SetAttr(object self, string name, object value) {
			if (name == "__class__") {
				// check that this is a legal new class
				UserType newType = value as UserType;
				if (newType == null) { 
					throw Ops.TypeError("__class__ must be set to new-style class, not '{0}' object", Ops.GetDynamicType(value).__name__);
				}
				if (newType.type != this.type) {
					throw Ops.TypeError("__class__ assignment: '{0}' object layout differs from '{1}'", __name__, newType.__name__);
				}
				((ISuperDynamicObject)self).SetDynamicType(newType);
				return;
			}

			if (__setattr__F.IsObjectMethod()) {
				BaseSetAttr((ISuperDynamicObject)self, name, value);
			} else {
				__setattr__F.Invoke(self, name, value);
			}
		}

		public void BaseSetAttr(ISuperDynamicObject self, string name, object value) {
			object slot = RawGetSlot(name);
			if (slot != null && Ops.SetDescriptor(slot, self, value)) return;

			Dict d = GetInitializedDict(self);
			d[name] = value;
		}


		public override void DelAttr(object self, string name) {
			//!!! Add support for overriding __delattr__
			object slot = LookupSlot(name);
			if (slot == null) {
				Dict d = GetInitializedDict((ISuperDynamicObject)self); //!!! forces dict init
				if (d.Contains(name)) {
					d.Remove(name);
					return;
				} else {
					throw Ops.AttributeError("no slot named {0} on {1}", name, this.__name__);
				}
			}
			Ops.DelDescriptor(slot, self);
		}

//		public string StrForInstance(ISuperDynamicObject self) {
//			return (string)__str__F.Invoke(self);
//		}

//		public string ReprForInstance(ISuperDynamicObject self) {
//			object ret;
//			if (GetSlotForInstance(self, "__repr__", out ret)) return (string)Ops.Call(ret);
//			return string.Format("<{0} object at {1}>", __name__, Ops.HexId(this));
//		}

//		public object __cmp__ = null;
//		public object GetCompare() {
//			if (!isUserType) return null;
//
//			if (__cmp__ != null) return __cmp__;
//			if (isUserType && rawBases != null) {
//				foreach (ReflectedType rt in rawBases) {
//					object cmp = rt.GetCompare();
//					if (cmp != null) return cmp;
//				}
//			}
//			return null;
//		}

//		public override bool GetAttr(object self, string name, out object ret) {
//			object slot = RawGetSlot(name);
//			if (slot != null) {
//				ret = Ops.GetDescriptor(slot, self, this);
//				return true;
//			}
//
//			if (name == "__class__") { ret = this; return true; }
//
//			ret = null;
//			return false;
//		}
//
//		public override void SetAttr(object self, string name, object value) {
//			object slot = RawGetSlot(name);
//			if (slot == null) {
//				throw new Exception("no slot " + name);
//			}
//			Ops.SetDescriptor(slot, self, value);
//		}
//
//		public override void DelAttr(object self, string name) {
//			object slot = RawGetSlot(name);
//			if (slot == null) {
//				throw new Exception("no slot " + name);
//			}
//			if (Ops.DelDescriptor(slot, self)) return;
//			RawRemoveSlot(name);
//		}
	

		#region IDynamicObject Members

//		public bool GetSlot(string name, out object ret) {
//			if (name == "__subclasses__") {
//				ret = new ReflectedMethod(typeof(ReflectedType).GetMethod("__subclasses__")).__get__(this, null);
//				return true;
//			}
//			object slot = RawGetSlot(name);
//			if (slot != null) {
//				ret = Ops.GetDescriptor(slot, null, this);
//				return true;
//			}
//
//			if (name == "__name__") { ret = __name__; return true; }
//			if (name == "__bases__") { ret = __bases__; return true; }
//
//			//if (name == "__class__") return this;
//
//			ret = null;
//			return false;
//		}
//
//		public void SetSlot(string name, object value) {
//			if (name == "__bases__") { __bases__ = (Tuple)value; return;}
//			if (name == "__getattribute__") { __getattribute__ = value; return; }
//			if (name == "__setattr__") { __setattr__ = value; return; }
//			if (name == "__cmp__") { __cmp__ = value; return; }
//			if (name == "__setitem__") { __setitem__ = value; return; }
//
//
//			object slot = RawGetSlot(name);
//			if (slot != null) {
//				if (Ops.SetDescriptor(slot, null, value)) return;
//			} 
//			if (isUserType) {
//				RawSetSlot(name, value);
//			} else {
//				throw Ops.TypeError("can't set attributes of built-in/extension type '{0}'", __name__);
//			}	
//		}
//
//		public void DelSlot(string name) {
//			if (name == "__getattribute__") { __getattribute__ = null; return; }
//			if (name == "__setattr__") { __setattr__ = null; return; }
//
//			object slot = RawGetSlot(name);
//			if (slot != null) {
//				if (Ops.DelDescriptor(slot, null)) return;
//			} 
//			if (isUserType) {
//				RawRemoveSlot(name);
//			} else {
//				throw Ops.TypeError("can't del attributes of built-in/extension type '{0}'", __name__);
//			}	
//		}



		public override DynamicType GetDynamicType() {
			return Ops.GetDynamicTypeFromType(typeof(UserType));  //!!! should be stuck in a static somewhere for faster lookup
		}

		#endregion

		#region ICallable Members
		public override object Call(params object[] args) {
			//!!! need to do __new__
			object newMethod, newObject;

			if (Ops.GetAttr(this, "__new__", out newMethod)) {
				object[] newArgs = new object[args.Length+1];
				Array.Copy(args, 0, newArgs, 1, args.Length);
				newArgs[0] = this;
				newObject = Ops.Call(newMethod, newArgs);
			} else {
				if (GetMaxArgs(init) == 0) newObject = init.Call(); //!!! hack
				else newObject = init.Call(args);
			}
			ISuperDynamicObject sdo = newObject as ISuperDynamicObject;
			if (sdo != null) {
				sdo.SetDynamicType(this);
			}

			if (newObject == null) return newObject;

			object initFunc;

			if (Ops.GetAttr(newObject, "__init__", out initFunc)) {
				//!!!initFunc = Ops.GetDescriptor(initFunc, newObject, this);
				switch (args.Length) {
					case 0: Ops.Call(initFunc);break;
					case 1: Ops.Call(initFunc, args[0]);break;
					case 2: Ops.Call(initFunc, args[0], args[1]);break;
					default:
						Ops.Call(initFunc, args);
						break;
				}
			}

			return newObject;
		}
//			Initialize();
//			
//			if (isUserType) {
//				ReflectedMethodBase.NoteCall(type); //???
//
//				object[] newArgs = new object[args.Length+1];
//				Array.Copy(args, 0, newArgs, 1, args.Length);
//				newArgs[0] = this;
//				object newObject;
//				if (this is ISuperDynamicObject) {
//					newObject = Ops.Invoke(this, "__new__", newArgs);
//				} else {
//					newObject = Ops.Call(RawGetSlot("__new__"), newArgs);
//				}
//				if (newObject is ISuperDynamicObject) {
//					((ISuperDynamicObject)newObject).SetDynamicType(this);
//				}
//
//				if (newObject == null) return newObject;
//
//
//				//!!! need to do this on newObject
//				object initFunc = LookupSlot("__init__");
//				if (initFunc != null) {
//					initFunc = Ops.GetDescriptor(initFunc, newObject, this);
//					switch (args.Length) {
//						case 0: Ops.Call(initFunc);break;
//						case 1: Ops.Call(initFunc, args[0]);break;
//						case 2: Ops.Call(initFunc, args[0], args[1]);break;
//						default:
//						    Ops.Call(initFunc, args);
//							break;
//					}
//				}
//
//				return newObject;
//			}
//
//			return init.Call(args);
//		}
		#endregion
	}

}
