/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;
using System.Collections.Specialized;

namespace IronPython.Objects {
	public class TypedWrapper:IEnumerable,ICodeFormattable,ICustomAttributes {
		public static TypedWrapper Make(object inst, Type type) {
			TypedWrapper w = new TypedWrapper(inst);
			if (type.IsByRef) return w; //!!!
			w.AddType(Ops.GetDynamicTypeFromType(type));
			return w;
		}

		private static DynamicType baseType = Ops.GetDynamicTypeFromType(typeof(TypedWrapper));

		private object inst;
		private List types = List.Make();

		public TypedWrapper(object inst) {
			this.inst = inst;
			if (inst.GetType().FullName == "System.__ComObject") return;

			this.AddType(Ops.GetDynamicTypeFromType(inst.GetType()));
		}

		public void AddType(DynamicType type) {
			types.Add(type);
		}

		public override string ToString() {
			return inst.ToString();
		}

		#region IEnumerable Members

		public IEnumerator GetEnumerator() {
			IEnumerator i1 = inst as IEnumerator;
			if (i1 != null) return i1;

			IEnumerable i2 = inst as IEnumerable;
			if (i2 != null) return i2.GetEnumerator();

			throw Ops.TypeError("not enumerable");
		}

		#endregion

		#region ICodeFormattable Members

		public string ToCodeString() {
			return string.Format("<wrapped object {0} with types {1}>", inst, types);
		}

		#endregion

		#region ICustomAttributes Members

		public object __getattribute__(string name) {
			object ret;
			if (baseType.GetAttr(this, name, out ret)) return ret;
			foreach (DynamicType t in types) {
				if (t.GetAttr (inst, name, out ret)) return ret;
			}
			return Ops.Missing;
		}

		public void __setattr__(string name, object value) {
			throw new NotImplementedException();
		}

		public void __delattr__(string name) {
			throw new NotImplementedException();
		}

		public List __attrs__() {
			throw new NotImplementedException();
		}

		#endregion
	}
}
