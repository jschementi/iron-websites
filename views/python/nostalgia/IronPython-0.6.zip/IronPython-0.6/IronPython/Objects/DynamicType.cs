/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Reflection;

namespace IronPython.Objects
{
	/// <summary>
	/// Summary description for DynamicType.
	/// </summary>
	public abstract class DynamicType {
		public object __name__;

		#region Generated DynamicType Binary Ops
		
		public virtual object Add(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object ReverseAdd(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object InPlaceAdd(object self, object other) {
		    return Ops.Add(self, other);
		}
		
		public virtual object Subtract(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object ReverseSubtract(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object InPlaceSubtract(object self, object other) {
		    return Ops.Subtract(self, other);
		}
		
		public virtual object Power(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object ReversePower(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object InPlacePower(object self, object other) {
		    return Ops.Power(self, other);
		}
		
		public virtual object Multiply(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object ReverseMultiply(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object InPlaceMultiply(object self, object other) {
		    return Ops.Multiply(self, other);
		}
		
		public virtual object FloorDivide(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object ReverseFloorDivide(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object InPlaceFloorDivide(object self, object other) {
		    return Ops.FloorDivide(self, other);
		}
		
		public virtual object Divide(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object ReverseDivide(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object InPlaceDivide(object self, object other) {
		    return Ops.Divide(self, other);
		}
		
		public virtual object Mod(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object ReverseMod(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object InPlaceMod(object self, object other) {
		    return Ops.Mod(self, other);
		}
		
		public virtual object LeftShift(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object ReverseLeftShift(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object InPlaceLeftShift(object self, object other) {
		    return Ops.LeftShift(self, other);
		}
		
		public virtual object RightShift(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object ReverseRightShift(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object InPlaceRightShift(object self, object other) {
		    return Ops.RightShift(self, other);
		}
		
		public virtual object BitwiseAnd(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object ReverseBitwiseAnd(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object InPlaceBitwiseAnd(object self, object other) {
		    return Ops.BitwiseAnd(self, other);
		}
		
		public virtual object BitwiseOr(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object ReverseBitwiseOr(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object InPlaceBitwiseOr(object self, object other) {
		    return Ops.BitwiseOr(self, other);
		}
		
		public virtual object Xor(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object ReverseXor(object self, object other) {
		    return Ops.NotImplemented;
		}
		public virtual object InPlaceXor(object self, object other) {
		    return Ops.Xor(self, other);
		}
		
		public virtual object LessThan(object self, object other) {
		    return Ops.NotImplemented;
		}
		
		public virtual object GreaterThan(object self, object other) {
		    return Ops.NotImplemented;
		}
		
		public virtual object LessThanOrEqual(object self, object other) {
		    return Ops.NotImplemented;
		}
		
		public virtual object GreaterThanOrEqual(object self, object other) {
		    return Ops.NotImplemented;
		}
		
		public virtual object Equal(object self, object other) {
		    return Ops.NotImplemented;
		}
		
		public virtual object NotEqual(object self, object other) {
		    return Ops.NotImplemented;
		}
		#endregion


		public virtual string Repr(object self) {
			object ret;
			if (Ops.TryToInvoke(self, "__repr__", out ret)) return (string)ret;
			return self.ToString();
		}

		public object __getitem__(object self, object index) {
			return Ops.Invoke(self, "__getitem__", index);
		}

		public void __setitem__(object self, object index, object value) {
			Ops.Invoke(self, "__setitem__", index, value);
		}

		public void __delitem__(object self, object index) {
			Ops.Invoke(self, "__delitem__", index);
		}

		public virtual bool GetAttr(object self, string name, out object ret) {
			ret = null;
			return false;
		}

		public virtual object GetAttr(object self, string name) {
			object ret;
			if (GetAttr(self, name, out ret)) return ret;
			throw Ops.AttributeError("'{0}' object has no attribute '{1}'", this.__name__, name);
		}

		public virtual void SetAttr(object self, string name, object value) {
			throw Ops.AttributeError("'{0}' object has no attribute '{1}'", this.__name__, name);
		}

		public virtual void DelAttr(object self, string name) {
			throw new NotImplementedException();
		}

		public virtual List GetAttrNames(object self) {
			return List.MakeEmptyList(0);
		}

		public virtual bool IsSubclassOf(object other) {
			throw new NotImplementedException();
		}
	}


	public class NoneType:DynamicType {
		public static readonly DynamicType Instance = new NoneType();

		private NoneType():base() {
			__name__ = "NoneType";
		}

		public override bool IsSubclassOf(object other) {
			if (other == this) return true;
			return false;
		}

	}
}
