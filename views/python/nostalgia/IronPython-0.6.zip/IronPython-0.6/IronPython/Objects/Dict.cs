/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;
using System.Collections.Specialized;
using System.Text;

using IronPython.AST;


namespace IronPython.Objects {

	public class Dict:IMapping, IEnumerable,IDictionary,IComparable {
		public static Dict fromkeysAny(object o) {
			Dict ret = new Dict();
			IEnumerator i = Ops.GetEnumerator(o);
			while (i.MoveNext()) {
				ret[i.Current] = null; //!!!
			}
			return ret;
		}

		public static object fromkeys(object o) {
			XRange xr = o as XRange;
			if (xr != null) {
				int n = xr.__len__();
				//Hashtable ret = new Hashtable();
				Dict ret;
				if (Options.MonoWorkaround) ret = new Dict();
				else ret = new Dict(n);
				for (int i=0; i < n; i++) {
					ret[ xr.__getitem__(i) ] = null;
				}
				return ret;
			}
			return fromkeysAny(o);
		}


		protected Dict(bool initData) {
			if (initData) data = new HybridDictionary();
		}
		internal Dict(int size) { data = new HybridDictionary(size); }

		private void AddKeyValue(object o) {
			//!!! optimize for Tuple, List, other easy cases
			//ICollection c = (ICollection)o;
			//!!!if (c.Count != 2) throw Ops.ValueError("dictionary update sequence element has length {0}, 2 required", c.Count);

			IEnumerator i = Ops.GetEnumerator(o); //c.GetEnumerator();
			i.MoveNext();
			object key = i.Current;
			i.MoveNext();
			object value = i.Current;

			this[key] = value;
		}

		public Dict(object o): this() {
			if (o is IDictionary) {
				IDictionaryEnumerator e = ((IDictionary)o).GetEnumerator();
				while (e.MoveNext()) {
					this[e.Key] = e.Value;
				}
			} else {
				IEnumerator i = Ops.GetEnumerator(o);
				while (i.MoveNext()) {
					AddKeyValue(i.Current);
				}
			}
		}
		
		protected HybridDictionary data;
		public Dict(): base() { data = new HybridDictionary(); }

		IEnumerator IEnumerable.GetEnumerator() {
			//!!! this is a hack to allow modification of the dict while iterating over the keys
			return keys().GetEnumerator();  //!!! there's a performance price here that's higher than I'd like
			//return this.Keys.GetEnumerator();
			//return this.Keys.GetEnumerator();
		}

		#region IComparable Members

		public int CompareTo(object obj) {
			if (obj is Dict) {
				List l1 = items();
				l1.sort();

				List l2 = ((Dict)obj).items();
				l2.sort();

				return l1.CompareTo(l2);
			} else {
				return -1;//!!!
			}
		}

		#endregion

		public override bool Equals(object other) {
			if (other is Dict) {
				List l1 = items();
				l1.sort();

				List l2 = ((Dict)other).items();
				l2.sort();

				return l1.Equals(l2);
			} else {
				return false;
			}
		}

		public override int GetHashCode() {
			throw Ops.TypeError("dict objects are unhashable");
		}


		public virtual List keys() {
			return new List(data.Keys);
		}

		public virtual List values() {
			return new List(data.Values);
		}

		public virtual List items() {
			List ret = List.MakeEmptyList(data.Count);
			IDictionaryEnumerator e = data.GetEnumerator();
			while ( e.MoveNext() ) {
				ret.Add( Tuple.MakeTuple(e.Key, e.Value) );
			}
			return ret;
		}


		public override string ToString() {
			StringBuilder buf = new StringBuilder();
			buf.Append("{");
			IDictionaryEnumerator e = data.GetEnumerator();
			bool first = true;
			while ( e.MoveNext() ) {
				if (first) { first = false; }
				else { buf.Append(", "); }
				buf.Append(Ops.StringRepr(e.Key));
				buf.Append(": ");
				buf.Append(Ops.StringRepr(e.Value));
			}
			buf.Append("}");
			return buf.ToString();
		}
		#region IMapping Members

		public virtual int __len__() {
			return data.Count;
		}

		public virtual bool __contains__(object key) {
			return data.Contains(key);
		}

		public virtual object get(object key) {
			return __getitem__(key);
		}

		public virtual object get(object key, object defaultValue) {
			if (data.Contains(key)) return data[key];
			return defaultValue;
		}

		public virtual object setdefault(object key, object defaultValue) {
			if (data.Contains(key)) return data[key];
			data[key] = defaultValue;
			return defaultValue;
		}

		public virtual object __getitem__(object key) {
			//!!! handle missing correctly
			return data[key];
		}

		public virtual void __setitem__(object key, object value) {
			data[key] = value;
		}

		public virtual void __delitem__(object key) {
			data.Remove(key);
		}
		#endregion

		#region IDictionary Members

		public bool IsReadOnly {
			get {
				return false;
			}
		}

		public IDictionaryEnumerator GetEnumerator() {
			return data.GetEnumerator();
		}

		public virtual object this[object key] {
			get {
				return data[key]; //get(key, null);
			}
			set {
				data[key] = value; //__setitem__(key, value); //[key] = value;
			}
		}

		public void Remove(object key) {
			data.Remove(key);
		}

		public virtual bool Contains(object key) {
			return data.Contains(key);
		}

		public void Clear() {
			data.Clear();
		}

		public ICollection Values {
			get {
				return data.Values;
			}
		}

		public void Add(object key, object value) {
			data.Add(key, value);
		}

		public ICollection Keys {
			get {
				return data.Keys;
			}
		}

		public bool IsFixedSize {
			get {
				return data.IsFixedSize;
			}
		}

		#endregion

		#region ICollection Members

		public bool IsSynchronized {
			get {
				return data.IsSynchronized;
			}
		}

		public int Count {
			get {
				return data.Count;
			}
		}

		public void CopyTo(Array array, int index) {
			data.CopyTo(array, index);
		}

		public object SyncRoot {
			get {
				return data.SyncRoot;
			}
		}

		#endregion
	}

	public delegate Dict DictFactory();

	public abstract class CustomDict:Dict {
		public CustomDict():base(false) {
		}

		public virtual object RawGet(object name) {
			if (data != null) return data[name];
			return null; //???
		}

		public virtual void RawSet(object name, object value) {
			if (data == null) data = new HybridDictionary();
			data[name] = value;
		}

		public abstract Tuple RawGetKeys();

		public override object __getitem__(object key) {
			return RawGet(key);
		}

		public override object get(object key, object defaultValue) {
			return RawGet(key); //!!!
		}

		public override void __setitem__(object key, object value) {
			RawSet(key, value);
		}

		public override object this[object key] {
			get {
				return RawGet(key);
			}
			set {
				RawSet(key, value); //data[key] = value; //__setitem__(key, value); //[key] = value;
			}
		}

		public override bool Contains(object key) {
			foreach (object rkey in RawGetKeys()) {
				if (rkey == key) return true;
			}
			if (data != null) return base.Contains(key);
			return false;
		}


		public override List keys() {
			if (data == null) return List.Make(RawGetKeys()); //??? performance
			List ret = base.keys();
			foreach(object key in RawGetKeys()) {
				ret.append(key);
			}
			return ret;
		}
	}
}
