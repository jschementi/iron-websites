/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;

namespace IronPython.Objects {
	[PythonType("enumerate")]
	public class Enumerate:IEnumerator {
		private readonly IEnumerator iter;
		private int index = 0;
		public Enumerate(object iter) {
			this.iter = Ops.GetEnumerator(iter);
		}


		#region IEnumerator Members

		public void Reset() {
			throw new NotImplementedException();
		}

		public object Current {
			get {
				return Tuple.MakeTuple(index++, iter.Current);
			}
		}

		public bool MoveNext() {
			return iter.MoveNext();
		}

		#endregion
	}

	public class PythonEnumerator:IEnumerator {
		private readonly object baseObject;
		private readonly object nextMethod;
		private object current = null;

		public PythonEnumerator(object iter) {
			this.baseObject = iter;
			this.nextMethod = Ops.GetAttr(iter, "next");
		}


		#region IEnumerator Members

		public void Reset() {
			throw new NotImplementedException();
		}

		public object Current {
			get {
				return current;
			}
		}

		public bool MoveNext() {
			try {
				current = Ops.Call(nextMethod);
				return true;
			} catch (PythonStopIteration) {
				return false;
			}
		}

		#endregion
	}

}
