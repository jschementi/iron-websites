/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;

using System.Resources;
using System.Diagnostics;
using System.Diagnostics.SymbolStore;
using System.Reflection;
using System.Reflection.Emit;

using System.Security;
using System.Security.Policy;
using System.Security.Permissions;


namespace IronPython.AST {
	public class AssemblyGen {
		public readonly AssemblyBuilder myAssembly;
		public readonly ModuleBuilder myModule;
		public readonly ISymbolDocumentWriter sourceFile;
		public readonly string outFileName;

		//public readonly bool staticModules = false;  //!!! looks like ~1% pystone change

		//!!! assumption here is one source file per assembly, that's very pythonic...
		public AssemblyGen(string sourceFileName, string moduleName, string outFileName) {
			this.outFileName = outFileName;

			AssemblyName asmname = new AssemblyName();

			AppDomain domain = System.Threading.Thread.GetDomain();
			
//			SecurityPermission perm = new SecurityPermission(SecurityPermissionFlag.AllFlags &
//				SecurityPermissionFlag.SkipVerification);
//
//
//			//Evidence evidence = domain.Evidence;
//			//evidence = new Evidence();
			PermissionSet forbidden = new PermissionSet(null);
			forbidden.SetPermission(new SecurityPermission(SecurityPermissionFlag.SkipVerification));
//
//			PermissionSet optional = new PermissionSet(null);
//
//			PermissionSet required = new PermissionSet(null);
//			//required.AddPermission(new FileIOPermission(PermissionState.Unrestricted));
//			//required.AddPermission(new ReflectionPermission(ReflectionPermissionFlag.AllFlags)); //(PermissionState.Unrestricted));



			asmname.Name = moduleName; //"temp"; //??? does this matter at all???
			if (outFileName == null) {
				myAssembly = domain.
					DefineDynamicAssembly(asmname, AssemblyBuilderAccess.Run,
						domain.Evidence); //, null, null, forbidden); // tweak

				myModule =
					myAssembly.DefineDynamicModule(moduleName);
			} else {
				myAssembly = domain.
					DefineDynamicAssembly(asmname, AssemblyBuilderAccess.RunAndSave,
							domain.Evidence, null, null, forbidden); //required, optional, forbidden); // tweak
				myModule =
					myAssembly.DefineDynamicModule(outFileName, outFileName, true);
			}

				//??? one of these is not needed ???
			const bool disableJitOptimizer = true, enableTracking = true;

			myAssembly.SetCustomAttribute(new CustomAttributeBuilder(
				typeof(DebuggableAttribute).GetConstructor(
				new Type[] { typeof(bool), typeof(bool) }),
				new Object[] { disableJitOptimizer, enableTracking } ));


			//!!! these specs seem to have ZERO effect
//			myAssembly.SetCustomAttribute(new CustomAttributeBuilder(
//				typeof(SecurityPermissionAttribute).GetConstructor(new Type[] { typeof(SecurityAction) }),
//				new object[] { SecurityAction.RequestRefuse },
//				new PropertyInfo[] {typeof(SecurityPermissionAttribute).GetProperty("SkipVerification")},
//				new object[] {true}));

			myModule.SetCustomAttribute(new CustomAttributeBuilder(
				typeof(DebuggableAttribute).GetConstructor(new Type[] { typeof(bool), typeof(bool) }),
				new Object[] { disableJitOptimizer, enableTracking } ));

//			myModule.SetCustomAttribute(new CustomAttributeBuilder(
//				typeof(SecurityPermissionAttribute).GetConstructor(new Type[] { typeof(SecurityAction) }),
//				new object[] { SecurityAction.RequestRefuse },
//				new PropertyInfo[] {typeof(SecurityPermissionAttribute).GetProperty("SkipVerification")},
//				new object[] {true}));


			sourceFile =
				myModule.DefineDocument(sourceFileName, 
				//Guid.NewGuid(), Guid.NewGuid()); //!!! learn about guids
				SymLanguageType.Pascal, SymLanguageVendor.Microsoft, SymDocumentType.Text);
		}

		public Assembly dumpAndLoad() {
			//???asmbuild.SetEntryPoint(cg.methodBuilder);

			myAssembly.Save(outFileName);
			//return myAssembly;
			return Assembly.LoadFrom(outFileName);
		}

		public TypeGen defineType(string name, Type parent) {
			TypeBuilder tb = myModule.DefineType(name, TypeAttributes.Public);
			tb.SetParent(parent);
			return new TypeGen(this, tb);
		}
	}
}
