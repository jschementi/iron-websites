/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;

namespace IronPython.AST
{
	public abstract class Node
	{
		public int start, end, line=-1;

		public void setLoc(int start, int end) {
			this.start = start; this.end = end;
		}
	}
}
