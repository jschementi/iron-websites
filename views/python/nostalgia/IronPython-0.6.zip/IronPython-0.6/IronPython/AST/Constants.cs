/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Reflection;

namespace IronPython.AST
{
	/// <summary>
	/// Summary description for Constants.
	/// </summary>
	public class Constants
	{
		public static Type typeofPyObjectAddr = Type.GetType("IronPython.Objects.PyObject&");
		public static Type typeofObjectAddr = Type.GetType("System.Object&");
	
		public static Type[] makeArray(Type t, int n) {
			Type[] ret = new Type[n];
			for (int i=0; i < n; i++) ret[i] = t;
			return ret;
		}

		public static Type[] GetTypes(ParameterInfo[] pis) {
			Type[] ret = new Type[pis.Length];
			for (int i=0; i < pis.Length; i++) ret[i] = pis[i].ParameterType;
			return ret;
		}
	}
}
