/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;
using System.Collections.Specialized;

using System.Reflection;
using System.Reflection.Emit;

using IronPython.Objects;

namespace IronPython.AST {
	public abstract class Namespace {
		public Hashtable slots = new Hashtable(); //!!! vis issue
		public readonly Namespace parent;

		public string privatePrefix = null;

		public Namespace(Namespace parent) {
			this.parent = parent;
		}


		public bool IsPrivateName(Name name) {
			string s = name.GetString();
			return s.StartsWith("__") && !s.EndsWith("__");
		}

		public Name FixName(Name name) {
			if (!IsPrivateName(name)) return name;

			if (privatePrefix != null) return Name.make(string.Format("_{0}{1}", privatePrefix, name.GetString()));

			if (parent != null) return parent.FixName(name);
			return name;
		}

		private Slot makeGlobalSlot(Name name) {
			if (parent != null) return parent.makeGlobalSlot(name);
			else return makeSlot(name);
		}

		protected abstract Slot makeSlot(Name name);

		public virtual Slot GetTempSlot(string prefix, Type type) {
			throw new NotImplementedException();
		}

		private Slot getOrMakeGlobalSlot(Name name) {
			if (parent == null) {
				return getOrMakeSlot(name);
			} else {
				return parent.getOrMakeGlobalSlot(name);
			}
		}

		private Slot getOrMakeSlot(Name name) {
			Slot ret = (Slot)slots[name];
			if (ret != null) return ret;
			ret = makeSlot(name);
			slots[name] = ret;
			return ret;
		}

		public Slot getSlotForGet(Name name) {
			name = FixName(name);

			Slot s = (Slot)slots[name];
			if (s == null) {
				s = getOrMakeGlobalSlot(name);
			}
			return s;
		}

		public Slot getSlotForSet(Name name) {
			name = FixName(name);

			return getOrMakeSlot(name);
		}

		public void markGlobal(Name name) {
			//!!! need testing to check already used as local
			slots[name] = getOrMakeGlobalSlot(name);
		}

		public void emitLocalsDict(CodeGen cg) {
			ICollection c = slots.Values;

			cg.emitNew(typeof(HybridDictionary), Type.EmptyTypes);

			foreach (DictionaryEntry entry in slots) {
				Slot slot = (Slot)entry.Value;
				Name name = (Name)entry.Key;
				cg.ilg.Emit(OpCodes.Dup);
				cg.emitString(name.GetString());
				slot.emitGet(cg);
				cg.emitCall(typeof(HybridDictionary), "Add");
			}
		}

		public virtual void setArgs(Name[] names, MethodBuilder methodBuilder) {
			throw new NotImplementedException();
		}
	}


//	public class SnippetNamespace:Namespace {
//		protected Slot module;
//		protected TypeGen typeGen;
//		public SnippetNamespace(Namespace parent, Slot module, TypeGen typeGen):base(parent) {
//			this.module = module;
//			this.typeGen = typeGen;
//		}
//
//		protected override Slot makeSlot(Name name) {
//			return new SnippetSlot(module, typeGen.getOrMakeConstant(PyString.make(name.GetString())));
//		}
//	}

//	public class ModuleNamespace:Namespace {
//		protected Slot module;
//		protected TypeGen typeGen;
//		public ModuleNamespace(Namespace parent, Slot module, TypeGen typeGen):base(parent) {
//			this.module = module;
//			this.typeGen = typeGen;
//		}
//
//		protected override Slot makeSlot(Name name) {
//			return new ModuleSlot(module, typeGen.getOrMakeConstant(PyString.make(name.GetString())));
//		}
//	}
	public class ObjectStaticFieldNamespace:Namespace {
		protected TypeGen typeGen;
		public ObjectStaticFieldNamespace(Namespace parent, TypeGen typeGen):base(parent) {
			this.typeGen = typeGen;
		}

		protected override Slot makeSlot(Name name) {
			FieldBuilder fb =
				typeGen.myType.DefineField(name.GetString(), typeof(object),
				FieldAttributes.Public | FieldAttributes.Static);
			return new StaticFieldSlot(fb);
		}
	}

	public class StaticFieldNamespace:Namespace {
		protected TypeGen typeGen;
		public StaticFieldNamespace(Namespace parent, TypeGen typeGen):base(parent) {
			this.typeGen = typeGen;
		}

		protected override Slot makeSlot(Name name) {
			FieldBuilder fb =
				typeGen.myType.DefineField(name.GetString(), typeof(object),
							FieldAttributes.Public | FieldAttributes.Static);
			return new StaticFieldSlot(fb);
		}
	}

	public class FieldNamespace:StaticFieldNamespace {
		private Slot instance;
		public FieldNamespace(Namespace parent, TypeGen typeGen, Slot instance):base(parent, typeGen) {
			this.instance = instance;
		}

		private int counter = 0;
		public override Slot GetTempSlot(string prefix, Type type) {
			FieldBuilder fb =
				typeGen.myType.DefineField(prefix + '$' + counter++, type,
				FieldAttributes.Public);
			return new FieldSlot(instance, fb);
		}

		protected override Slot makeSlot(Name name) {
			FieldBuilder fb =
				typeGen.myType.DefineField(name.GetString(), typeof(object),
						FieldAttributes.Public);
			return new FieldSlot(instance, fb);
		}
	}

	public class LocalNamespace:Namespace {
		private CodeGen codeGen;
		public LocalNamespace(Namespace parent, CodeGen codeGen):base(parent) {
			this.codeGen = codeGen;
		}

		protected override Slot makeSlot(Name name) {
			LocalBuilder b = codeGen.ilg.DeclareLocal(typeof(object));
			b.SetLocalSymInfo(name.GetString());
			return new LocalSlot(b);
		}
		
		public override void setArgs(Name[] names, MethodBuilder methodBuilder) {
			//!!! terrible off-by-one issue here
			int index = 1;
			foreach (Name name in names) {
				slots[name] = ArgSlot.make(methodBuilder, index++, name.GetString());
			}
		}
	}

	public class FrameNamespace:Namespace {
		private CodeGen codeGen;
		public int count=0;
		private Slot frame;

		public FrameNamespace(TypeGen typeGen, CodeGen codeGen):base(null) {
			this.codeGen = codeGen;

			ArgSlot argSlot = ArgSlot.make(codeGen.methodBuilder, 1, "frame");
			FieldInfo frameField = typeGen.myType.DefineField("__frame__", typeof(Frame), FieldAttributes.Public|FieldAttributes.Static);
			Slot fieldSlot = new StaticFieldSlot(frameField);

			fieldSlot.emitSet(codeGen, argSlot);
			this.frame = new FrameObjectSlot(codeGen, argSlot, fieldSlot);
		}

		protected override Slot makeSlot(Name name) {
			return new NamedFrameSlot(frame, name);
			//return FrameSlot.makeFrameSlot(frame, count++);
		}

		public override void setArgs(Name[] names, MethodBuilder methodBuilder) {
			foreach (Name name in names) {
				slots[name] = makeSlot(name);
			}
		}
	}

	//!!! for FrameNamespace if needed
	//		public Slot frameSlot = null, baseFrameSlot = null;
	//
	//		private Slot makeFrameSlot(Name name) {
	//			if (slots.Count < PyFrame.FIELD_COUNT) {
	//				return new SmallFrameSlot(baseFrameSlot, name, slots.Count);
	//			} else {
	//				return new FrameSlot(frameSlot, name, slots.Count);
	//			}
	//		}

	//		public void useFrame() {
	//			baseFrameSlot = new ArgSlot(Name.make("frame"),
	//				methodBuilder.DefineParameter(1, ParameterAttributes.None, "frame"));
	//
	//			frameSlot = new LocalSlot(Name.make("slots"),
	//				ilg.DeclareLocal(typeof(PyObject[])));
	//			
	//			//!!! only get field if needed
	//			baseFrameSlot.emitGet(this);
	//			emitFieldGet(typeof(PyFrame), "slots");
	//			frameSlot.emitSet(this);
	//		}
}
