/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;
using System.Text;
using System.IO;
using System.CodeDom;
using System.CodeDom.Compiler;

using System.Resources;
using System.Diagnostics;
using System.Diagnostics.SymbolStore;
using System.Reflection;
using System.Reflection.Emit;

using IronPython.Objects;

using Microsoft.CSharp;

namespace IronPython.AST
{
	/// <summary>
	/// Summary description for ModuleDef.
	/// </summary>
	public class ModuleDef {
		public readonly Name name;
		public readonly Stmt body;
		public ModuleDef(Name name, Stmt body) {
			this.name = name;
			this.body = body;
		}

		public module Generate(string sourceFileName) {
			Options.RAW_OBJECTS = true;

			AssemblyGen ag = new AssemblyGen(Path.GetFullPath(sourceFileName), name.GetString(), name.GetString()+".exe");
			
			TypeGen tg = ag.defineType(name.GetString(), typeof(module));
			tg.AddModuleField(tg.myType);

			ConstructorBuilder cb =
				tg.myType.DefineDefaultConstructor(MethodAttributes.Public);

			CodeGen ncg = tg.defineMethod(
				MethodAttributes.Virtual|MethodAttributes.Public,
				"init", typeof(void), new Type[0]);

			//if (dict == null) {
			if (Options.STATIC_MODULES) ncg.names = new ObjectStaticFieldNamespace(null, tg);
			else throw new NotImplementedException(); //.names = new FieldNamespace(null, tg, new ModuleSlot(tg.myType));
			//			} else {
			//				ncg.names = new ModuleNamespace(null, new ThisSlot(tg.myType), tg);
			//			}

//			string doc = body.GetDocString();
//			if (doc != null) {
//				ncg.emitModuleInstance();
//				ncg.emitConstant(doc);
//				ncg.emitFieldSet(typeof(PyModule).GetField("__doc__"));
//			}

			body.Emit(ncg);
			ncg.ilg.Emit(OpCodes.Ret);

			// block to add main method and set as entry point
			CodeGen cg = tg.defineMethod(MethodAttributes.Public | MethodAttributes.Static,
				"Main", typeof(void), new Type[0]);

			cg.ilg.Emit(OpCodes.Newobj,cb);
			cg.emitCall(ncg.methodBuilder);

			cg.ilg.Emit(OpCodes.Ret);

			//!!!tg.createAttrMethods(ncg.names.slots);

			// questions as to how simple this can be...
			Type ret = tg.finishType();

			//if (outFileName != null) {
			ag.myAssembly.SetEntryPoint(cg.methodBuilder);
			Assembly assm = ag.dumpAndLoad();
			ret = assm.GetType(name.GetString());
			//}

			module mod = (module)ret.GetConstructor(new Type[0]).Invoke(new object[0]);
			//!!!pmod.__file__ = PyString.make(sourceFileName);
			//			if (dict != null) {
			//				pmod.setDict(dict);
			//			}

			return mod;
		}


//		public PyModule generate(string sourceFileName) {
//			AssemblyGen ag = new AssemblyGen(sourceFileName, name.GetString(), name.GetString()+".exe");
//			
//			TypeGen tg = ag.defineType(name.GetString(), typeof(PyModule));
//
//			ConstructorBuilder cb =
//				tg.myType.DefineDefaultConstructor(MethodAttributes.Public);
//
//			CodeGen ncg = tg.defineMethod(
//				MethodAttributes.Virtual|MethodAttributes.Public,
//				"init", typeof(void), new Type[0]);
//
//			//if (dict == null) {
//				if (Options.STATIC_MODULES) ncg.names = new StaticFieldNamespace(null, tg);
//				else ncg.names = new FieldNamespace(null, tg, new ModuleSlot(tg.myType));
////			} else {
////				ncg.names = new ModuleNamespace(null, new ThisSlot(tg.myType), tg);
////			}
//
//			string doc = body.GetDocString();
//			if (doc != null) {
//				ncg.emitModuleInstance();
//				ncg.emitConstant(PyString.make(doc));
//				ncg.emitFieldSet(typeof(PyModule).GetField("__doc__"));
//			}
//
//			body.generate(ncg);
//			ncg.ilg.Emit(OpCodes.Ret);
//
//			// block to add main method and set as entry point
//			CodeGen cg = tg.defineMethod(MethodAttributes.Public | MethodAttributes.Static,
//				"Main", typeof(void), new Type[0]);
//
//			cg.ilg.Emit(OpCodes.Newobj,cb);
//			cg.emitCall(ncg.methodBuilder);
//
//			cg.ilg.Emit(OpCodes.Ret);
//
//			tg.createAttrMethods(ncg.names.slots);
//
//			// questions as to how simple this can be...
//			Type ret = tg.finishType();
//
//			//if (outFileName != null) {
//				ag.myAssembly.SetEntryPoint(cg.methodBuilder);
//				Assembly assm = ag.dumpAndLoad();
//				ret = assm.GetType(name.GetString());
//			//}
//
//			PyModule pmod = (PyModule)ret.GetConstructor(new Type[0]).Invoke(new object[0]);
//			pmod.__file__ = PyString.make(sourceFileName);
////			if (dict != null) {
////				pmod.setDict(dict);
////			}
//
//			return pmod;
//		}
	}
}
