/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Reflection;
using System.Reflection.Emit;
using System.Collections;

using IronPython.Objects;

namespace IronPython.AST
{
	/// <summary>
	/// Summary description for Expr.
	/// </summary>
	public abstract class Expr:Node {
		public virtual object Evaluate(NameEnv env) {
			throw new NotImplementedException("Evaluate: " + this);
		}

		public virtual void Assign(object val, NameEnv env) {
			throw new NotImplementedException("Assign: " + this);
		}

		public virtual void Emit(CodeGen cg) {
			throw new NotImplementedException("generate: " + this);
		}

		public virtual void EmitSet(CodeGen cg) {
			throw new NotImplementedException("EmitSet: " + this);
		}

		public virtual void EmitDel(CodeGen cg) {
			throw new NotImplementedException("EmitDel: " + this);
		}

		public static object[] Evaluate(Expr[] items, NameEnv env) {
			object[] ret = new object[items.Length];
			for (int i=0; i < items.Length; i++) {
				ret[i] = items[i].Evaluate(env);
			}
			return ret;
		}

		public void Walk(IWalker w) {
			w.Walk(this);  //!!! actually TBD
		}
	}

	public class CallExpr:Expr {
		public static readonly Name VAR_NAME = Name.make("*");
		public static readonly Name KW_NAME = Name.make("**");

		public readonly Expr target;
		public readonly Arg[] args;
		private bool hasArgsTuple, hasKeywordDict;
		private int keywordCount=0, extraArgs=0;
		public CallExpr(Expr target, params Arg[] args) {
			this.target = target;
			this.args = args;

			foreach (Arg arg in args) {
				if (arg.name == null) {
					if (hasArgsTuple || hasKeywordDict || keywordCount > 0) {
						throw Ops.SyntaxError("plain args not allowed after keywords");
					}
				} else if (arg.name == VAR_NAME) {
					if (hasArgsTuple || hasKeywordDict) {
						throw Ops.SyntaxError("only one * allowed");
					}
					hasArgsTuple = true; extraArgs++;
				} else if (arg.name == KW_NAME) {
					if (hasKeywordDict) {
						throw Ops.SyntaxError("only on ** allowed");
					}
					hasKeywordDict = true; extraArgs++;
				} else {
					if (hasArgsTuple || hasKeywordDict) {
						throw Ops.SyntaxError("keywords must come before * args");
					}
					keywordCount++;
				}
			}
		}

		public override object Evaluate(NameEnv env) {
			object callee = target.Evaluate(env);

			object[] cargs = new object[args.Length];
			int index = 0;
			foreach (Arg arg in args) {
				if (arg.name != null) throw new NotImplementedException("keywords");
				cargs[index++] = arg.expr.Evaluate(env);
			}
			switch (cargs.Length) {
				case 0: return Ops.Call(callee);
				default: return Ops.Call(callee, cargs);
			}
		}

		public override void Emit(CodeGen cg) {
			//!!! first optimize option comes here
//			if (target is FieldExpr && !hasSpecialArgs()) {
//				generateInvoke((FieldExpr)target, cg);
//				return;
//			}

			target.Emit(cg);
			Expr[] exprs = new Expr[args.Length-extraArgs];
			Expr argsTuple = null, keywordDict = null;
			string[] keywordNames = new string[keywordCount];
			int index = 0, keywordIndex=0;
			foreach (Arg arg in args) {
				if (arg.name == VAR_NAME) {
					argsTuple = arg.expr; continue;
				} else if (arg.name == KW_NAME) {
					keywordDict = arg.expr; continue;
				} else if (arg.name != null) {
					keywordNames[keywordIndex++] = arg.name.GetString();
				}
				exprs[index++] = arg.expr;
			}

			//!!! in the future we can imagine more fastpaths for keywords
			if (hasKeywordDict || (hasArgsTuple && keywordCount > 0)) {
				cg.emitObjectArray(exprs);
				cg.emitStringArray(keywordNames);
				cg.emitExprOrNone(argsTuple);
				cg.emitExprOrNone(keywordDict);
				cg.emitCall(typeof(Ops), "CallWithArgsTupleAndKeywordDict",
					new Type[] { typeof(object), typeof(object[]), typeof(string[]),
								   typeof(object), typeof(object)});
			} else if (hasArgsTuple) {
				cg.emitObjectArray(exprs);
				cg.emitExprOrNone(argsTuple);
				cg.emitCall(typeof(Ops), "CallWithArgsTuple",
					new Type[] { typeof(object), typeof(object[]), typeof(object)});
			} else if (keywordCount > 0) {
				cg.emitObjectArray(exprs);
				cg.emitStringArray(keywordNames);
				cg.emitCall(typeof(Ops), "Call",
					new Type[] { typeof(object), typeof(object[]), typeof(string[])});
			} else if (args.Length <= Ops.MAX_CALL_ARGS) {
//				if (args.Length == 1) {
//					foreach (Expr e in exprs) {
//						e.Emit(cg);
//					}
//					cg.emitCall(TailCallOpsBuilder.GetTailCallOps(cg.typeGen.myAssembly), "Call", Constants.makeArray(typeof(object), 2));
//					return;
//				}


				Type[] argTypes = new Type[args.Length+1];
				int i = 0;
				argTypes[i++] = typeof(object);
				foreach (Expr e in exprs) {
					e.Emit(cg);
					argTypes[i++] = typeof(object);
				}
				cg.emitCall(typeof(Ops), "Call", argTypes);
			} else {
				cg.emitObjectArray(exprs);
				cg.emitCall(typeof(Ops), "Call",
					new Type[] { typeof(object), typeof(object[]) });
			}
		}

		private bool hasSpecialArgs() {
			return keywordCount > 0 || hasArgsTuple || hasKeywordDict;
		}
//
//		private void generateInvoke(FieldExpr fieldExpr, CodeGen cg) {
//			fieldExpr.target.generate(cg);
//
//			if (fieldExpr.name == Name.make("next") && args.Length == 0) {
//				cg.emitCall(typeof(PyObject), "next", new Type[0]);
//				return;
//			}
//
//			cg.emitName(fieldExpr.name);
//
//			Expr[] exprs = new Expr[args.Length];
//			int index = 0;
//			foreach (Arg arg in args) {
//				if (arg.name != null) throw new NotImplementedException("keywords");
//				exprs[index++] = arg.expr;
//			}
//			
//			if (exprs.Length <= 3) {
//				Type[] argTypes = new Type[args.Length+1];
//				int i = 0;
//				argTypes[i++] = typeof(PyString);
//				foreach (Expr e in exprs) {
//					e.generate(cg);
//					argTypes[i++] = typeof(PyObject);
//				}
//				cg.emitCall(typeof(PyObject), "invoke", argTypes);
//			} else {
//				cg.emitPyObjectArray(exprs);
//				cg.emitCall(typeof(PyObject), "invoke",
//					new Type[] { typeof(PyString), typeof(PyObject[]) });
//			}
//		}
	}

	public class Arg:Node {
		public readonly Name name;
		public readonly Expr expr;
		public Arg(Expr expr): this(null, expr) {}

		public Arg(Name name, Expr expr) {
			this.name = name;
			this.expr = expr;
		}
	}

	public class FieldExpr:Expr {
		public readonly Expr target;
		public readonly Name name;
		public FieldExpr(Expr target, Name name) {
			this.target = target;
			this.name = name;
		}

		public override void Emit(CodeGen cg) {
			target.Emit(cg);
			cg.emitName(name);
			cg.emitCall(typeof(Ops), "GetAttr", new Type[] { typeof(object), typeof(string) });
		}

		public override void EmitSet(CodeGen cg) {
			target.Emit(cg);
			cg.emitName(name); 
			cg.emitCall(typeof(Ops), "SetAttrStackHelper");
		}

		public override void EmitDel(CodeGen cg) {
			target.Emit(cg);
			cg.emitName(name);
			cg.emitCall(typeof(Ops), "DelAttr");
		}
	}

	public class IndexExpr:Expr {
		public readonly Expr target;
		public readonly Expr index;
		public IndexExpr(Expr target, Expr index) {
			this.target = target;
			this.index = index;
		}

		public override object Evaluate(NameEnv env) {
			object t = target.Evaluate(env);
			object i = index.Evaluate(env);
			return Ops.GetIndex(t, i);
		}

		public override void Assign(object val, NameEnv env) {
			object t = target.Evaluate(env);
			object i = index.Evaluate(env);
			Ops.SetIndex(t, i, val);
		}

		public override void Emit(CodeGen cg) {
			target.Emit(cg);
//			SliceExpr sliceIndex = index as SliceExpr;
//			if (sliceIndex != null && sliceIndex.step_ == null) {
//				cg.emitExprOrNone(sliceIndex.start_);
//				cg.emitExprOrNone(sliceIndex.stop_);
//				cg.emitCall(typeof(Ops), "GetSlice", new Type[] {typeof(object), typeof(object), typeof(object)});
//				return;
//			}
			index.Emit(cg);
			cg.emitCall(typeof(Ops), "GetIndex");
		}


		public override void EmitSet(CodeGen cg) {
			target.Emit(cg);
			index.Emit(cg);
			cg.emitCall(typeof(Ops), "SetIndexStackHelper");
		}

		public override void EmitDel(CodeGen cg) {
			target.Emit(cg);
			index.Emit(cg);
			cg.emitCall(typeof(Ops), "DelIndex");
		}
	}

	public abstract class SequenceExpr:Expr {
		public readonly Expr[] items;
		public SequenceExpr(params Expr[] items) { this.items = items; }

		public override void Assign(object val, NameEnv env) {
			IEnumerator i = Ops.GetEnumerator(val);
			foreach (Expr expr in items) {
				i.MoveNext();
				expr.Assign(i.Current, env);
			}
			//!!! verify what to do for different sized sequences
		}

		public override void EmitSet(CodeGen cg) {
			Slot tmp = cg.getLocalTmp(typeof(IEnumerator));
			cg.emitCall(typeof(Ops), "GetEnumerator");
			tmp.emitSet(cg);

			foreach (Expr expr in items) {
				tmp.emitGet(cg);
				cg.emitCall(typeof(IEnumerator), "MoveNext");
				cg.ilg.Emit(OpCodes.Pop);
				tmp.emitGet(cg);
				cg.emitCall(typeof(IEnumerator).GetProperty("Current").GetGetMethod());
				expr.EmitSet(cg);
			}
			cg.freeLocalTmp(tmp);
		}

		public override void EmitDel(CodeGen cg) {
			foreach (Expr expr in items) {
				expr.EmitDel(cg);
			}
		}
	}


	public class TupleExpr:SequenceExpr {
		public TupleExpr(params Expr[] items):base(items) { }

		public override object Evaluate(NameEnv env) {
			return Ops.MakeTuple(Evaluate(items, env));
		}

		public override void Emit(CodeGen cg) {
//			if (items.Length == 2) {
//				items[0].Emit(cg);
//				items[1].Emit(cg);
//				cg.emitCall(typeof(Ops), "MakeTuple", Constants.makeArray(typeof(object), 2));
//				return;
//			}
			cg.emitObjectArray(items);
			cg.emitCall(typeof(Ops), "MakeTuple", new Type[] { typeof(object[]) });
		}
	}

	public class ListExpr:SequenceExpr {
		public ListExpr(params Expr[] items):base(items) { }

		public override object Evaluate(NameEnv env) {
			return Ops.MakeList(Evaluate(items, env));
		}

		public override void Emit(CodeGen cg) {
			cg.emitObjectArray(items);
			cg.emitCall(typeof(Ops), "MakeList", new Type[] { typeof(object[]) });
		}
	}

	public class DictExpr:Expr {
		public readonly SliceExpr[] items;
		public DictExpr(params SliceExpr[] items) { this.items = items; }

		public override object Evaluate(NameEnv env) {
			Dict dict = Ops.MakeDict(items.Length);
			foreach (SliceExpr s in items) {
				dict[s.start_.Evaluate(env)] = s.stop_.Evaluate(env);
			}
			return dict;
		}

		public override void Emit(CodeGen cg) {
			cg.emitInt(items.Length);
			cg.emitCall(typeof(Ops), "MakeDict");
			foreach (SliceExpr s in items) {
				cg.ilg.Emit(OpCodes.Dup);
				s.start_.Emit(cg);
				s.stop_.Emit(cg);
				cg.emitCall(typeof(Dict).GetProperty("Item").GetSetMethod());
			}
		}
	}

	public class SliceExpr:Expr {
		//!!! these names will be trouble
		public readonly Expr start_, stop_, step_;
		public SliceExpr(Expr start, Expr stop, Expr step) {
			this.start_ = start;
			this.stop_ = stop;
			this.step_ = step;
		}

		public override object Evaluate(NameEnv env) {
			object e1 = start_.Evaluate(env);
			object e2 = stop_.Evaluate(env);
			object e3 = step_.Evaluate(env);
			return Ops.MakeSlice(e1, e2, e3);
		}

		public override void Emit(CodeGen cg) {
			cg.emitExprOrNone(start_);
			cg.emitExprOrNone(stop_);
			cg.emitExprOrNone(step_);
			cg.emitCall(typeof(Ops), "MakeSlice");
		}
	}


	public class BackquoteExpr:Expr {
		public readonly Expr expr;
		public BackquoteExpr(Expr expr) { this.expr = expr; }

		public override object Evaluate(NameEnv env) {
			return Ops.Repr( expr.Evaluate(env) );
		}

		public override void Emit(CodeGen cg) {
			expr.Emit(cg);
			cg.emitCall(typeof(Ops), "Repr");
		}
	}
	public class ParenExpr:Expr {
		public readonly Expr expr;
		public ParenExpr(Expr expr) { this.expr = expr; }

		public override object Evaluate(NameEnv env) {
			return expr.Evaluate(env);
		}

		public override void Emit(CodeGen cg) {
			expr.Emit(cg);
		}
	}


	public class ConstantExpr:Expr {
		public readonly object value;
		public ConstantExpr(object value) {
			this.value = value;
		}

		public override object Evaluate(NameEnv env) {
			if (value == null) throw new NotImplementedException();
			return value;
		}

		public override void Emit(CodeGen cg) {
			cg.emitConstant(value);
		}
	}

	public class NameExpr:Expr {
		public readonly Name name;
		public NameExpr(Name name) { this.name = name; }
		
		public override object Evaluate(NameEnv env) {
			return env.Get(name.GetString());
		}

		public override void Assign(object val, NameEnv env) {
			env.Set(name.GetString(), val);
		}

		public override void Emit(CodeGen cg) {
			cg.emitGet(name);
		}

		public override void EmitSet(CodeGen cg) {
			cg.emitSet(name);
		}

//		public override void emitDel(CodeGen cg) {
//			cg.emitName(name);
//			cg.emitNew(typeof(PyUninitialized), new Type[] { typeof(PyString) } );
//			cg.emitSet(name);
//		}

	}

	
	public class AndExpr:Expr {
		public readonly Expr left, right;
		public AndExpr(Expr left, Expr right) {
			this.left = left; this.right = right;
			this.start = left.start; this.end = right.end;
		}

		public override object Evaluate(NameEnv env) {
			object ret = left.Evaluate(env);
			if (Ops.IsTrue(ret)) return right.Evaluate(env);
			else return ret;
		}

		public override void Emit(CodeGen cg) {
			left.Emit(cg);
			cg.ilg.Emit(OpCodes.Dup);
			cg.emitCall(typeof(Ops), "IsTrue");
			//cg.emitNonzero(left);
			Label l = cg.ilg.DefineLabel();
			cg.ilg.Emit(OpCodes.Brfalse, l);
			cg.ilg.Emit(OpCodes.Pop);
			right.Emit(cg);
			cg.ilg.MarkLabel(l);
		}
	}

	public class OrExpr:Expr {
		public readonly Expr left, right;
		public OrExpr(Expr left, Expr right) {
			this.left = left; this.right = right;
			this.start = left.start; this.end = right.end;
		}

		public override object Evaluate(NameEnv env) {
			object ret = left.Evaluate(env);
			if (!Ops.IsTrue(ret)) return right.Evaluate(env);
			else return ret;
		}

		
		public override void Emit(CodeGen cg) {
			left.Emit(cg);
			cg.ilg.Emit(OpCodes.Dup);
			cg.emitCall(typeof(Ops), "IsTrue");
			//cg.emitNonzero(left);
			Label l = cg.ilg.DefineLabel();
			cg.ilg.Emit(OpCodes.Brtrue, l);
			cg.ilg.Emit(OpCodes.Pop);
			right.Emit(cg);
			cg.ilg.MarkLabel(l);
		}
	}

	public class UnaryExpr:Expr {
		public readonly Expr expr;
		public readonly UnaryOperator op;
		public UnaryExpr(UnaryOperator op, Expr expr) {
			this.op = op; this.expr = expr;
			this.end = expr.end;
		}

		public override object Evaluate(NameEnv env) {
			return op.Evaluate( expr.Evaluate(env) );
		}

		public override void Emit(CodeGen cg) {
			expr.Emit(cg);
			cg.emitCall(op.target.Method);
		}
	}

	public class BinaryExpr:Expr {
		public readonly Expr left, right;
		public readonly BinaryOperator op;
		public BinaryExpr(BinaryOperator op, Expr left, Expr right) {
			this.op = op; this.left = left; this.right = right;
			this.start = left.start; this.end = right.end;
		}

		public override object Evaluate(NameEnv env) {
			object l = left.Evaluate(env);
			object r = right.Evaluate(env);

			return op.Evaluate(l, r);

//			if (op == Operator.SubOp) {
//				return Ops.Subtract(l, r);
//			} else if (op == Operator.AddOp) {
//				return Ops.Add(l, r);
//			} else if (op == Operator.MulOp) {
//				return Ops.Multiply(l, r);
//			}
		}

		public override void Emit(CodeGen cg) {
			left.Emit(cg);
			if (isComparision() && isComparision(right)) {
				FinishCompare(cg);
			} else {
				right.Emit(cg);
				cg.emitCall(op.target.Method);
			}
		}

		protected bool isComparision() {
			return op.isComparision();
		}

		protected bool isComparision(Expr e) {
			return e is BinaryExpr && ((BinaryExpr)e).isComparision();
		}

		//!!! code review
		protected void FinishCompare(CodeGen cg) {
			BinaryExpr bright = (BinaryExpr)right;

			Slot valTmp = cg.getLocalTmp(typeof(object));
			Slot retTmp = cg.getLocalTmp(typeof(object));
			bright.left.Emit(cg);
			cg.ilg.Emit(OpCodes.Dup);
			valTmp.emitSet(cg);

			cg.emitCall(op.target.Method);
			cg.ilg.Emit(OpCodes.Dup);
			retTmp.emitSet(cg);
			cg.emitNonzero();

			Label end = cg.ilg.DefineLabel();
			cg.ilg.Emit(OpCodes.Brfalse, end);

			valTmp.emitGet(cg);

			if (isComparision(bright.right)) {
				bright.FinishCompare(cg);
			} else {
				bright.right.Emit(cg);
				cg.emitCall(bright.op.target.Method);
			}

			retTmp.emitSet(cg);
			cg.ilg.MarkLabel(end);
			retTmp.emitGet(cg);
		}
	}

	public class LambdaExpr:Expr {
		public readonly FuncDef func;
		public LambdaExpr(FuncDef func) {
			this.func = func;
		}

		public override object Evaluate(NameEnv env) {
			return func.MakeFunction(env);
		}

		public override void Emit(CodeGen cg) {
			func.Emit(cg);
			cg.emitGet(func.name);
		}
	}

	public class ListCompFor:Node {
		public readonly Expr lhs, list;
		public ListCompFor(Expr lhs, Expr list) {
			this.lhs = lhs; this.list = list;
		}
	}

	public class ListCompIf:Node {
		public readonly Expr test;
		public ListCompIf(Expr test) { this.test = test; }
	}


	public class ListComp:Expr {
		public readonly Expr item;
		public readonly ListCompFor[] fors;
		public readonly ListCompIf[] ifs;

		public ListComp(Expr item, ListCompFor[] fors, ListCompIf[] ifs) {
			this.item = item; this.fors = fors; this.ifs = ifs;
		}

		//!!! need to look this over carefully...
		public override void Emit(CodeGen cg) {
			Slot list = cg.getLocalTmp(typeof(List));
			Slot item = cg.getLocalTmp(typeof(object));
			Slot[] iters = new Slot[fors.Length];
			//Label[] eolTargets = new Label[fors.Length];
			Label[] continueTargets = new Label[fors.Length+1];
			for (int i=0; i < fors.Length+1; i++) {
				continueTargets[i] = cg.ilg.DefineLabel();
			}

			cg.emitCall(typeof(Ops), "MakeList", Type.EmptyTypes);
			list.emitSet(cg);

			for (int i=0; i < fors.Length; i++) {
				fors[i].list.Emit(cg);
				cg.emitCall(typeof(Ops), "GetEnumerator");
				iters[i] = cg.getLocalTmp(typeof(IEnumerator));
				iters[i].emitSet(cg);

				cg.ilg.MarkLabel(continueTargets[i+1]);

				iters[i].emitGet(cg);
				cg.emitCall(typeof(IEnumerator), "MoveNext", Type.EmptyTypes);

				cg.ilg.Emit(OpCodes.Brfalse, continueTargets[i]);

				iters[i].emitGet(cg);
				cg.emitCall(typeof(IEnumerator).GetProperty("Current").GetGetMethod());

				fors[i].lhs.EmitSet(cg);
			}

			for (int i=0; i < ifs.Length; i++) {
				cg.emitNonzero(ifs[i].test);
				cg.ilg.Emit(OpCodes.Brfalse, continueTargets[fors.Length]);
			}

			list.emitGet(cg);
			this.item.Emit(cg);
			cg.emitCall(typeof(List), "append");

			cg.ilg.Emit(OpCodes.Br, continueTargets[fors.Length]);
			cg.ilg.MarkLabel(continueTargets[0]);

			list.emitGet(cg);

			cg.freeLocalTmp(list);
			cg.freeLocalTmp(item);
			for (int i=0; i < iters.Length; i++) cg.freeLocalTmp(iters[i]);
		}
	}
}
