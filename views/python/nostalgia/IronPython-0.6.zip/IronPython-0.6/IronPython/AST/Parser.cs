/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;
using System.IO;

using IronPython.Objects;


namespace IronPython.AST
{
	/// <summary>
	/// Summary description for Parser.
	/// </summary>
	public class Parser {
		public static Parser fromString(string text) {
			return new Parser("<string>", new Tokenizer(text.ToCharArray()));
		}

		public static Parser fromFile(string filename) {
			StreamReader sr = new StreamReader(File.OpenRead(filename), System.Text.Encoding.ASCII);
			string data  = sr.ReadToEnd();
			sr.Close();
			return new Parser(filename, new Tokenizer(data.ToCharArray()));
		}


		private Tokenizer tokenizer;
		private string sourcefile = "<unknown>";

		private Token peekedToken;
		private int savedStart, savedEnd;
		private int yieldCount = -1;
		
		public Parser(string sourcefile, Tokenizer tokenizer) {
			this.sourcefile = sourcefile;
			this.tokenizer = tokenizer;
		}

		protected Token peekToken() {
			if (peekedToken != null) return peekedToken;
			savedStart = tokenizer.start;
			savedEnd = tokenizer.end;
			Token p = nextToken();
			peekedToken = p;
			return p;
		}

		protected bool peekToken(Token check) {
			return peekToken() == check;
		}

		protected Token nextToken() {
			if (peekedToken != null) {
				Token ret = peekedToken;
				peekedToken = null;
				return ret;
			}
			return tokenizer.next();
		}

		protected void eat(int kind) {
			Token t = nextToken();
			if (t.kind != kind) {
				//TODO better messages
				throw makeSyntaxError(t);
			}
		}

		protected bool maybeEat(int kind) {
			Token t = peekToken();
			if (t.kind == kind) {
				nextToken();
				return true;
			} else {
				return false;
			}
		}

		private int getStart() {
			if (peekedToken == null) return tokenizer.start;
			else return savedStart;
		}

		private int getEnd() {
			if (peekedToken == null) return tokenizer.end;
			else return savedEnd;
		}

		private void setStartAndEnd(Node node) {
			if (peekedToken != null) {
				node.start = savedStart;
				node.end = savedEnd;
			} else {
				node.start = tokenizer.start;
				node.end = tokenizer.end;
			}
		}

		private Exception makeSyntaxError(Token t) {
			return Ops.SyntaxError("unexpected token {0} at {1}:{2}",  t.getImage(), sourcefile, tokenizer.line);
		}

		private Name maybeReadName() {
			Token t = nextToken();
			NameToken n = t as NameToken;
			if (n == null) return null;
			return n.value;
		}


		private Name readName() {
			Token t = nextToken();
			NameToken n = t as NameToken;
			if (n == null) throw makeSyntaxError(t);
			return n.value;
		}

		//single_input: NEWLINE | simple_stmt | compound_stmt NEWLINE
		//eval_input: testlist NEWLINE* ENDMARKER

		//file_input: (NEWLINE | stmt)* ENDMARKER
		public Stmt parseFileInput() {
			ArrayList l = new ArrayList();
			while (true) {
				if (maybeEat(TokenKind.EOF)) break;
				if (maybeEat(TokenKind.NEWLINE)) continue;
				int line = tokenizer.line;
				Stmt s = parseStmt();
				s.line = line;
				l.Add(s);
			}
			Stmt[] stmts = new Stmt[l.Count];
			l.CopyTo(stmts);
			return new SuiteStmt(stmts);
		}

		//stmt: simple_stmt | compound_stmt
		//compound_stmt: if_stmt | while_stmt | for_stmt | try_stmt | funcdef | classdef
		public Stmt parseStmt() {
			Token t = peekToken();
			switch(t.kind) {
				case TokenKind.kIF:
					return parseIfStmt();
				case TokenKind.kWHILE:
					return parseWhileStmt();
				case TokenKind.kFOR:
					return parseForStmt();
				case TokenKind.kTRY:
					return parseTryStmt();

				case TokenKind.kDEF:
					return parseFuncDef();
				case TokenKind.kCLASS:
					return parseClassDef();

				default:
					return parseSimpleStmt();
			}
		}

		//simple_stmt: small_stmt (';' small_stmt)* [';'] NEWLINE
		public Stmt parseSimpleStmt() {
			Stmt s = parseSmallStmt();
			if (maybeEat(TokenKind.SEMICOLON)) {
				int start = s.start;
				ArrayList l = new ArrayList();
				l.Add(s);
				while (true) {
					if (maybeEat(TokenKind.NEWLINE)) break;
					l.Add(parseSmallStmt());
					if (!maybeEat(TokenKind.SEMICOLON)) {
						eat(TokenKind.NEWLINE);
						break;
					}
				}
				Stmt[] stmts = new Stmt[l.Count];
				l.CopyTo(stmts);
				SuiteStmt ret = new SuiteStmt(stmts);
				ret.setLoc(start, getEnd());
				return ret;
			} else {
				eat(TokenKind.NEWLINE);
				return s;
			}
		}

		/*
		small_stmt: expr_stmt | print_stmt  | del_stmt | pass_stmt | flow_stmt | import_stmt | global_stmt | exec_stmt | assert_stmt

		del_stmt: 'del' exprlist
		pass_stmt: 'pass'
		flow_stmt: break_stmt | continue_stmt | return_stmt | raise_stmt | yield_stmt
		break_stmt: 'break'
		continue_stmt: 'continue'
		return_stmt: 'return' [testlist]
		yield_stmt: 'yield' testlist
		*/
		public Stmt parseSmallStmt() {
			Token t = peekToken();
			int start = getStart();
			Stmt ret;
			switch(t.kind) {
				case TokenKind.kPRINT:
					return parsePrintStmt();
				case TokenKind.kPASS:
					nextToken();
					ret = new PassStmt(); break;
				case TokenKind.kBREAK:
					nextToken();
					ret = new BreakStmt(); break;
				case TokenKind.kCONTINUE:
					nextToken();
					ret = new ContinueStmt(); break;
				case TokenKind.kRETURN:
					nextToken();
					Expr expr = null;
					if (!neverTestToken(peekToken())) {
						expr = parseTestListAsExpr();
					}
					ret = new ReturnStmt(expr); break;
				case TokenKind.kFROM:
					return parseFromImportStmt();
				case TokenKind.kIMPORT:
					return parseImportStmt();
				case TokenKind.kGLOBAL:
					return parseGlobalStmt();
				case TokenKind.kRAISE:
					return parseRaiseStmt();
				case TokenKind.kASSERT:
					return parseAssertStmt();
				case TokenKind.kEXEC:
					return parseExecStmt();
				case TokenKind.kDEL:
					nextToken();
					ArrayList l = parseExprList();
					ret = new DelStmt(exprsFromList(l));
					break;
				case TokenKind.kYIELD:
					nextToken();
					ret = new YieldStmt(parseTestListAsExpr(), yieldCount++);
					break;

				default:
					return parseExprStmt();
			}
			ret.setLoc(start, getEnd());
			return ret;
		}

		//expr_stmt: testlist (augassign testlist | ('=' testlist)*)
		//augassign: '+=' | '-=' | '*=' | '/=' | '%=' | '&=' | '|=' | '^=' | '<<=' | '>>=' | '**=' | '//='
		public Stmt parseExprStmt() {
			int start = getStart();
			Expr lhs = parseTestListAsExpr();

			if (maybeEat(TokenKind.ASSIGN)) {
				ArrayList l = new ArrayList();
				l.Add(lhs);
				do {
					l.Add(parseTestListAsExpr());
				} while (maybeEat(TokenKind.ASSIGN));

				int last = l.Count-1;
				Expr rhs = (Expr)l[last];
				l.RemoveAt(last);
				Expr[] lhss = exprsFromList(l);

				Stmt ret = new AssignStmt(lhss, rhs);
				ret.setLoc(start, getEnd());
				return ret;
			} else {
				BinaryOperator op = getAssignOp(peekToken());
				if (op == null) {
					Stmt ret = new ExprStmt(lhs);
					ret.setLoc(start, getEnd());
					return ret;
				} else {
					nextToken();
					Expr rhs = parseTestListAsExpr();
					Stmt ret = new AugAssignStmt(op, lhs, rhs);
					ret.setLoc(start, getEnd());
					return ret;
				}
			}
		}

		//		private bool isExprStmtSep(Token t) {
		//			return isEndOfStmt(t) || getAssignOp(t) != null || t == TokenKind.AssignToken;
		//		}
		//
		//		private bool isEndOfStmt(Token t) {
		//			return t.kind == TokenKind.NEWLINE || t.kind == TokenKind.SEMICOLON;
		//		}

		private BinaryOperator getAssignOp(Token t) {
			switch (t.kind) {
				case TokenKind.ADD_EQ: return Operator.AddOp;
				case TokenKind.SUB_EQ: return Operator.SubOp;
				case TokenKind.MUL_EQ: return Operator.MulOp;
				case TokenKind.DIV_EQ: return Operator.DivOp;
				case TokenKind.MOD_EQ: return Operator.ModOp;
				case TokenKind.AND_EQ: return Operator.AndOp;
				case TokenKind.OR_EQ: return Operator.OrOp;
				case TokenKind.XOR_EQ: return Operator.XorOp;
				case TokenKind.LSHIFT_EQ: return Operator.LshiftOp;
				case TokenKind.RSHIFT_EQ: return Operator.RshiftOp;
				case TokenKind.POW_EQ: return Operator.PowOp;
				case TokenKind.FLOORDIV_EQ: return Operator.FloordivOp;
				default: return null;
			}
		}

		//import_stmt: 'import' dotted_as_name (',' dotted_as_name)*
		public ImportStmt parseImportStmt() {
			eat(TokenKind.kIMPORT);
			int start = getStart();

			ArrayList l = new ArrayList();
			ArrayList las = new ArrayList();
			l.Add(parseDottedName());
			las.Add(maybeParseAsName());
			while (maybeEat(TokenKind.COMMA)) {
				l.Add(parseDottedName());
				las.Add(maybeParseAsName());
			}
			DottedName[] names = new DottedName[l.Count];
			l.CopyTo(names);
			Name[] asNames = new Name[las.Count];
			las.CopyTo(asNames);

			ImportStmt ret = new ImportStmt(names, asNames);
			ret.setLoc(start, getEnd());
			return ret;
		}

		//| 'from' dotted_name 'import' ('*' | import_as_name (',' import_as_name)*)
		public FromImportStmt parseFromImportStmt() {
			eat(TokenKind.kFROM);
			int start = getStart();
			DottedName dname = parseDottedName();

			eat(TokenKind.kIMPORT);

			Name[] names;
			Name[] asNames;
			if (maybeEat(TokenKind.MUL)) {
				names = FromImportStmt.STAR;
				asNames = null;
			} else {
				ArrayList l = new ArrayList();
				ArrayList las = new ArrayList();
				l.Add(readName());
				las.Add(maybeParseAsName());
				while (maybeEat(TokenKind.COMMA)) {
					l.Add(readName());
					las.Add(maybeParseAsName());
				}
				names = new Name[l.Count];
				l.CopyTo(names);
				asNames = new Name[las.Count];
				las.CopyTo(asNames);
			}
			FromImportStmt ret = new FromImportStmt(dname, names, asNames);
			ret.setLoc(start, getEnd());
			return ret;
		}

		//import_as_name: NAME [NAME NAME]
		//dotted_as_name: dotted_name [NAME NAME]
		private static readonly Name AS_NAME = Name.make("as");
		private Name maybeParseAsName() {
			NameToken t = peekToken() as NameToken;
			if (t == null) return null;
			if (t.value == AS_NAME) {
				nextToken();
				return readName();
			}
			return null;
		}

		//dotted_name: NAME ('.' NAME)*
		private DottedName parseDottedName() {
			int start = getStart();
			ArrayList l = new ArrayList();
			l.Add(readName());
			while (maybeEat(TokenKind.DOT)) {
				l.Add(readName());
			}
			Name[] names = new Name[l.Count];
			l.CopyTo(names);
			DottedName ret = new DottedName(names);
			ret.setLoc(start, getEnd());
			return ret;
		}

		//exec_stmt: 'exec' expr ['in' test [',' test]]
		public ExecStmt parseExecStmt() {
			eat(TokenKind.kEXEC);
			int start = getStart();
			Expr code, locals=null, globals=null;
			code = parseExpr();
			if (maybeEat(TokenKind.kIN)) {
				locals = parseTest();
				if (maybeEat(TokenKind.COMMA)) {
					globals = parseTest();
				}
			}
			ExecStmt ret = new ExecStmt(code, locals, globals);
			ret.setLoc(start, getEnd());
			return ret;
		}

		//global_stmt: 'global' NAME (',' NAME)*
		public GlobalStmt parseGlobalStmt() {
			eat(TokenKind.kGLOBAL);
			int start = getStart();
			ArrayList l = new ArrayList();
			l.Add(readName());
			while (maybeEat(TokenKind.COMMA)) {
				l.Add(readName());
			}
			Name[] names = new Name[l.Count];
			l.CopyTo(names);
			GlobalStmt ret = new GlobalStmt(names);
			ret.setLoc(start, getEnd());
			return ret;
		}

		//raise_stmt: 'raise' [test [',' test [',' test]]]
		public RaiseStmt parseRaiseStmt() {
			eat(TokenKind.kRAISE);
			int start = getStart();
			Expr type=null, _value=null, traceback=null;

			if (!neverTestToken(peekToken())) {
				type = parseTest();
				if (maybeEat(TokenKind.COMMA)) {
					_value = parseTest();
					if (maybeEat(TokenKind.COMMA)) {
						traceback = parseTest();
					}
				}
			}
			RaiseStmt ret = new RaiseStmt(type, _value, traceback);
			ret.setLoc(start, getEnd());
			return ret;
		}

		//assert_stmt: 'assert' test [',' test]
		public AssertStmt parseAssertStmt() {
			eat(TokenKind.kASSERT);
			int start = getStart();
			Expr test = parseTest();
			Expr message = null;
			if (maybeEat(TokenKind.COMMA)) {
				message = parseTest();
			}
			AssertStmt ret = new AssertStmt(test, message);
			ret.setLoc(start, getEnd());
			return ret;
		}

		//print_stmt: 'print' ( [ test (',' test)* [','] ] | '>>' test [ (',' test)+ [','] ] )
		public PrintStmt parsePrintStmt() {
			eat(TokenKind.kPRINT);
			int start = getStart();
			Expr dest = null;
			bool trailingComma = false;
			if (maybeEat(TokenKind.RSHIFT)) {
				dest = parseTest();
				if (maybeEat(TokenKind.COMMA)) {
					trailingComma = true;
				} else {
					PrintStmt ret = new PrintStmt(dest, new Expr[0], false);
					ret.setLoc(start, getEnd());
					return ret;
				}
			}
		
			if (true) {
				ArrayList l = parseTestList(out trailingComma);
				Expr[] exprs = exprsFromList(l);
				PrintStmt ret = new PrintStmt(dest, exprs, trailingComma);
				ret.setLoc(start, getEnd());
				return ret;
			}
		}

		
		//classdef: 'class' NAME ['(' testlist ')'] ':' suite
		public ClassDef parseClassDef() {
			eat(TokenKind.kCLASS);
			int start = getStart();
			Name name = readName();
			Expr[] bases = new Expr[0];
			if (maybeEat(TokenKind.L_PAREN)) {
				ArrayList l  = parseTestList();
				bases = exprsFromList(l);
				eat(TokenKind.R_PAREN);
			}
			Stmt body = parseSuite();
			ClassDef ret = new ClassDef(name, bases, body);
			ret.setLoc(start, getEnd());
			return ret;
		}



		//funcdef: 'def' NAME parameters ':' suite
		//parameters: '(' [varargslist] ')'
		public FuncDef parseFuncDef() {
			eat(TokenKind.kDEF);
			int start = getStart();
			Name name = readName();
			
			eat(TokenKind.L_PAREN);

			Expr[] parameters, defaults;
			FuncDefFlags flags;
			parseVarArgsList(out parameters, out defaults, out flags, TokenKind.R_PAREN);

			yieldCount = 0;
			Stmt body = parseSuite();
			FuncDef ret = new FuncDef(name, parameters, defaults, flags, body);
			ret.yieldCount = this.yieldCount;
			this.yieldCount = -1;
			ret.setLoc(start, getEnd());
			return ret;
		}

		private Expr parseNameExpr() {
			return new NameExpr(readName());
		}

		//varargslist: (fpdef ['=' test] ',')* ('*' NAME [',' '**' NAME] | '**' NAME) | fpdef ['=' test] (',' fpdef ['=' test])* [',']
		//fpdef: NAME | '(' fplist ')'
		//fplist: fpdef (',' fpdef)* [',']
		private void parseVarArgsList(out Expr[] parameters, out Expr[] defaults, out FuncDefFlags flags, int terminator) {
			// parameters not doing * or ** today
			ArrayList al = new ArrayList();
			ArrayList dl = new ArrayList();
			bool needDefault = false;
			flags = FuncDefFlags.None;
			while (true) {
				if (maybeEat(terminator)) break;

				if (maybeEat(TokenKind.MUL)) {
					al.Add(parseNameExpr());
					flags |= FuncDefFlags.ArgList;
					if (maybeEat(TokenKind.COMMA)) {
						eat(TokenKind.POW);
						al.Add(parseNameExpr());
						flags |= FuncDefFlags.KwDict;
					}
					eat(terminator);
					break;
				} else if (maybeEat(TokenKind.POW)) {
					al.Add(parseNameExpr());
					flags |= FuncDefFlags.KwDict;
					eat(terminator);
					break;
				}

				Expr t = parsePrimary();
				al.Add(t);
				if (maybeEat(TokenKind.ASSIGN)) {
					needDefault = true;
					dl.Add(parseTest());
				} else if (needDefault) {
					throw Ops.SyntaxError("default value must be specified here");
				}
				if (!maybeEat(TokenKind.COMMA)) {
					eat(terminator);
					break;
				}
			}

			parameters = exprsFromList(al);
			defaults = exprsFromList(dl);
		}

		//lambdef: 'lambda' [varargslist] ':' test
		private int lambdaCount = 0;
		private Expr finishLambdef() {
			int start = getStart();
			Expr[] parameters, defaults;
			FuncDefFlags flags;
			parseVarArgsList(out parameters, out defaults, out flags, TokenKind.COLON);

			Expr expr = parseTest();
			Stmt body = new ReturnStmt(expr);
			FuncDef func = new FuncDef(Name.make("lamda$"+lambdaCount++), parameters, defaults, flags, body);
			func.setLoc(start, getEnd());
			LambdaExpr ret = new LambdaExpr(func);
			ret.setLoc(start, getEnd());
			return ret;
		}

		//while_stmt: 'while' test ':' suite ['else' ':' suite]
		public WhileStmt parseWhileStmt() {
			eat(TokenKind.kWHILE);
			int start = getStart();
			Expr test = parseTest();
			//eat(TokenKind.COLON);
			Stmt body = parseSuite();
			Stmt else_ = null;
			if (maybeEat(TokenKind.kELSE)) {
				//eat(TokenKind.COLON);
				else_ = parseSuite();
			}
			WhileStmt ret = new WhileStmt(test, body, else_);
			ret.setLoc(start, getEnd());
			return ret;
		}

		//for_stmt: 'for' exprlist 'in' testlist ':' suite ['else' ':' suite]
		public ForStmt parseForStmt() {
			eat(TokenKind.kFOR);
			int start = getStart();
			ArrayList l = parseExprList(); //TokenKind.kIN);
			Expr lhs = makeTupleOrExpr(l, false); //!!! wrong
			eat(TokenKind.kIN);
			Expr list = parseTestListAsExpr();
			Stmt body = parseSuite();
			Stmt else_ = null;
			if (maybeEat(TokenKind.kELSE)) {
				else_ = parseSuite();
			}
			ForStmt ret = new ForStmt(lhs, list, body, else_);
			ret.setLoc(start, getEnd());
			return ret;
		}

		// if_stmt: 'if' test ':' suite ('elif' test ':' suite)* ['else' ':' suite]
		public IfStmt parseIfStmt() {
			eat(TokenKind.kIF);
			int start = getStart();
			ArrayList l = new ArrayList();
			l.Add(parseIfStmtTest());

			while (maybeEat(TokenKind.kELIF)) {
				l.Add(parseIfStmtTest());
			}

			Stmt else_ = null;
			if (maybeEat(TokenKind.kELSE)) {
				//eat(TokenKind.COLON);
				else_ = parseSuite();
			}

			IfStmtTest[] tests = new IfStmtTest[l.Count];
			l.CopyTo(tests);
			IfStmt ret = new IfStmt(tests, else_);
			ret.setLoc(start, getEnd());
			return ret;
		}

		private IfStmtTest parseIfStmtTest() {
			Expr test = parseTest();
			//eat(TokenKind.COLON);
			Stmt suite = parseSuite();
			IfStmtTest ret = new IfStmtTest(test, suite);
			ret.setLoc(test.start, suite.end);
			return ret;
		}

		//try_stmt: ('try' ':' suite (except_clause ':' suite)+ 
		//    ['else' ':' suite] | 'try' ':' suite 'finally' ':' suite)
        //# NB compile.c makes sure that the default except clause is last
		
		public Stmt parseTryStmt() {
			eat(TokenKind.kTRY);
			int start = getStart();
			Stmt body = parseSuite();
			Stmt ret;

			if (maybeEat(TokenKind.kFINALLY)) {
				Stmt finally_ = parseSuite();
				ret = new TryFinallyStmt(body, finally_);
			} else {
				ArrayList l = new ArrayList();
				while (peekToken().kind == TokenKind.kEXCEPT) {
					l.Add(parseTryStmtHandler());
				}
				TryStmtHandler[] handlers = new TryStmtHandler[l.Count];
				l.CopyTo(handlers);

				Stmt else_ = null;
				if (maybeEat(TokenKind.kELSE)) {
					else_ = parseSuite();
				}

				ret = new TryStmt(body, handlers, else_);
			}
			ret.setLoc(start, getEnd());
			return ret;
		}

		//except_clause: 'except' [test [',' test]]
		private TryStmtHandler parseTryStmtHandler() {
			eat(TokenKind.kEXCEPT);
			int start = getStart();
			Expr test1 = null, test2 = null;
			if (peekToken().kind != TokenKind.COLON) {
				test1 = parseTest();
				if (maybeEat(TokenKind.COMMA)) {
					test2 = parseTest();
				}
			}
			Stmt body = parseSuite();
//			if (test2 == null) {
//				test2 = test1; test1 = null;
//			}
			TryStmtHandler ret = new TryStmtHandler(test1, test2, body);
			ret.setLoc(start, getEnd());
			return ret;
		}

		//suite: simple_stmt | NEWLINE INDENT stmt+ DEDENT
		public Stmt parseSuite() {
			eat(TokenKind.COLON);
			int start = getStart();
			ArrayList l = new ArrayList();
			if (maybeEat(TokenKind.NEWLINE)) {
				eat(TokenKind.INDENT);
				while (true) {
					int line = tokenizer.line;
					Stmt s = parseStmt();
					s.line = line;
					l.Add(s);
					if (maybeEat(TokenKind.DEDENT)) break;
				}
				Stmt[] stmts = new Stmt[l.Count];
				l.CopyTo(stmts);
				SuiteStmt ret = new SuiteStmt(stmts);
				ret.setLoc(start, getEnd());
				return ret;
			} else {
				return parseSimpleStmt();
			}
		}


		// test: and_test ('or' and_test)* | lambdef
		public Expr parseTest() {
			if (maybeEat(TokenKind.kLAMBDA)) {
				return finishLambdef();
			}
			Expr ret = parseAndTest();
			while (maybeEat(TokenKind.kOR)) {
				ret = new OrExpr(ret, parseTest());
			}
			return ret;
		}

		// and_test: not_test ('and' not_test)*
		public Expr parseAndTest() {
			Expr ret = parseNotTest();
			while (maybeEat(TokenKind.kAND)) {
				ret = new AndExpr(ret, parseAndTest());
			}
			return ret;
		}

		//not_test: 'not' not_test | comparison
		public Expr parseNotTest() {
			if (maybeEat(TokenKind.kNOT)) {
				int start = getStart();
				Expr ret = new UnaryExpr(Operator.NotOp, parseNotTest());
				ret.start = start;
				return ret;
			} else {
				return parseComparison();
			}
		}
		//comparison: expr (comp_op expr)*
		//comp_op: '<'|'>'|'=='|'>='|'<='|'<>'|'!='|'in'|'not' 'in'|'is'|'is' 'not'
		public Expr parseComparison() {
			Expr ret = parseExpr();
			while (true) {
				BinaryOperator op;
				Token t = peekToken();
				switch (t.kind) {
					case TokenKind.LT: nextToken(); op = Operator.LtOp; break;
					case TokenKind.LE: nextToken(); op = Operator.LeOp; break;
					case TokenKind.GT: nextToken(); op = Operator.GtOp; break;
					case TokenKind.GE: nextToken(); op = Operator.GeOp; break;
					case TokenKind.EQ: nextToken(); op = Operator.EqOp; break;
					case TokenKind.NE: nextToken(); op = Operator.NeOp; break;
					case TokenKind.LG: nextToken(); op = Operator.NeOp; break;

					case TokenKind.kIN: nextToken(); op = Operator.InOp; break;
					case TokenKind.kNOT: nextToken(); eat(TokenKind.kIN); op = Operator.NotInOp; break;

					case TokenKind.kIS:
						nextToken(); 
						if (maybeEat(TokenKind.kNOT)) op = Operator.IsNotOp;
						else op = Operator.IsOp;
						break;
					default:
						return ret;
				}
				ret = new BinaryExpr(op, ret, parseComparison());
			}

		}

		/*
		expr: xor_expr ('|' xor_expr)*
		xor_expr: and_expr ('^' and_expr)*
		and_expr: shift_expr ('&' shift_expr)*
		shift_expr: arith_expr (('<<'|'>>') arith_expr)*
		arith_expr: term (('+'|'-') term)*
		term: factor (('*'|'/'|'%'|'//') factor)*
		*/
		public Expr parseExpr() {
			return parseExpr(0);
		}

		public Expr parseExpr(int precedence) {
			Expr ret = parseFactor();
			while (true) {
				Token t = peekToken();
				OperatorToken ot = t as OperatorToken;
				if (ot == null) return ret;

				int prec = ot.op.precedence;
				if (prec >= precedence) {
					nextToken();
					Expr right = parseExpr(prec+1);
					ret = new BinaryExpr((BinaryOperator)ot.op, ret, right);
				} else {
					return ret;
				}
			}
		}

		// factor: ('+'|'-'|'~') factor | power
		public Expr parseFactor() {
			Token t = peekToken();
			int start = getStart();
			Expr ret;
			switch (t.kind) {
				case TokenKind.ADD:
					nextToken();
					ret = new UnaryExpr(Operator.PosOp, parseFactor());
					break;
				case TokenKind.SUB:
					nextToken();
					ret = new UnaryExpr(Operator.NegOp, parseFactor());
					break;
				case TokenKind.TWIDLE:
					nextToken();
					ret = new UnaryExpr(Operator.InvertOp, parseFactor());
					break;
				default:
					return parsePower();
			}
			ret.start = start;
			return ret;
		}

		// power: atom trailer* ['**' factor]
		public Expr parsePower() {
			Expr ret = parsePrimary();
			ret = addTrailers(ret);
			if (maybeEat(TokenKind.POW)) {
				ret = new BinaryExpr(Operator.PowOp, ret, parseFactor());
			}
			return ret;
		}



		//atom: '(' [testlist] ')' | '[' [listmaker] ']' | '{' [dictmaker] '}' | '`' testlist1 '`' | NAME | NUMBER | STRING+
		public Expr parsePrimary() {
			Token t = nextToken();
			Expr ret;
			switch(t.kind) {
				case TokenKind.L_PAREN:
					return finishTupleValue();
				case TokenKind.L_BRACKET:
					return finishListValue();
				case TokenKind.L_BRACE:
					return finishDictValue();
				case TokenKind.BACKQUOTE:
					return finishBackquote();
				case TokenKind.NAME:
					ret = new NameExpr((Name)t.getValue());
					setStartAndEnd(ret);
					return ret;
				case TokenKind.CONSTANT:
					object cv = t.getValue();
					if (cv is String) {
						cv = finishStringPlus( (string) cv);
					}
					// todo handle STRING+
					ret = new ConstantExpr(cv);
					setStartAndEnd(ret);
					return ret;
				default:
					throw makeSyntaxError(t);
			}
		}

		private string finishStringPlus(string s) {
			Token t = peekToken();
			//Console.WriteLine("finishing string with " + t);
			while (true) {
				if (t is ConstantValueToken) {
					object cv = t.getValue();
					if (cv is String) {
						s += (string)cv;
						nextToken();
						t = peekToken();
						//Console.WriteLine("have: " + s + " seeing " + t);
						continue;
					}
				}
				break;
			}
			return s;
		}

		//trailer: '(' [arglist] ')' | '[' subscriptlist ']' | '.' NAME
		private Expr addTrailers(Expr ret) {
			while (true) {
				Token t = peekToken();
				switch (t.kind) {
					case TokenKind.L_PAREN:
						nextToken();
						Arg[] args = parseArgList();
						ret = new CallExpr(ret, args);
						ret.end = getEnd();
						break;
					case TokenKind.L_BRACKET:
						nextToken();
						Expr index = parseSubscriptList();
						ret = new IndexExpr(ret, index);
						ret.end = getEnd();
						break;
					case TokenKind.DOT:
						nextToken();
						Name name = readName();
						ret = new FieldExpr(ret, name);
						ret.end = getEnd();
						break;
					default:
						return ret;
				}
			}
		}

		//subscriptlist: subscript (',' subscript)* [',']
		//subscript: '.' '.' '.' | test | [test] ':' [test] [sliceop]
		//sliceop: ':' [test]
		public Expr parseSubscriptList() {
			const int terminator = TokenKind.R_BRACKET;
			int start0 = getStart();
			bool trailingComma = false;

			ArrayList l = new ArrayList();
			while (true) {
				if (maybeEat(terminator)) {
					break;
				}
				Expr e;
				if (maybeEat(TokenKind.DOT)) {
					int start = getStart();
					eat(TokenKind.DOT); eat(TokenKind.DOT);
					e = new ConstantExpr(Ops.Ellipsis);
					e.setLoc(start, getEnd());
				} else if (maybeEat(TokenKind.COLON)) {
					e = finishSlice(null, getStart());
				} else {
					e = parseTest();
					if (maybeEat(TokenKind.COLON)) {
						e = finishSlice(e, e.start);
					}
				}

				l.Add(e);
				if (!maybeEat(TokenKind.COMMA)) {
					eat(terminator);
					trailingComma = false;
					break;
				}
				trailingComma = true;
			}
			Expr ret = makeTupleOrExpr(l, trailingComma);
			ret.setLoc(start0, getEnd());
			return ret;
		}

		private Expr finishSlice(Expr e0, int start) {
			Expr e1 = null;
			Token t = peekToken();
			switch(t.kind) {
				case TokenKind.COMMA: case TokenKind.R_BRACKET:
					break;
				case TokenKind.COLON:
					nextToken();
					break;
				default:
					e1 = parseTest();
					break;
			}
			Expr e2 = null;
			t = peekToken();
			switch(t.kind) {
				case TokenKind.COMMA: case TokenKind.R_BRACKET:
					break;
				default:
					e2 = parseTest();
					break;
			}
			SliceExpr ret = new SliceExpr(e0, e1, e2);
			ret.setLoc(start, getEnd());
			return ret;
		}
		

		//exprlist: expr (',' expr)* [',']
		private ArrayList parseExprList() {
			ArrayList l = new ArrayList();
			while (true) {
				Expr e = parseExpr();
				l.Add(e);
				if (!maybeEat(TokenKind.COMMA)) {
					break;
				}
				if (neverTestToken(peekToken())) {
					break;
				}
			}
			return l;
		}
//		private ArrayList parseExprList(int terminator) {
//			ArrayList l = new ArrayList();
//			while (true) {
//				Expr e = parseExpr();
//				l.Add(e);
//				if (!maybeEat(TokenKind.COMMA)) {
//					break;
//				}
//				if (peekToken().kind == terminator) {
//					break;
//				}
//			}
//			return l;
//		}

		//arglist: (argument ',')* (argument [',']| '*' test [',' '**' test] | '**' test)
		//argument: [test '='] test	# Really [keyword '='] test
		private Arg[] parseArgList() {
			const int terminator = TokenKind.R_PAREN;
			ArrayList l = new ArrayList();
			while (true) {
				if (maybeEat(terminator)) {
					break;
				}
				int start = getStart();
				Arg a;
				if (maybeEat(TokenKind.MUL)) {
					Expr t = parseTest();
					a = new Arg(CallExpr.VAR_NAME, t);
				} else if (maybeEat(TokenKind.POW)) {
					Expr t = parseTest();
					a = new Arg(CallExpr.KW_NAME, t);
				} else {
					Expr e = parseTest();
					if (maybeEat(TokenKind.ASSIGN)) {
						NameExpr n = e as NameExpr;
						if (n == null) {
							throw Ops.SyntaxError("expected name");
						}
						e = parseTest();
						a = new Arg(n.name, e);
					} else {
						a = new Arg(e);
					}
				}
				a.setLoc(start, getEnd());
				l.Add(a);
				if (!maybeEat(TokenKind.COMMA)) {
					eat(terminator);
					break;
				}
			}
			Arg[] ret = new Arg[l.Count];
			l.CopyTo(ret);
			return ret;

		}

		private ArrayList parseTestList() {
			bool tmp;
			return parseTestList(out tmp);
		}

		//		testlist: test (',' test)* [',']
		//		testlist_safe: test [(',' test)+ [',']]
		//		testlist1: test (',' test)*
		private ArrayList parseTestList(out bool trailingComma) {
			ArrayList l = new ArrayList();
			trailingComma = false;
			while (true) {
				if (this.neverTestToken(peekToken())) break;
				Expr e = parseTest();
				l.Add(e);
				if (!maybeEat(TokenKind.COMMA)) {
					trailingComma = false;
					break;
				}
				trailingComma = true;
			}
			return l;
		}

		private Expr parseTestListAsExpr() {
			int start = getStart();
			bool trailingComma;
			ArrayList l = parseTestList(out trailingComma);
			Expr ret = makeTupleOrExpr(l, trailingComma);
			ret.setLoc(start, getEnd());
			return ret;
		}

		private Expr finishTupleValue() {
			Expr ret = parseTestListAsExpr();
			eat(TokenKind.R_PAREN);
			ret.end = getEnd();
			return ret;
		}

		//dictmaker: test ':' test (',' test ':' test)* [',']
		private Expr finishDictValue() {
			int start = getStart();
			ArrayList l = new ArrayList();
			while (true) {
				if (maybeEat(TokenKind.R_BRACE)) {
					break;
				}
				Expr e1 = parseTest();
				eat(TokenKind.COLON);
				Expr e2 = parseTest();
				SliceExpr se = new SliceExpr(e1, e2, null);
				se.setLoc(e1.start, e2.end);
				l.Add(se);

				if (!maybeEat(TokenKind.COMMA)) {
					eat(TokenKind.R_BRACE);
					break;
				}
			}
			SliceExpr[] exprs = new SliceExpr[l.Count];
			l.CopyTo(exprs);
			DictExpr ret = new DictExpr(exprs);
			ret.setLoc(start, getEnd());
			return ret;
		}


		//		/*
		//		listmaker: test ( list_for | (',' test)* [','] )
		//		*/
		private Expr finishListValue() {
			Expr ret;
			int start = getStart();
			if (maybeEat(TokenKind.R_BRACKET)) {
				ret = new ListExpr();
				ret.setLoc(start, getEnd());
				return ret;
			}

			Expr t0 = parseTest();
			if (maybeEat(TokenKind.COMMA)) {
				ArrayList l = parseTestList();
				eat(TokenKind.R_BRACKET);
				l.Insert(0, t0);
				ret = new ListExpr(exprsFromList(l));
			} else if (peekToken(TokenKind.kForToken)) {
				return finishListComp(start, t0);
			} else {
				eat(TokenKind.R_BRACKET);
				ret = new ListExpr(t0);
			}
			ret.setLoc(start, getEnd());
			return ret;
		}

		//		list_iter: list_for | list_if
		private Expr finishListComp(int start, Expr item) {
			ArrayList forIters = new ArrayList();
			ArrayList ifIters = new ArrayList();
			while (true) {
				if (peekToken(TokenKind.kForToken)) {
					forIters.Add(parseListCompFor());
				} else if (peekToken(TokenKind.kIfToken)) {
					ifIters.Add(parseListCompIf());
				} else {
					break;
				}
			}
			eat(TokenKind.R_BRACKET);

			ListCompFor[] forIterArray = new ListCompFor[forIters.Count];
			forIters.CopyTo(forIterArray);
			ListCompIf[] ifIterArray = new ListCompIf[ifIters.Count];
			ifIters.CopyTo(ifIterArray);

			ListComp ret = new ListComp(item, forIterArray, ifIterArray);
			ret.setLoc(start, getEnd());
			return ret;
		}

		//		list_for: 'for' exprlist 'in' testlist_safe [list_iter]
		private ListCompFor parseListCompFor() {
			eat(TokenKind.kFOR);
			int start = getStart();
			ArrayList l = parseExprList();
			Expr lhs = makeTupleOrExpr(l, false); //!!! wrong
			eat(TokenKind.kIN);
			Expr list = parseTestListAsExpr();

			ListCompFor ret = new ListCompFor(lhs, list);
			ret.setLoc(start, getEnd());
			return ret;
		}

		//		list_if: 'if' test [list_iter]
		private ListCompIf parseListCompIf() {
			eat(TokenKind.kIF);
			int start = getStart();
			Expr test = parseTest();
			ListCompIf ret = new ListCompIf(test);
			ret.setLoc(start, getEnd());
			return ret;
		}

		private Expr finishBackquote() {
			Expr ret;
			int start = getStart();
			Expr expr = parseTestListAsExpr();
			eat(TokenKind.BACKQUOTE);
			ret = new BackquoteExpr(expr);
			ret.setLoc(start, getEnd());
			return ret;
		}

		protected Expr[] exprsFromList(ArrayList l) {
			Expr[] ret = new Expr[l.Count];
			l.CopyTo(ret);
			return ret;
		}

		protected Expr makeTupleOrExpr(ArrayList l, bool trailingComma) {
			if (l.Count == 1 && !trailingComma) return (Expr)l[0];
			return new TupleExpr(exprsFromList(l));
		}

		private bool neverTestToken(Token t) {
			switch (t.kind) {
				case TokenKind.ADD_EQ: return true;
				case TokenKind.SUB_EQ: return true;
				case TokenKind.MUL_EQ: return true;
				case TokenKind.DIV_EQ: return true;
				case TokenKind.MOD_EQ: return true;
				case TokenKind.AND_EQ: return true;
				case TokenKind.OR_EQ: return true;
				case TokenKind.XOR_EQ: return true;
				case TokenKind.LSHIFT_EQ: return true;
				case TokenKind.RSHIFT_EQ: return true;
				case TokenKind.POW_EQ: return true;
				case TokenKind.FLOORDIV_EQ: return true;

				case TokenKind.INDENT: return true;
				case TokenKind.DEDENT: return true;
				case TokenKind.NEWLINE: return true;
				case TokenKind.SEMICOLON: return true;

				case TokenKind.ASSIGN: return true;
				case TokenKind.R_BRACE: return true;
				case TokenKind.R_BRACKET: return true;
				case TokenKind.R_PAREN: return true;

				case TokenKind.COMMA: return true;

				case TokenKind.kFOR: return true;
				case TokenKind.kIN: return true;
				case TokenKind.kIF: return true;

				default: return false;
			}
		}
	}
}
