/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;
using System.Text;
using System.IO;

using System.Resources;
using System.Diagnostics;
using System.Diagnostics.SymbolStore;

using System.Reflection;
using System.Reflection.Emit;

using IronPython.Objects;

namespace IronPython.AST {
	public class NewTypeMaker {
		private static int index = 0;

		public const string typePrefix = "IronPython.NewTypes.";
		public static Dict newTypes = new Dict();
		public static Type GetNewType(string mod, string name, Tuple bases, IDictionary dict) {
			// we're really only interested in the "correct" base type pulled out of bases
			// and any slot information contained in dict
			// other info might be used for future optimizations

			Type baseType = GetBaseType(bases);
			//!!! next collect any slot information, this might force a new Type creation

			Type existingType = (Type)newTypes[baseType];
			if (existingType != null) return existingType;

			Type ret = new NewTypeMaker(baseType).CreateNewType();
			newTypes[baseType] = ret;

			return ret;
		}

		private TypeGen tg;
		private Slot typeField, dictField;
		private Type baseType;
		private bool hasBaseTypeField = false;
		public NewTypeMaker(Type baseType) {
			this.baseType = baseType;
		}

		public Type CreateNewType() {
			AssemblyGen ag = SnippetMaker.snippetAssembly;

			tg = ag.defineType(typePrefix + baseType.FullName, baseType);
			
			FieldInfo baseTypeField = baseType.GetField("__class__");
			if (baseTypeField == null) {
				typeField = tg.AddField(typeof(UserType), "__class__");
			} else {
				typeField = new FieldSlot(new ThisSlot(tg.myType), baseTypeField);
				hasBaseTypeField = true;
			}

			FieldInfo baseDictField = baseType.GetField("dict");
			if (baseDictField == null) {
				dictField = tg.AddField(typeof(Dict), "__dict__");
			} else {
				dictField = new FieldSlot(new ThisSlot(tg.myType), baseDictField);
				//!!! anything else
			}

			ImplementDynamicObject();

			foreach (ConstructorInfo ci in baseType.GetConstructors()) { //!!! how can we chain to protected constructors
				ConstructorInfo myConstructor = tg.DefineChainedConstructor(ci);
				GenerateOptimizedMaker(myConstructor, ci.GetParameters());
				//!!!ReflectOptimizer.GenerateSingleMethod(tg, myConstructor);
			}

			OverrideVirtualMethods();

			//??? constructor inheritance is loads of fun...
//			CodeGen newGen = tg.defineMethod(
//				MethodAttributes.Static|MethodAttributes.Public,
//				"__new__", typeof(PyObject), new Type[0]);
//			newGen.emitNew(tg.myType.DefineDefaultConstructor(MethodAttributes.Public));
//			newGen.ilg.Emit(OpCodes.Ret);

			//!!!Hashtable slots = collectSlots(dict, tg);
			//!!!if (slots != null) tg.createAttrMethods(slots);

			//!!!OverrideVirtualMethods(baseType, tg, typeField);

			Type ret = tg.finishType();
			return ret;
		}

		private void GenerateOptimizedMaker(ConstructorInfo ci, ParameterInfo[] pis) {
			if (pis.Length == 1 && pis[0].ParameterType == typeof(object[])){ //!!!
				CodeGen cg = tg.defineMethod(MethodAttributes.Public|MethodAttributes.Static, "MakeNew", typeof(object), 
					new Type[] { typeof(object[]) });
				cg.emitArgGet(0);
				cg.emitNew(ci);
				cg.emitReturn();
				cg.finish();
				
			} else {
				CodeGen cg = tg.defineMethod(MethodAttributes.Public|MethodAttributes.Static, "MakeNew", typeof(object), 
					Constants.makeArray(typeof(object), pis.Length));
				for (int i=0; i < pis.Length; i++) {
					cg.emitArgGet(i);
					ReflectOptimizer.EmitCastFromObject(cg, pis[i].ParameterType);
				}
				cg.emitNew(ci);
				cg.emitReturn();
				cg.finish();
			}
		}

		private void ImplementDynamicObject() {
			//			public interface IDynamicObject {
			//				bool GetSlot(string name, out object ret);
			//				void SetSlot(string name, object value);
			//				void DelSlot(string name);
			//
			//				DynamicType GetDynamicType();
			//			}
			//
			//			public interface ISuperDynamicObject:IDynamicObject {
			//				Dict GetDict();
			//				void SetDict(Dict dict);
			//
			//				void SetDynamicType(ReflectedType newType);
			//			}
			CodeGen cg;

			tg.myType.AddInterfaceImplementation(typeof(ISuperDynamicObject));

			cg = tg.DefineMethodOverride(typeof(ISuperDynamicObject).GetMethod("GetDict"));
			dictField.emitGet(cg);
			cg.emitReturn();
			cg.finish();

			cg = tg.DefineMethodOverride(typeof(ISuperDynamicObject).GetMethod("SetDict"));
			cg.emitArgGet(0);
			dictField.emitSet(cg);
			cg.emitReturn();
			cg.finish();

			if (hasBaseTypeField) return;

			cg = tg.DefineMethodOverride(typeof(IDynamicObject).GetMethod("GetDynamicType"));
			typeField.emitGet(cg);
			cg.emitReturn();
			cg.finish();

			cg = tg.DefineMethodOverride(typeof(ISuperDynamicObject).GetMethod("SetDynamicType"));
			cg.emitArgGet(0);
			typeField.emitSet(cg);
			cg.emitReturn();
			cg.finish();

//			DefineTypeDelegateMethod(typeof(IDynamicObject), "GetSlot", "GetSlotForInstance");
//			DefineTypeDelegateMethod(typeof(IDynamicObject), "SetSlot", "SetSlotForInstance");
//			DefineTypeDelegateMethod(typeof(IDynamicObject), "DelSlot", "DelSlotForInstance");
		}

		private void DefineTypeDelegateMethod(Type interfaceType, string interfaceMethodName, string typeMethodName) {
			CodeGen cg = tg.DefineMethodOverride(interfaceType.GetMethod(interfaceMethodName));
			typeField.emitGet(cg);
			cg.emitThis();
			for (int i=0; i < cg.methodToOverride.GetParameters().Length; i++) {
				cg.emitArgGet(i);
			}
			cg.emitCall(typeof(ReflectedType), typeMethodName);
			cg.emitReturn();
			cg.finish();
		}


		private static Type GetBaseType(Tuple bases) {
			if (bases.Count == 0) {
				return typeof(object);
			} else if (bases.Count > 1) {
				throw new NotImplementedException("more than one base type for new-style class");
			} else {
				object baseType = bases[0];
				PythonType rt = baseType as PythonType;
				if (rt != null) {
					Type ret = rt.GetTypeToExtend();
					if (ret == typeof(PythonType)) ret = typeof(UserType);
					return ret;
				} else {
					//!!! more to do
					throw new NotImplementedException("unsupported base type for new-style class: " + baseType);
				}
			}
		}

		public void OverrideVirtualMethods() {
			foreach (MethodInfo mi in baseType.GetMethods()) {
				if (mi.Name == "__getitem__" || mi.Name == "ToString" || mi.Name == "__setitem__" || mi.Name == "__cmp__") OverrideBaseMethod(mi); //!!! horrible
			}
//			CodeGen cg;
//
//			cg = tg.defineMethod(MethodAttributes.Public|MethodAttributes.Virtual, "ToString",
//				typeof(string), Type.EmptyTypes);
//			typeField.emitGet(cg);
//			cg.emitThis();
//			cg.emitCall(typeof(ReflectedType), "StrForInstance");
//			cg.emitReturn();
//			cg.finish();
//
//
//			tg.myType.AddInterfaceImplementation(typeof(ICodeFormattable));
//			cg = tg.DefineMethodOverride(typeof(ICodeFormattable).GetMethod("ToCodeString"));
//			typeField.emitGet(cg);
//			cg.emitThis();
//			cg.emitCall(typeof(ReflectedType), "ReprForInstance");
//			cg.emitReturn();
//			cg.finish();
//
//			OverrideSetItem();
		}

		public Slot GetOrMakeField(string name) {
			if (name == "ToString") name = "__str__"; //???
			FieldInfo fi = typeof(PythonType).GetField(name+"F");
			if (fi == null) return null;  //!!! actually should make the field on a custom UserType

			return new FieldSlot(typeField, fi);
		}



		private void OverrideBaseMethod(MethodInfo mi) {
			if (mi == null || !mi.IsVirtual || mi.IsFinal) return;

			Slot methField = GetOrMakeField(mi.Name);
			if (methField == null) return; //!!!

			CodeGen cg = tg.DefineMethodOverride(mi);

			//cg.ilg.EmitWriteLine(string.Format("entering {0}", mi.Name));
//			CodeGen cg = tg.defineMethod(MethodAttributes.Public|MethodAttributes.Virtual, baseCmp.Name, baseCmp.ReturnType, 
//				Constants.GetTypes(baseCmp.GetParameters()));
			Label baseCall = cg.ilg.DefineLabel();
			
			methField.emitGet(cg); 
			cg.emitCall(typeof(MethodWrapper), "IsBuiltinMethod");
			cg.ilg.Emit(OpCodes.Brtrue, baseCall);

			methField.emitGet(cg);
			cg.emitThis();
			for (int i=0; i < mi.GetParameters().Length; i++) {
				cg.emitArgGet(i);
				ReflectOptimizer.EmitCastToObject(cg, mi.GetParameters()[i].ParameterType);
			}
			
			cg.emitCall(typeof(MethodWrapper), "Invoke", Constants.makeArray(typeof(object), 1+mi.GetParameters().Length));
			ReflectOptimizer.EmitCastFromObject(cg, mi.ReturnType);
			cg.emitReturn();

			cg.ilg.MarkLabel(baseCall);
			cg.emitThis();
			for (int i=0; i < mi.GetParameters().Length; i++) cg.emitArgGet(i);
			cg.ilg.EmitCall(OpCodes.Call, mi, null); // base call must be non-virtual
			cg.emitReturn();
			cg.finish();
		}




//		private void OverrideSetItem() {
//			MethodInfo baseCmp = baseType.GetMethod("__setitem__", new Type[] { typeof(object), typeof(object) }); //indexer.GetSetMethod(); //baseType.GetProperty( baseType.GetMethod("CompareTo", new Type[] { typeof(object) });
//			if (baseCmp == null || !baseCmp.IsVirtual || baseCmp.IsFinal) return;
//
//			FieldInfo fi = typeof(ReflectedType).GetField("__setitem__"); // tg.myType.DefineField("__setitem__", typeof(object), FieldAttributes.Static|FieldAttributes.Public);
//			
//			Slot methField = GetOrMakeField(
//			CodeGen cg = tg.defineMethod(MethodAttributes.Public|MethodAttributes.Virtual, baseCmp.Name, baseCmp.ReturnType, 
//				Constants.GetTypes(baseCmp.GetParameters()));
//			Label baseCall = cg.ilg.DefineLabel();
//			methField.emitGet(cg); //cg.emitFieldGet(fi);
//			cg.ilg.Emit(OpCodes.Brfalse, baseCall);
//			
//			methField.emitGet(cg); //cg.emitFieldGet(fi);
//			cg.emitThis();
//			for (int i=0; i < baseCmp.GetParameters().Length; i++) cg.emitArgGet(i);
//			cg.emitCall(typeof(Ops), "Call", Constants.makeArray(typeof(object), 2+baseCmp.GetParameters().Length));
//			cg.ilg.Emit(OpCodes.Pop); //!!!cg.emitCall(typeof(Ops), "object2int");
//			cg.emitReturn();
//
//			cg.ilg.MarkLabel(baseCall);
//			cg.emitThis();
//			for (int i=0; i < baseCmp.GetParameters().Length; i++) cg.emitArgGet(i);
//			cg.ilg.EmitCall(OpCodes.Call, baseCmp, null); // base call must be non-virtual
//			cg.emitReturn();
//			cg.finish();
//		}

//			tg.myType.AddInterfaceImplementation(typeof(ICodeFormattable));
//			cg = tg.defineMethod(MethodAttributes.Public|MethodAttributes.Virtual, "ToCodeString",
//				typeof(string), Type.EmptyTypes);
//			cg.emitFieldGet(typeField);
//			cg.emitThis();
//
//			MethodInfo baseToString = baseType.GetMethod("ToString", Type.EmptyTypes);
//			if (baseToString.DeclaringType != typeof(object)) {
//				cg.emitThis();
//				cg.ilg.EmitCall(OpCodes.Call, baseToString, null);
//			} else {
//				cg.ilg.Emit(OpCodes.Ldnull);
//			}
//
//			cg.emitCall(typeof(ReflectedType), "ToCodeString", new Type[] { typeof(object), typeof(string) });
//			cg.ilg.Emit(OpCodes.Ret);
//			cg.finish();
//			tg.myType.DefineMethodOverride(cg.methodBuilder, typeof(ICodeFormattable).GetMethod("ToCodeString"));
//
//			OverrideCompareTo(baseType, tg, typeField);
//		}
//
////		public static object CompareTo_Function = null;
////		public override int CompareTo(object obj) {
////			if (CompareTo_Function != null) return Ops.object2int(Ops.Call(CompareTo_Function, this, obj));
////			return base.CompareTo(obj);
////		}
//		private static void OverrideCompareTo(Type baseType, TypeGen tg, FieldInfo typeField) {
//			MethodInfo baseCmp = baseType.GetMethod("CompareTo", new Type[] { typeof(object) });
//			if (baseCmp == null || !baseCmp.IsVirtual) return;
//
//			FieldInfo fi = tg.myType.DefineField("__cmp__", typeof(object), FieldAttributes.Static|FieldAttributes.Public);
//
//			CodeGen cg = tg.defineMethod(MethodAttributes.Public|MethodAttributes.Virtual, baseCmp.Name, baseCmp.ReturnType, 
//						Constants.GetTypes(baseCmp.GetParameters()));
//			Label baseCall = cg.ilg.DefineLabel();
//			cg.emitFieldGet(fi);
//			cg.ilg.Emit(OpCodes.Brfalse, baseCall);
//			
//			cg.emitFieldGet(fi);
//			cg.emitThis();
//			cg.ilg.Emit(OpCodes.Ldarg_1);
//			cg.emitCall(typeof(Ops), "Call", Constants.makeArray(typeof(object), 3));
//			cg.emitCall(typeof(Ops), "object2int");
//			cg.emitReturn();
//
//			cg.ilg.MarkLabel(baseCall);
//			cg.emitThis();
//			cg.ilg.Emit(OpCodes.Ldarg_1);
//			cg.ilg.EmitCall(OpCodes.Call, baseCmp, null); // base call must be non-virtual
//			cg.emitReturn();
//		}


//
//		//!!! This is half the job
//		private static void overrideDeclaredMethods(PyDictionary dict, TypeGen tg) {
//			foreach (DictionaryEntry entry in dict) {
//				PyString name = entry.Key as PyString;
//				if (name == null) continue;
//
//				//Console.WriteLine("considering {0} with {1}", name, entry.Value);
//
//				PyFunction func = entry.Value as PyFunction;
//				if (func == null || func is PyBuiltinFunction) continue;
//
////				if (name == Names.__new__) {
////
////				}
//
//				//!!! we'd like a non-reflexive way to do this faster...
//				if (tg.myType.BaseType.GetMethod(name.value,
//					Constants.makeArray(typeof(PyObject), func.argNames.Length-1)) != null) 
//				{
//					overrideDeclaredMethod(name, func, tg);
//				}
//			}
//		}
//
//		private static void overrideDeclaredMethod(PyString name, PyFunction func, TypeGen tg) {
//			Console.WriteLine("overriding: " + name);
//			int nargs = func.argNames.Length-1;
//			
//			CodeGen cg = tg.defineMethod(MethodAttributes.Public|MethodAttributes.Virtual,
//				name.value, typeof(PyObject), Constants.makeArray(typeof(PyObject), nargs));
//			
//			//cg.emitLine(42);
//
//			cg.emitModuleInstance();
//			cg.emitThis();
//			for (int i=0; i < nargs; i++) {
//				cg.ilg.Emit(OpCodes.Ldarg, i+1);
//			}
//
//			cg.emitCall(func.getMethodInfo());
//
//			cg.emitReturn();
//		}
//
//		private static Hashtable collectSlots(PyDictionary dict, TypeGen tg) {
//			PyObject slots;
//			if (!dict.__getitem__(Names.__slots__, out slots)) {
//				createDictSlot(tg);
//				return null;
//			}
//
//			Hashtable ret = new Hashtable();
//
//			PyObject iter = slots.__iter__();
//			PyObject name;
//			Slot thisSlot = new ThisSlot(tg.myType);
//			while (iter.next(out name)) {
//				string sname = name.ToString();
//				if (sname == "__dict__") {
//					createDictSlot(tg);
//					continue;
//				}
//				ret[Name.make(sname)] =
//					new FieldSlot(thisSlot,
//						tg.myType.DefineField(sname, typeof(PyObject), FieldAttributes.Public));
//			}
//
//			return ret;
//		}
//
//		private static void createDictSlot(TypeGen tg) {
//			FieldBuilder field = tg.myType.DefineField("_dict", typeof(PyDictionary),
//				FieldAttributes.Public);
//
//			CodeGen getGen = tg.defineMethod(
//				MethodAttributes.Public|MethodAttributes.Virtual,
//				"get__dict__", typeof(PyObject), new Type[0]);
//
//			//getGen.ilg.EmitWriteLine("doing __dict__ property");
//
//			getGen.emitThis();
//			getGen.emitFieldGet(field);
//			getGen.ilg.Emit(OpCodes.Dup);
//
//			Label doReturn = getGen.ilg.DefineLabel();
//			Slot tmp = getGen.getLocalTmp(typeof(PyDictionary));
//			getGen.ilg.Emit(OpCodes.Brtrue, doReturn);
//			getGen.ilg.Emit(OpCodes.Pop);
//			getGen.emitThis();
//			getGen.emitCall(typeof(PyDictionary), "make", new Type[0]);
//			getGen.ilg.Emit(OpCodes.Dup);
//			tmp.emitSet(getGen);
//			getGen.emitFieldSet(field);
//			tmp.emitGet(getGen);
//
//			getGen.ilg.MarkLabel(doReturn);
//			getGen.ilg.Emit(OpCodes.Ret);
//		
////			PropertyBuilder pb = tg.myType.DefineProperty("__dict__",
////				PropertyAttributes.None, typeof(PyObject), new Type[] { typeof(PyObject) });
////			pb.SetGetMethod(getGen.methodBuilder);
//		}

	}
}
