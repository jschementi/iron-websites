/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Reflection;
using System.Reflection.Emit;

using IronPython.Objects;

namespace IronPython.AST
{
	/// <summary>
	/// Summary description for SnippetMaker.
	/// </summary>
	public class SnippetMaker {
		public static AssemblyGen snippetAssembly = 
			new AssemblyGen("<snippets>", "snippets", "snippets.dll");

		static int count = 0;
		public static void DumpAssembly() {
			snippetAssembly.myAssembly.Save("snippets.dll");
			snippetAssembly = new AssemblyGen("<snippets>", "snippets"+count, "snippets" + (count++) + ".dll");
		}

		private static int index=0;
		public static FrameCode generate(Stmt body, string name) {
			// This is where we first expect to use lcg.  This should just make a function, not a full class.
			TypeGen tg = snippetAssembly.defineType(name+"_"+index++, typeof(FrameCode));

			tg.AddModuleField(typeof(module));

			ConstructorBuilder cb =
				tg.myType.DefineDefaultConstructor(MethodAttributes.Public);

			CodeGen cg = tg.defineMethod(
				MethodAttributes.Virtual|MethodAttributes.Public,
				"Run", typeof(object), new Type[] {typeof(Frame)});
			cg.printExprStmts = true;
			cg.names = new FrameNamespace(tg, cg);

			cg.emitArgGet(0);
			cg.emitFieldGet(typeof(Frame), "__module__");
			tg.moduleSlot.emitSet(cg);

			body.Emit(cg);
			if (!(body is ReturnStmt)) cg.emitReturn(null);

			
			// questions as to how simple this can be...
			Type ret = tg.finishType();
			//!!! appears to show bug in mono TypeBuilder.GetType
			//Console.Out.WriteLine("made it: " + ret + ", " + ret.BaseType + ", " + tg.myType.BaseType);
			FrameCode code = (FrameCode)ret.GetConstructor(new Type[0]).Invoke(new object[0]);

			return code;
		}
	}
}
