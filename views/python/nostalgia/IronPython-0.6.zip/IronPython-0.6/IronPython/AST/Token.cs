/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;

namespace IronPython.AST
{
	/// <summary>
	/// Summary description for Token.
	/// </summary>
	public abstract class Token {
		public readonly int kind;
		public Token(int kind) {
			this.kind = kind;
		}
		public virtual object getValue() {
			throw new NotSupportedException("no value for this token");
		}

		public abstract String getImage();
	}

	public class ErrorToken:Token {
		public readonly String message;
		public ErrorToken(String message):base(TokenKind.ERROR) {
			this.message = message;
		}

		public override String getImage() {
			return message;
		}

		public override object getValue() {
			return message;
		}
	}

	public class ConstantValueToken:Token {
		public readonly object value;

		public ConstantValueToken(object value):base(TokenKind.CONSTANT) {
			this.value = value;
		}

		public override object getValue() {
			return value;
		}

		public override String getImage() {
			return value.ToString();
		}
	}

	public class NameToken:Token {
		public readonly Name value;
		public NameToken(Name value):base(TokenKind.NAME) {
			this.value = value;
		}

		public override object getValue() {
			return value;
		}

		public override String getImage() {
			return value.ToString();
		}
	}

	public class OperatorToken:Token {
		public readonly Operator op;
		public OperatorToken(int kind, Operator op):base(kind) {
			this.op = op;
		}

		public override object getValue() {
			return op;
		}

		public override String getImage() {
			return op.symbol;
		}
	}

	public class SymbolToken:Token {
		public readonly String image;
		public SymbolToken(int kind, String image):base(kind) {
			this.image = image;
		}

		public override object getValue() {
			return image;
		}

		public override String getImage() {
			return image;
		}
	}
}
