/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;

namespace IronPython.AST
{
	/// <summary>
	/// Summary description for TokenKind.
	/// </summary>
	public class TokenKind
	{
		public const int EOF = -1;
		public const int ERROR = 0;
		public const int NEWLINE = 1;
		public const int INDENT = 2;
		public const int DEDENT = 3;

		public const int NAME = 8;
		public const int CONSTANT = 9;

		public static readonly Token EofToken = new SymbolToken(EOF, "<eof>");
		public static readonly Token NewlineToken = new SymbolToken(NEWLINE, "<newline>");
		public static readonly Token IndentToken = new SymbolToken(INDENT, "<indent>");
		public static readonly Token DedentToken = new SymbolToken(DEDENT, "<dedent>");

		public const int DOT = 31;
		public static readonly Token DotToken = new SymbolToken(DOT, ".");

		#region Generated Token Kinds
		public const int ADD = 32;
		public static readonly Token AddToken = new OperatorToken(ADD, Operator.AddOp);
		public const int ADD_EQ = 33;
		public static readonly Token AddEqToken = new SymbolToken(ADD_EQ, "+=");
		public const int SUB = 34;
		public static readonly Token SubToken = new OperatorToken(SUB, Operator.SubOp);
		public const int SUB_EQ = 35;
		public static readonly Token SubEqToken = new SymbolToken(SUB_EQ, "-=");
		public const int POW = 36;
		public static readonly Token PowToken = new OperatorToken(POW, Operator.PowOp);
		public const int POW_EQ = 37;
		public static readonly Token PowEqToken = new SymbolToken(POW_EQ, "**=");
		public const int MUL = 38;
		public static readonly Token MulToken = new OperatorToken(MUL, Operator.MulOp);
		public const int MUL_EQ = 39;
		public static readonly Token MulEqToken = new SymbolToken(MUL_EQ, "*=");
		public const int FLOORDIV = 40;
		public static readonly Token FloordivToken = new OperatorToken(FLOORDIV, Operator.FloordivOp);
		public const int FLOORDIV_EQ = 41;
		public static readonly Token FloordivEqToken = new SymbolToken(FLOORDIV_EQ, "//=");
		public const int DIV = 42;
		public static readonly Token DivToken = new OperatorToken(DIV, Operator.DivOp);
		public const int DIV_EQ = 43;
		public static readonly Token DivEqToken = new SymbolToken(DIV_EQ, "/=");
		public const int MOD = 44;
		public static readonly Token ModToken = new OperatorToken(MOD, Operator.ModOp);
		public const int MOD_EQ = 45;
		public static readonly Token ModEqToken = new SymbolToken(MOD_EQ, "%=");
		public const int LSHIFT = 46;
		public static readonly Token LshiftToken = new OperatorToken(LSHIFT, Operator.LshiftOp);
		public const int LSHIFT_EQ = 47;
		public static readonly Token LshiftEqToken = new SymbolToken(LSHIFT_EQ, "<<=");
		public const int RSHIFT = 48;
		public static readonly Token RshiftToken = new OperatorToken(RSHIFT, Operator.RshiftOp);
		public const int RSHIFT_EQ = 49;
		public static readonly Token RshiftEqToken = new SymbolToken(RSHIFT_EQ, ">>=");
		public const int AND = 50;
		public static readonly Token AndToken = new OperatorToken(AND, Operator.AndOp);
		public const int AND_EQ = 51;
		public static readonly Token AndEqToken = new SymbolToken(AND_EQ, "&=");
		public const int OR = 52;
		public static readonly Token OrToken = new OperatorToken(OR, Operator.OrOp);
		public const int OR_EQ = 53;
		public static readonly Token OrEqToken = new SymbolToken(OR_EQ, "|=");
		public const int XOR = 54;
		public static readonly Token XorToken = new OperatorToken(XOR, Operator.XorOp);
		public const int XOR_EQ = 55;
		public static readonly Token XorEqToken = new SymbolToken(XOR_EQ, "^=");
		public const int LT = 56;
		public static readonly Token LtToken = new OperatorToken(LT, Operator.LtOp);
		public const int GT = 57;
		public static readonly Token GtToken = new OperatorToken(GT, Operator.GtOp);
		public const int LE = 58;
		public static readonly Token LeToken = new OperatorToken(LE, Operator.LeOp);
		public const int GE = 59;
		public static readonly Token GeToken = new OperatorToken(GE, Operator.GeOp);
		public const int EQ = 60;
		public static readonly Token EqToken = new OperatorToken(EQ, Operator.EqOp);
		public const int NE = 61;
		public static readonly Token NeToken = new OperatorToken(NE, Operator.NeOp);
		public const int L_PAREN = 62;
		public static readonly Token LParenToken = new SymbolToken(L_PAREN, "(");
		public const int R_PAREN = 63;
		public static readonly Token RParenToken = new SymbolToken(R_PAREN, ")");
		public const int L_BRACKET = 64;
		public static readonly Token LBracketToken = new SymbolToken(L_BRACKET, "[");
		public const int R_BRACKET = 65;
		public static readonly Token RBracketToken = new SymbolToken(R_BRACKET, "]");
		public const int L_BRACE = 66;
		public static readonly Token LBraceToken = new SymbolToken(L_BRACE, "{");
		public const int R_BRACE = 67;
		public static readonly Token RBraceToken = new SymbolToken(R_BRACE, "}");
		public const int COMMA = 68;
		public static readonly Token CommaToken = new SymbolToken(COMMA, ",");
		public const int COLON = 69;
		public static readonly Token ColonToken = new SymbolToken(COLON, ":");
		public const int BACKQUOTE = 70;
		public static readonly Token BackquoteToken = new SymbolToken(BACKQUOTE, "`");
		public const int SEMICOLON = 71;
		public static readonly Token SemicolonToken = new SymbolToken(SEMICOLON, ";");
		public const int ASSIGN = 72;
		public static readonly Token AssignToken = new SymbolToken(ASSIGN, "=");
		public const int TWIDLE = 73;
		public static readonly Token TwidleToken = new SymbolToken(TWIDLE, "~");
		public const int LG = 74;
		public static readonly Token LgToken = new SymbolToken(LG, "<>");
		
		public const int kAND = 75;
		public static readonly Token kAndToken = new SymbolToken(kAND, "and");
		public const int kASSERT = 76;
		public static readonly Token kAssertToken = new SymbolToken(kASSERT, "assert");
		public const int kBREAK = 77;
		public static readonly Token kBreakToken = new SymbolToken(kBREAK, "break");
		public const int kCLASS = 78;
		public static readonly Token kClassToken = new SymbolToken(kCLASS, "class");
		public const int kCONTINUE = 79;
		public static readonly Token kContinueToken = new SymbolToken(kCONTINUE, "continue");
		public const int kDEF = 80;
		public static readonly Token kDefToken = new SymbolToken(kDEF, "def");
		public const int kDEL = 81;
		public static readonly Token kDelToken = new SymbolToken(kDEL, "del");
		public const int kELIF = 82;
		public static readonly Token kElifToken = new SymbolToken(kELIF, "elif");
		public const int kELSE = 83;
		public static readonly Token kElseToken = new SymbolToken(kELSE, "else");
		public const int kEXCEPT = 84;
		public static readonly Token kExceptToken = new SymbolToken(kEXCEPT, "except");
		public const int kEXEC = 85;
		public static readonly Token kExecToken = new SymbolToken(kEXEC, "exec");
		public const int kFINALLY = 86;
		public static readonly Token kFinallyToken = new SymbolToken(kFINALLY, "finally");
		public const int kFOR = 87;
		public static readonly Token kForToken = new SymbolToken(kFOR, "for");
		public const int kFROM = 88;
		public static readonly Token kFromToken = new SymbolToken(kFROM, "from");
		public const int kGLOBAL = 89;
		public static readonly Token kGlobalToken = new SymbolToken(kGLOBAL, "global");
		public const int kIF = 90;
		public static readonly Token kIfToken = new SymbolToken(kIF, "if");
		public const int kIMPORT = 91;
		public static readonly Token kImportToken = new SymbolToken(kIMPORT, "import");
		public const int kIN = 92;
		public static readonly Token kInToken = new SymbolToken(kIN, "in");
		public const int kIS = 93;
		public static readonly Token kIsToken = new SymbolToken(kIS, "is");
		public const int kLAMBDA = 94;
		public static readonly Token kLambdaToken = new SymbolToken(kLAMBDA, "lambda");
		public const int kNOT = 95;
		public static readonly Token kNotToken = new SymbolToken(kNOT, "not");
		public const int kOR = 96;
		public static readonly Token kOrToken = new SymbolToken(kOR, "or");
		public const int kPASS = 97;
		public static readonly Token kPassToken = new SymbolToken(kPASS, "pass");
		public const int kPRINT = 98;
		public static readonly Token kPrintToken = new SymbolToken(kPRINT, "print");
		public const int kRAISE = 99;
		public static readonly Token kRaiseToken = new SymbolToken(kRAISE, "raise");
		public const int kRETURN = 100;
		public static readonly Token kReturnToken = new SymbolToken(kRETURN, "return");
		public const int kTRY = 101;
		public static readonly Token kTryToken = new SymbolToken(kTRY, "try");
		public const int kWHILE = 102;
		public static readonly Token kWhileToken = new SymbolToken(kWHILE, "while");
		public const int kYIELD = 103;
		public static readonly Token kYieldToken = new SymbolToken(kYIELD, "yield");
		
		public static readonly Hashtable keywords = new Hashtable();
		static TokenKind() {
		    keywords[Name.make("and")] = kAndToken;
		    keywords[Name.make("assert")] = kAssertToken;
		    keywords[Name.make("break")] = kBreakToken;
		    keywords[Name.make("class")] = kClassToken;
		    keywords[Name.make("continue")] = kContinueToken;
		    keywords[Name.make("def")] = kDefToken;
		    keywords[Name.make("del")] = kDelToken;
		    keywords[Name.make("elif")] = kElifToken;
		    keywords[Name.make("else")] = kElseToken;
		    keywords[Name.make("except")] = kExceptToken;
		    keywords[Name.make("exec")] = kExecToken;
		    keywords[Name.make("finally")] = kFinallyToken;
		    keywords[Name.make("for")] = kForToken;
		    keywords[Name.make("from")] = kFromToken;
		    keywords[Name.make("global")] = kGlobalToken;
		    keywords[Name.make("if")] = kIfToken;
		    keywords[Name.make("import")] = kImportToken;
		    keywords[Name.make("in")] = kInToken;
		    keywords[Name.make("is")] = kIsToken;
		    keywords[Name.make("lambda")] = kLambdaToken;
		    keywords[Name.make("not")] = kNotToken;
		    keywords[Name.make("or")] = kOrToken;
		    keywords[Name.make("pass")] = kPassToken;
		    keywords[Name.make("print")] = kPrintToken;
		    keywords[Name.make("raise")] = kRaiseToken;
		    keywords[Name.make("return")] = kReturnToken;
		    keywords[Name.make("try")] = kTryToken;
		    keywords[Name.make("while")] = kWhileToken;
		    keywords[Name.make("yield")] = kYieldToken;
		}
		#endregion
	}
}
