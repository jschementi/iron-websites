/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;

using System.Reflection;
using System.Reflection.Emit;

using IronPython.Objects;

using IronMath;

namespace IronPython.AST
{
	class TailCallOpsBuilder {
		private static Type myType = null;

		public static Type GetTailCallOps(AssemblyGen ag) {
			return typeof(Ops);

//			if (myType == null) myType = MakeTailCallOps(ag);
//			return myType; //typeof(Ops);
		}


		private static Type MakeTailCallOps(AssemblyGen ag) {
			//AssemblyGen ag = SnippetMaker.snippetAssembly;

			TypeGen tg = ag.defineType("TailCallOps", typeof(object));


			CodeGen cg = tg.defineMethod("Call", typeof(object), new Type[] { typeof(object), typeof(object) });
			cg.emitArgGet(0);
			cg.ilg.Emit(OpCodes.Isinst, typeof(Function));
			Label next = cg.ilg.DefineLabel();
			cg.ilg.Emit(OpCodes.Dup);
			cg.ilg.Emit(OpCodes.Brfalse, next);
			cg.emitArgGet(1);
			cg.ilg.Emit(OpCodes.Tailcall);
			cg.emitCall(typeof(Function), "Call", Constants.makeArray(typeof(object), 1));
			cg.ilg.Emit(OpCodes.Ret);

			cg.ilg.MarkLabel(next);
			cg.ilg.Emit(OpCodes.Pop);

			cg.emitArgGet(0);
			cg.emitArgGet(1);
			cg.emitCall(typeof(Ops), "Call", Constants.makeArray(typeof(object), 2)); //!!! quick experiment
			cg.ilg.Emit(OpCodes.Ret);

			return tg.finishType();
		}
	}



	class DictBuilder {
		private static Dict alreadyMade = new Dict();

		public static DictFactory GetCustomDictFactory(Tuple keys) {
			Type ty = GetCustomDict(keys);
			return (DictFactory)Delegate.CreateDelegate(typeof(DictFactory), ty.GetMethod("Factory"));
		}


		public static Type GetCustomDict(Tuple keys) {
			Type ret = (Type)alreadyMade[keys];
			if (ret != null) return ret;

			ret = new DictBuilder(keys).MakeCustomDict();

			alreadyMade[keys] = ret;
			return ret;
		}

		private Tuple keys;
		private TypeGen tg;
		private FieldSlot[] slots;

		private DictBuilder(Tuple keys) {
			this.keys = keys;

			string name = "ReflectOps.CustomDict$" + alreadyMade.Count;

			AssemblyGen ag = SnippetMaker.snippetAssembly;

			tg = ag.defineType(name, typeof(CustomDict));
		}

		private Type MakeCustomDict() {
			slots = new FieldSlot[keys.Count];

			int i=0;
			foreach (string name in keys) {
				slots[i++] = (FieldSlot)tg.AddField(typeof(object), name);
			}

			MakeGetMethod();
			MakeSetMethod();
			MakeRawKeysMethod();

			MakeFactoryMethod();

			Type ret = tg.finishType();
			ret.GetField("RawKeysTuple").SetValue(null, keys);

			return ret;
		}

		private void MakeGetMethod() {
			CodeGen cg = tg.DefineMethodOverride(typeof(CustomDict).GetMethod("RawGet")); //(MethodAttributes.Public, "RawGet", typeof(object), new Type[] { typeof(object) });
			foreach (FieldSlot slot in slots) {
				cg.emitArgGet(0);
				cg.emitString(slot.field.Name);
				Label next = cg.ilg.DefineLabel();
				cg.ilg.Emit(OpCodes.Bne_Un, next);
				slot.emitGet(cg);
				cg.emitReturn();
				cg.ilg.MarkLabel(next);
			}
			cg.emitThis();
			cg.emitArgGet(0);
			cg.ilg.Emit(OpCodes.Call, typeof(CustomDict).GetMethod("RawGet"));
			cg.emitReturn();
			cg.finish();
		}

		private void MakeSetMethod() {
			CodeGen cg = tg.DefineMethodOverride(typeof(CustomDict).GetMethod("RawSet")); //defineMethod(MethodAttributes.Public, "RawSet", typeof(void), new Type[] { typeof(object), typeof(object) });
			foreach (FieldSlot slot in slots) {
				cg.emitArgGet(0);
				cg.emitString(slot.field.Name);
				Label next = cg.ilg.DefineLabel();
				cg.ilg.Emit(OpCodes.Bne_Un, next);
				cg.emitThis();
				cg.emitArgGet(1);
				cg.ilg.Emit(OpCodes.Stfld, slot.field);
				cg.emitReturn();
				cg.ilg.MarkLabel(next);
			}
			cg.emitThis();
			cg.emitArgGet(0);
			cg.emitArgGet(1);
			cg.ilg.Emit(OpCodes.Call, typeof(CustomDict).GetMethod("RawSet"));
			cg.emitReturn();
			cg.finish();
		}

		private void MakeRawKeysMethod() {
			FieldBuilder fb = tg.myType.DefineField("RawKeysTuple", typeof(Tuple), FieldAttributes.Public|FieldAttributes.Static);

			CodeGen cg = tg.DefineMethodOverride(typeof(CustomDict).GetMethod("RawGetKeys")); //tg.defineMethod(MethodAttributes.Public, "RawGetKeys", typeof(Tuple), Type.EmptyTypes);
			cg.emitFieldGet(fb);
			cg.emitReturn();
			cg.finish();
		}

		private void MakeFactoryMethod() {
			CodeGen cg = tg.defineMethod(MethodAttributes.Public|MethodAttributes.Static, "Factory", typeof(Dict), Type.EmptyTypes);
			cg.emitNew(tg.myType.DefineDefaultConstructor(MethodAttributes.Public));
			cg.emitReturn();
			cg.finish();
		}
	}


	class ReflectOptimizer {
		//private static int counter = 0;  //!!! this probably indicates a weak design
		private static Dict alreadyDone = new Dict();
		public static Type GenerateFunctions(ReflectedType inType) {
			string name = inType.type.FullName;
			name = name.Replace('+', '_');

			if (alreadyDone.Contains(name)) return null;
			alreadyDone[name] = inType;
			
			//Console.WriteLine("Generating for {0}", inType.type.FullName);

			name = "ReflectOpt." + name; // + '$'+counter++;
			AssemblyGen ag = SnippetMaker.snippetAssembly;

			TypeGen tg = ag.defineType(name, typeof(object));

			IDictionaryEnumerator de = inType.dict.GetEnumerator();

			while (de.MoveNext()) {
				if (de.Value is ReflectedMethod) {
					GenerateFunction(tg, (ReflectedMethod)de.Value);
				}
			}

			if (inType.init != null) GenerateFunction(tg, (ReflectedConstructor)inType.init);

			Type ret = tg.finishType();

			//if (outFileName != null) {
			//ag.myAssembly.SetEntryPoint(cg.methodBuilder);
			//			Assembly assm = ag.dumpAndLoad();
			//			ret = assm.GetType(name);

			foreach (MethodInfo mi in ret.GetMethods()) {
				if (!mi.IsStatic) continue;

				object existing = inType.dict[mi.Name];
				if (existing is BuiltinFunction) {
					((BuiltinFunction)existing).AddMethod(mi);
				} else {
					inType.dict[mi.Name] = BuiltinFunction.Make(mi); //MakeDelegate(mi);
				}
			}

			return ret;
		}


		

		//		public static object MakeDelegate(MethodInfo mi) {
		//			switch (mi.GetParameters().Length) {
		//				case 0:
		//					return new Function0(null, mi.Name, (CallTarget0)Delegate.CreateDelegate(typeof(CallTarget0), mi), null, null);
		//				case 1:
		//					return new Function1(null, mi.Name, (CallTarget1)Delegate.CreateDelegate(typeof(CallTarget1), mi), null, null);
		//				case 2:
		//					return new Function2(null, mi.Name, (CallTarget2)Delegate.CreateDelegate(typeof(CallTarget2), mi), null, null);
		//				case 3:
		//					return new Function3(null, mi.Name, (CallTarget3)Delegate.CreateDelegate(typeof(CallTarget3), mi), null, null);
		//				default:
		//					return null;
		//			}
		//		}

		private static Dict supportedValueTypes = MakeSupportedValueTypes();

		private static Dict MakeSupportedValueTypes() {
			Dict ret = (Dict)Dict.fromkeys( new Type[] { typeof(int), typeof(bool), typeof(double), typeof(char), typeof(Complex64), typeof(integer),
													 typeof(uint) } );
			return ret;
		}


		private static bool CanOptimize(MethodBase mi) {
			if (mi.GetParameters().Length > (mi.IsStatic ? 4 : 3)) return false; //??? static non-static difference here

			foreach (ParameterInfo pi in mi.GetParameters()) {
				if (pi.ParameterType.IsByRef) return false;
				if (ReflectedMethodBase.IsParamArray(pi)) return false;
				if (pi.ParameterType.IsValueType && !supportedValueTypes.Contains(pi.ParameterType)) return false;
			}
			return true;
		}

		private static bool CanOptimize(MethodBase[] infos) {
			for (int i=0; i < infos.Length; i++) {
				if (!IsParamsMethod(infos[i]) && !CanOptimize(infos[i])) return false;

				int j=0;
				for (; j < infos.Length; j++) {
					if (j == i) continue;
					if (IsParamsMethod(infos[j])) {
						if (IsParamsMethod(infos[i])) return false; //!!! more than one params method
						continue;
					}

					if (GetEffectiveArgs(infos[j]) == GetEffectiveArgs(infos[i])) {
						//Console.WriteLine("skipping {0} overloaded with {1} args", infos[i], GetEffectiveArgs(infos[i]));
						return false;
					}
				}
			}
			return true;
		}



		private static void GenerateFunction(TypeGen tg, ReflectedMethodBase meth) {
			//???if (meth is ReflectedUnboundMethod) return; //!!! important to optimize these, but they're non-trivial
			MethodBase[] infos = meth.infos;
			if (!CanOptimize(infos)) {
				//Console.WriteLine("skipping " + meth);
				return;
			}

			for (int i=0; i < infos.Length; i++) {
				if (IsParamsMethod(infos[i])) {
					GenerateParamsMethod(tg, infos[i]);
					continue;
				}

				GenerateSingleMethod(tg, infos[i]);
			}
		}
		private static bool IsStatic(MethodBase mi) {
			return mi.IsConstructor || mi.IsStatic;
		}

		private static string GetName(MethodBase mi) {
			if (mi.IsConstructor) return "MakeNew";
			else return mi.Name;
		}

		public static Type GetReturnType(MethodBase mi) {
			if (mi.IsConstructor) return mi.DeclaringType;
			else return ((MethodInfo)mi).ReturnType;
		}

		private static int GetEffectiveArgs(MethodBase mi) {
			if (IsStatic(mi)) return mi.GetParameters().Length;
			else return mi.GetParameters().Length + 1;
		}


		public static bool IsParamsMethod(MethodBase mi) {
			return mi.GetParameters().Length == 1 && ReflectedMethodBase.IsParamArray(mi.GetParameters()[0]) && IsStatic(mi) &&
				mi.GetParameters()[0].ParameterType == typeof(object[]);
		}

		public static void GenerateParamsMethod(TypeGen tg, MethodBase info) {
			CodeGen cg = tg.defineMethod(GetName(info), typeof(object), new Type[] { typeof(object[]) });

			cg.emitArgGet(0);

			if (info is MethodInfo) {
				cg.ilg.Emit(OpCodes.Call, (MethodInfo)info); //!!! explictly not making a virtual call here.emitCall(info);
			} else {
				cg.emitNew( (ConstructorInfo) info);
			}

			Type retType = GetReturnType(info);
			if (retType == typeof(void)) {
				cg.ilg.Emit(OpCodes.Ldnull);
			} else if (retType.IsValueType) {
				if (retType == typeof(int)) {
					cg.emitCall(typeof(Ops), "int2object");
				} else {
					cg.ilg.Emit(OpCodes.Box, retType);
				}
			}

			cg.emitReturn();

		}

		public static void EmitCastFromObject(CodeGen cg, Type paramType) {
			if (paramType == typeof(object)) return;

			if (paramType == typeof(void)) {
				cg.ilg.Emit(OpCodes.Pop);
			} else if (paramType == typeof(char)) {
				cg.emitCall(typeof(Ops), "object2char");
			} else if (paramType == typeof(int)) {
				cg.emitCall(typeof(Ops), "object2int");
			} else if (paramType == typeof(long)) {
				cg.emitCall(typeof(Ops), "object2long");
			} else if (paramType == typeof(double)) {
				cg.emitCall(typeof(Ops), "object2double");
			} else if (paramType == typeof(bool)) {
				cg.emitCall(typeof(Ops), "IsTrue");
			} else if (paramType == typeof(integer)) {
				cg.emitCall(typeof(Ops), "object2integer");
			} else if (paramType == typeof(Complex64)) {
				cg.emitCall(typeof(Ops), "object2Complex64");
			} else if (paramType == typeof(IEnumerator)) {
				cg.emitCall(typeof(Ops), "GetEnumerator");
			} else if (paramType.IsValueType) {
				// much too simple
				cg.ilg.Emit(OpCodes.Unbox, paramType);
				if (paramType == typeof(int)) {
					cg.ilg.Emit(OpCodes.Ldind_I4);
				} else if (paramType == typeof(double)) {
					cg.ilg.Emit(OpCodes.Ldind_R8);
				} else if (paramType == typeof(char)) {
					cg.ilg.Emit(OpCodes.Ldind_U2);
				} else if (paramType == typeof(System.Globalization.NumberStyles)) {
					cg.ilg.Emit(OpCodes.Ldind_I4);
				} else if (paramType == typeof(uint)) {
					cg.ilg.Emit(OpCodes.Ldind_U4);
				} else {
					throw new NotImplementedException();
				}
			} else {
				cg.ilg.Emit(OpCodes.Castclass, paramType);
			}
		}

		public static void EmitCastToObject(CodeGen cg, Type retType) {
			if (retType == typeof(void)) {
				cg.ilg.Emit(OpCodes.Ldnull);
			} else if (retType.IsValueType) {
				if (retType == typeof(int)) {
					cg.emitCall(typeof(Ops), "int2object");
				} else {
					cg.ilg.Emit(OpCodes.Box, retType);
				}
			}
			// otherwise it's already an object
		}


		public static void GenerateSingleMethod(TypeGen tg, MethodBase info) {
//			if (IsParamsMethod(info)) {
//				GenerateParamsMethod(tg, info);
//				return;
//			}
			//Console.WriteLine("generating: " + info.Name);

			//			string name;
			//			Type retType;
			//			bool isStatic;
			//			if (info is MethodInfo) {
			//				name = info.Name;
			//				retType = ((MethodInfo)info).ReturnType;
			//				isStatic = info.IsStatic;
			//			} else {
			//				name = "MakeNew";
			//				retType = info.DeclaringType;
			//				isStatic = true;
			//			}

			ParameterInfo[] pis = info.GetParameters();

			CodeGen cg = tg.defineMethod(GetName(info), typeof(object), Constants.makeArray(typeof(object), IsStatic(info) ? pis.Length : pis.Length+1));
			int argOffset = 0;

			//!!! rationalize all parameter conversions here and in ReflectedMethodBase

			if (!IsStatic(info)) {
				argOffset = 1;
				cg.ilg.Emit(OpCodes.Ldarg_0);
				EmitCastFromObject(cg, info.DeclaringType);

				if (info.DeclaringType.IsValueType) {
					Slot tmp = cg.getLocalTmp(info.DeclaringType);
					tmp.emitSet(cg);
					tmp.emitGetAddr(cg);
				}
			}


			for (int i=0; i < pis.Length; i++) {
				Type paramType = pis[i].ParameterType;
				cg.ilg.Emit(OpCodes.Ldarg, i+argOffset);
				EmitCastFromObject(cg, paramType);
			}

			if (info is MethodInfo) {
				cg.ilg.Emit(OpCodes.Call, (MethodInfo)info); //!!! explictly not making a virtual call here.emitCall(info);
			} else {
				cg.emitNew( (ConstructorInfo) info);
			}

			EmitCastToObject(cg, GetReturnType(info));

			cg.emitReturn();
		}


	}
}
