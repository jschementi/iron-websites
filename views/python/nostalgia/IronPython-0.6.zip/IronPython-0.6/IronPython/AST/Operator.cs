/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;

using IronPython.Objects;

namespace IronPython.AST {
	public abstract class Operator {
		#region Generated Operators
		public static readonly BinaryOperator AddOp = new BinaryOperator("+", new CallTarget2(Ops.Add), new CallTarget2(Ops.InPlaceAdd), 4);
		public static readonly BinaryOperator SubOp = new BinaryOperator("-", new CallTarget2(Ops.Subtract), new CallTarget2(Ops.InPlaceSubtract), 4);
		public static readonly BinaryOperator PowOp = new BinaryOperator("**", new CallTarget2(Ops.Power), new CallTarget2(Ops.InPlacePower), 6);
		public static readonly BinaryOperator MulOp = new BinaryOperator("*", new CallTarget2(Ops.Multiply), new CallTarget2(Ops.InPlaceMultiply), 5);
		public static readonly BinaryOperator FloordivOp = new BinaryOperator("//", new CallTarget2(Ops.FloorDivide), new CallTarget2(Ops.InPlaceFloorDivide), 5);
		public static readonly BinaryOperator DivOp = new BinaryOperator("/", new CallTarget2(Ops.Divide), new CallTarget2(Ops.InPlaceDivide), 5);
		public static readonly BinaryOperator ModOp = new BinaryOperator("%", new CallTarget2(Ops.Mod), new CallTarget2(Ops.InPlaceMod), 5);
		public static readonly BinaryOperator LshiftOp = new BinaryOperator("<<", new CallTarget2(Ops.LeftShift), new CallTarget2(Ops.InPlaceLeftShift), 3);
		public static readonly BinaryOperator RshiftOp = new BinaryOperator(">>", new CallTarget2(Ops.RightShift), new CallTarget2(Ops.InPlaceRightShift), 3);
		public static readonly BinaryOperator AndOp = new BinaryOperator("&", new CallTarget2(Ops.BitwiseAnd), new CallTarget2(Ops.InPlaceBitwiseAnd), 2);
		public static readonly BinaryOperator OrOp = new BinaryOperator("|", new CallTarget2(Ops.BitwiseOr), new CallTarget2(Ops.InPlaceBitwiseOr), 0);
		public static readonly BinaryOperator XorOp = new BinaryOperator("^", new CallTarget2(Ops.Xor), new CallTarget2(Ops.InPlaceXor), 1);
		public static readonly BinaryOperator LtOp = new BinaryOperator("<", new CallTarget2(Ops.LessThan), null, -1);
		public static readonly BinaryOperator GtOp = new BinaryOperator(">", new CallTarget2(Ops.GreaterThan), null, -1);
		public static readonly BinaryOperator LeOp = new BinaryOperator("<=", new CallTarget2(Ops.LessThanOrEqual), null, -1);
		public static readonly BinaryOperator GeOp = new BinaryOperator(">=", new CallTarget2(Ops.GreaterThanOrEqual), null, -1);
		public static readonly BinaryOperator EqOp = new BinaryOperator("==", new CallTarget2(Ops.Equal), null, -1);
		public static readonly BinaryOperator NeOp = new BinaryOperator("!=", new CallTarget2(Ops.NotEqual), null, -1);
		#endregion

		public static readonly BinaryOperator IsOp = new BinaryOperator("is", new CallTarget2(Ops.Is), null, -1);
		public static readonly BinaryOperator IsNotOp = new BinaryOperator("is not", new CallTarget2(Ops.IsNot), null, -1);
		public static readonly BinaryOperator InOp = new BinaryOperator("in", new CallTarget2(Ops.In), null, -1);
		public static readonly BinaryOperator NotInOp = new BinaryOperator("not in", new CallTarget2(Ops.NotIn), null, -1);

		public static readonly UnaryOperator PosOp = new UnaryOperator("+", new CallTarget1(Ops.Plus));
		public static readonly UnaryOperator NegOp = new UnaryOperator("-", new CallTarget1(Ops.Negate));
		public static readonly UnaryOperator InvertOp = new UnaryOperator("~", new CallTarget1(Ops.OnesComplement));
		public static readonly UnaryOperator NotOp = new UnaryOperator("not", new CallTarget1(Ops.Not));

		public readonly string symbol;
		public readonly int precedence;

		public Operator(string symbol, int precedence) {
			this.symbol = symbol;
			this.precedence = precedence;
		}
	}

	public class UnaryOperator:Operator {
		public readonly CallTarget1 target;

		public UnaryOperator(string symbol, CallTarget1 target):base(symbol, -1) {
			this.target = target;
		}

		public object Evaluate(object o) {
			return target(o);
		}
	}

	public class BinaryOperator:Operator {
		public readonly CallTarget2 target;
		public readonly CallTarget2 inPlaceTarget;

		public BinaryOperator(string symbol, CallTarget2 target, CallTarget2 inPlaceTarget, int precedence): base(symbol, precedence) {
			this.target = target;
			this.inPlaceTarget = inPlaceTarget;
		}

		public object Evaluate(object x, object y) {
			return target(x, y);
		}

		public object EvaluateInPlace(object x, object y) {
			return inPlaceTarget(x, y);
		}

		public bool isComparision() { return precedence == -1; }
	}
}
