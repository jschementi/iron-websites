/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;
using System.Collections.Specialized;

using System.Reflection;
using System.Reflection.Emit;

using System.Resources;
using System.Diagnostics;
using System.Diagnostics.SymbolStore;


using IronPython.Objects;
using IronPython.AST;


namespace IronPython.AST {
	/// <summary>
	/// Summary description for CodeGen.
	/// </summary>

	public struct ReturnBlock {
		public Slot returnValue;
		public Label returnStart;
	}

	public struct Targets {
		public readonly Label breakLabel;
		public readonly Label continueLabel;
		public readonly bool inTryBlock;
		
		public Targets(Label breakLabel, Label continueLabel, bool inTryBlock) {
			this.breakLabel = breakLabel; this.continueLabel = continueLabel;
			this.inTryBlock = inTryBlock;
		}
	}


	public class CodeGen {
		public readonly TypeGen typeGen;
		public readonly MethodBuilder methodBuilder;
		public readonly ILGenerator ilg;

		public MethodInfo methodToOverride = null;

		public Namespace names;

		private Stack targets = new Stack();
//		breakTargets = new Stack();
//		private Stack continueTargets = new Stack();

		private ArrayList freeSlots = new ArrayList(); //!!! really should be linked

		public Label[] yieldLabels;
		public bool printExprStmts = false;

		//private Slot[] parameters;

		private ReturnBlock returnBlock;

		//!!!public readonly FieldBuilder lineNum;
		//!!!public ISymbolDocumentWriter sourceFile;

		public CodeGen(TypeGen typeGen, MethodBuilder mb, ILGenerator ilg) {
			this.typeGen = typeGen;
			this.methodBuilder = mb;
			this.ilg = ilg;
		}

		public bool IsGenerator() {
			return yieldLabels != null;
		}

//
//		public Slot getParameter(int index) {
//			if (parameters == null) {
//				ParameterInfo[] parameterInfos = methodBuilder.GetParameters();
//				parameters = new Slot[parameterInfos.Length];
//				for(int i=0; i < parameterInfos.Length; i++) {
//					parameters[i] = new ArgSlot(methodBuilder.DefineParameter(
//						i+1, ParameterAttributes.None, parameterInfos[i].Name));
//				}
//			}
//			return parameters[index];
//		}

		public bool inTryBlock() {
			if (targets.Count == 0) return false;

			Targets t = (Targets)targets.Peek();
			return t.inTryBlock;
		}

		public void pushTryBlock() {
			if (targets.Count == 0) {
				targets.Push(new Targets(new Label(), new Label(), true));
			} else {
				Targets t = (Targets)targets.Peek();
				targets.Push(new Targets(t.breakLabel, t.continueLabel, true));
			}
		}


		public void pushTargets(Label breakTarget, Label continueTarget) {
			targets.Push(new Targets(breakTarget, continueTarget, inTryBlock()));
//			breakTargets.Push(breakTarget);
//			continueTargets.Push(continueTarget);
		}

		public void popTargets() {
			targets.Pop();
//			breakTargets.Pop();
//			continueTargets.Pop();
		}

		public void emitBreak() {
			Targets t = (Targets)targets.Peek();
			if (t.inTryBlock) ilg.Emit(OpCodes.Leave, t.breakLabel);
			else ilg.Emit(OpCodes.Br, t.breakLabel);
		}

		public void emitContinue() {
			Targets t = (Targets)targets.Peek();
			if (t.inTryBlock) ilg.Emit(OpCodes.Leave, t.continueLabel);
			else ilg.Emit(OpCodes.Br, t.continueLabel);

		}

//		protected void noteLine(int line) {
//			if (!topLevel) { parent.noteLine(line); return; }
//			emitInt(line);
//			ilg.Emit(OpCodes.Stsfld, lineNum);
//		}

		public void emitPosition(Node node) {
			if (node.line == -1) return;
			//ilg.EmitWriteLine("@" + node.line);
			//Console.WriteLine("position for: " + node + " at " + node.line + " in " + sourceFile);
			
			ilg.MarkSequencePoint(typeGen.myAssembly.sourceFile, node.line, 0, node.line+1, 0);

			//noteLine(node.line);
		}

		public void emitLine(int line) {
			ilg.MarkSequencePoint(typeGen.myAssembly.sourceFile, line, 0, line+1, 0);
		}


		public Slot getLocalTmp(Type type) {
			for (int i=0; i < freeSlots.Count; i++) {
				Slot slot = (Slot)freeSlots[i];
				if (slot.type == type) {
					freeSlots.RemoveAt(i);
					return slot;
				}
			}
			return new LocalSlot(ilg.DeclareLocal(type));
		}

		public void freeLocalTmp(Slot slot) {
			//!!! add assertion that its not already free
			freeSlots.Add(slot);
		}

		public void setArgs(Name[] names) {
			this.names.setArgs(names, methodBuilder);
		}

		public void emitGet(Name name) {
			Slot s = names.getSlotForGet(name);
			s.emitGet(this);
			s.emitCheck(this);
		}

		public void emitSet(Name name) {
			names.getSlotForSet(name).emitSet(this);
		}

		private void ensureReturnBlock() {
			if (returnBlock.returnValue == null) {
				returnBlock.returnValue =
					new LocalSlot(ilg.DeclareLocal(methodBuilder.ReturnType));
				returnBlock.returnStart = ilg.DefineLabel();
			}
		}

		public void finish() {
			if (returnBlock.returnValue != null) {
				ilg.MarkLabel(returnBlock.returnStart);
				returnBlock.returnValue.emitGet(this);
				ilg.Emit(OpCodes.Ret);
			}

			//!!! this is weird
			if (methodToOverride != null && methodToOverride.Name != "ToString") { // && (methodToOverride.IsAbstract)) { // || methodToOverride.IsVirtual)) {
				typeGen.myType.DefineMethodOverride(methodBuilder, methodToOverride);
			}
		}

		public void emitReturn() {
			if (inTryBlock()) {
				ensureReturnBlock();
				returnBlock.returnValue.emitSet(this);
				ilg.Emit(OpCodes.Leave, returnBlock.returnStart);
			} else {
				ilg.Emit(OpCodes.Ret);
			}
		}

		public void emitReturn(Expr expr) {
			if (yieldLabels != null) {
				emitReturnInGenerator(expr);
				return;
			}
			emitExprOrNone(expr);
			emitReturn();
		}

		public void emitReturnInGenerator(Expr expr) {
			ilg.Emit(OpCodes.Ldarg_1);
			//??? is an expr legal
			emitExprOrNone(expr);
			ilg.Emit(OpCodes.Stind_Ref);

			ilg.Emit(OpCodes.Ldc_I4_0);
			emitReturn();
		}

		public void emitYield(Expr expr, int index, Label label) {
			ilg.Emit(OpCodes.Ldarg_1);
			expr.Emit(this);
			ilg.Emit(OpCodes.Stind_Ref);

			//ilg.EmitWriteLine("yield: " + index);
			
			ilg.Emit(OpCodes.Ldarg_0);
			emitInt(index);
			emitFieldSet(typeof(Generator).GetField("location"));

			ilg.Emit(OpCodes.Ldc_I4_1);
			emitReturn();

			ilg.MarkLabel(label);
			//ilg.MarkLabel(yieldLabels[index]);
		}

		public void emitModuleInstance() {
			typeGen.moduleSlot.emitGet(this);
		}

		public void emitExprPopOrPrint() {
			if (printExprStmts) emitCall(typeof(Ops), "PrintNotNoneRepr", new Type[] { typeof(object) });
			else ilg.Emit(OpCodes.Pop);
		}

		public void emitThis() {
			ilg.Emit(OpCodes.Ldarg_0);
		}

		public void emitThisOrNull() {
			if (methodBuilder.IsStatic) ilg.Emit(OpCodes.Ldnull);
			else ilg.Emit(OpCodes.Ldarg_0);
		}

		public void emitPyNone() {
			ilg.Emit(OpCodes.Ldnull);
			//emitFieldGet(typeof(Py), "None");
		}

		public void emitExprOrNone(Expr e) {
			if (e == null) ilg.Emit(OpCodes.Ldnull);
			else e.Emit(this);
		}

		public void emitNonzero(Expr e) {
			e.Emit(this);
			emitCall(typeof(Ops), "IsTrue");
		}

		public void emitNonzero() {
			emitCall(typeof(Ops), "IsTrue");
		}

		public void emitPythonString(string s) {
			emitConstant(Ops.MakeString(s));
		}

//		public void emitPyStringArray(Name[] items) {
//			emitInt(items.Length);
//			ilg.Emit(OpCodes.Newarr, typeof(PyString));
//			for (int i = 0; i < items.Length; i++) {
//				ilg.Emit(OpCodes.Dup);
//				emitInt(i);
//				if (items[i] == null) {
//					ilg.Emit(OpCodes.Ldnull);
//				} else {
//					emitPyString(items[i].GetString());
//				}
//				ilg.Emit(OpCodes.Stelem_Ref);
//			}
//		}

//		public void emitPyObjectArray(Expr[] items) {
//			emitInt(items.Length);
//			ilg.Emit(OpCodes.Newarr, typeof(PyObject));
//			for (int i = 0; i < items.Length; i++) {
//				ilg.Emit(OpCodes.Dup);
//				emitInt(i);
//				items[i].generate(this);
//				ilg.Emit(OpCodes.Stelem_Ref);
//			}
//		}

		public void emitObjectArray(Expr[] items) {
			emitInt(items.Length);
			ilg.Emit(OpCodes.Newarr, typeof(object));
			for (int i = 0; i < items.Length; i++) {
				ilg.Emit(OpCodes.Dup);
				emitInt(i);
				items[i].Emit(this);
				ilg.Emit(OpCodes.Stelem_Ref);
			}
		}

		public void emitStringArray(string[] items) {
			emitInt(items.Length);
			ilg.Emit(OpCodes.Newarr, typeof(string));
			for (int i = 0; i < items.Length; i++) {
				ilg.Emit(OpCodes.Dup);
				emitInt(i);
				emitStringOrNull(items[i]);
				ilg.Emit(OpCodes.Stelem_Ref);
			}
		}

		public void emitArgGet(int i) {
			if (!methodBuilder.IsStatic) i += 1; // making room for this
			switch (i) {
				case 0: this.ilg.Emit(OpCodes.Ldarg_0); break;
				case 1: this.ilg.Emit(OpCodes.Ldarg_1); break;
				case 2: this.ilg.Emit(OpCodes.Ldarg_2); break;
				case 3: this.ilg.Emit(OpCodes.Ldarg_3); break;
				default:
					//!!! add short form index too
					this.ilg.Emit(OpCodes.Ldarg, i); break;
			}
		}

		public void emitInt(int i) {
			OpCode c;
			switch (i) {
				case -1: c = OpCodes.Ldc_I4_M1; break;
				case 0: c = OpCodes.Ldc_I4_0; break;
				case 1: c = OpCodes.Ldc_I4_1; break;
				case 2: c = OpCodes.Ldc_I4_2; break;
				case 3: c = OpCodes.Ldc_I4_3; break;
				case 4: c = OpCodes.Ldc_I4_4; break;
				case 5: c = OpCodes.Ldc_I4_5; break;
				case 6: c = OpCodes.Ldc_I4_6; break;
				case 7: c = OpCodes.Ldc_I4_7; break;
				case 8: c = OpCodes.Ldc_I4_8; break;
				default:
					if (i >= -128 && i <= 127) {
						ilg.Emit(OpCodes.Ldc_I4_S, i);
					} else {
						ilg.Emit(OpCodes.Ldc_I4, i);
					}
					return;
			}
			ilg.Emit(c);
		}


		public void emitFieldGet(Type tp, String name) {
			emitFieldGet(tp.GetField(name)); //, BindingFlags.NonPublic));
		}

		public void emitFieldGet(FieldInfo fi) {
			if (fi.IsStatic) {
				ilg.Emit(OpCodes.Ldsfld, fi);
			} else {
				ilg.Emit(OpCodes.Ldfld, fi);
			}
		}
		public void emitFieldSet(FieldInfo fi) {
			if (fi.IsStatic) {
				ilg.Emit(OpCodes.Stsfld, fi);
			} else {
				ilg.Emit(OpCodes.Stfld, fi);
			}
		}

		public void emitNew(ConstructorInfo ci) {
			ilg.Emit(OpCodes.Newobj, ci);
		}

//		public void emitNew(Type tp) {
//			emitCall(tp.GetMethod(name));
//		}

		public void emitNew(Type tp, Type[] paramTypes) {
			emitNew(tp.GetConstructor(paramTypes));
		}

		public void emitCall(MethodInfo mi) {
			if (mi.IsVirtual) {
				ilg.Emit(OpCodes.Callvirt, mi);
			} else {
				ilg.Emit(OpCodes.Call, mi);
			}
		}

		public void emitCall(Type tp, String name) {
			emitCall(tp.GetMethod(name));
		}

		public void emitCall(Type tp, String name, Type[] paramTypes) {
			emitCall(tp.GetMethod(name, paramTypes));
		}

		public void emitName(Name name) {
			//!!! check that this is always desired
			name = names.FixName(name);

			emitString(name.GetString());
			//emitConstant(PyString.make(name.GetString()));
		}

		public void emitString(string _value) {
			ilg.Emit(OpCodes.Ldstr, (string)_value);
		}

		public void emitStringOrNull(string _value) {
			if (_value == null) ilg.Emit(OpCodes.Ldnull);
			else emitString(_value);
		}

		public void emitConstant(object _value) {
			if (_value is string) {
				emitString((string)_value);
			} else {
				Slot s = typeGen.getOrMakeConstant(_value);
				s.emitGet(this);
			}
		}

//		public void emitConstant(PyObject _value) {
//			Slot s = typeGen.getOrMakeConstant(_value);
//			s.emitGet(this);
//		}
	}
}
