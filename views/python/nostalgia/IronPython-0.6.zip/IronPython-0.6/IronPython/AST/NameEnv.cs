/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;
using System.Collections.Specialized;

using IronPython.AST;
using IronPython.Objects;

namespace IronPython.AST {
	public class NameEnv {
		public module globals;
		private IDictionary locals;

		private HybridDictionary globalNames = new HybridDictionary();
		
		public NameEnv(module globals, IDictionary locals) {
			this.globals = globals;
			if (locals == null) locals = globals.__dict__;
			this.locals = locals;
		}

		public void MarkGlobal(string name) {
			globalNames[name] = name;
		}

		public void Set(string name, object value) {
			if (globalNames.Contains(name)) {
				globals.__setattr__(name, value);
			} else {
				locals[name] = value;
			}
		}

		public object Get(string name) {
			object ret = locals[name];
			if (ret == null) {
				return Ops.GetAttr(globals, name);
			} else {
				return ret;
			}
		}
	}
}
