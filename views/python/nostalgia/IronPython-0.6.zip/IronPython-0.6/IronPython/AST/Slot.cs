/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;

using System.Reflection;
using System.Reflection.Emit;

using IronPython.Objects;

namespace IronPython.AST
{
	public abstract class Slot {
		public abstract void emitGet(CodeGen cg);
		public abstract void emitGetAddr(CodeGen cg);

		//!!! must override at least one of these two methods or get infinite loop
		public virtual void emitSet(CodeGen cg, Slot val) {
			val.emitGet(cg);
			emitSet(cg);
		}

		public virtual void emitSet(CodeGen cg) {
			Slot val = cg.getLocalTmp(typeof(object));
			val.emitSet(cg);
			emitSet(cg, val);
			cg.freeLocalTmp(val);
		}

		//!!! consider combining with emitGet...
		public virtual void emitCheck(CodeGen cg) {
			//!!! the two lines below add a 8% overhead to pystone
			//!!! omit them when we can prove they are not needed
			//return;
			if (Options.CHECK_UNINITIALIZED) {
				cg.ilg.Emit(OpCodes.Dup);
				cg.emitCall(typeof(Ops), "CheckInitialized");
			}
		}

		public virtual Type type { get { throw new NotImplementedException("type"); } }
	}



//	public class FrameSlot:Slot {
//		public static Slot makeFrameSlot(Slot frame, int index) {
//			if (index < PyFrame.FIELD_COUNT) {
//				return new FieldSlot(frame, typeof(PyFrame).GetField("f" + index));
//			} else {
//				return new FrameSlot(frame, index);
//			}
//		}
//
//		public readonly Slot frame;
//		public readonly int index;
//
//		public FrameSlot(Slot frame, int index) {
//			this.frame = new FieldSlot(frame, typeof(PyFrame).GetField("slots"));
//			this.index = index-PyFrame.FIELD_COUNT;
//		}
//		public override void emitGet(CodeGen cg) {
//			frame.emitGet(cg);
//			cg.emitInt(index);
//			cg.ilg.Emit(OpCodes.Ldelem_Ref);
//			//cg.emitCall(typeof(PyFrame), "get");
//		}
//		public override void emitGetAddr(CodeGen cg) {
//			frame.emitGet(cg);
//			cg.emitInt(index);
//
//			cg.ilg.Emit(OpCodes.Ldelema, typeof(object));
//			//throw new NotImplementedException("get addr on frame slot");
//		}
//
//
//		public override void emitSet(CodeGen cg) {
//			frame.emitGet(cg);
//			cg.emitInt(index);
//			cg.emitCall(typeof(PyFrame), "doSet");
//		}
//
//		public override Type type { get { return typeof(object); } }
//
//		public override void emitCheck(CodeGen cg) {
//			//!!! skip check for these locals
//		}
//	}


//
//	public class SnippetSlot:Slot {
//		public readonly Slot module;
//		public readonly Slot name;
//
//		public SnippetSlot(Slot module, Slot name) {
//			this.module = module;
//			this.name = name;
//		}
//
//		public override void emitGet(CodeGen cg) {
//			module.emitGet(cg);
//			name.emitGet(cg);
//			cg.emitCall(typeof(PySnippet), "getGlobal");
//		}
//
//		public override void emitGetAddr(CodeGen cg) {
//			//???how bad is it that we can't do this???
//			throw new NotImplementedException("address of module slot");
//		}
//
//		public override void emitSet(CodeGen cg, Slot val) {
//			module.emitGet(cg);
//			name.emitGet(cg);
//			val.emitGet(cg);
//			cg.emitCall(typeof(PySnippet), "setGlobal");
//		}
//
//		public override Type type { get { return typeof(object); } }
//	}

	public class NamedFrameSlot:Slot {
		public readonly Slot frame;
		public readonly Name name;

		public NamedFrameSlot(Slot frame, Name name) {
			this.frame = frame;
			this.name = name;
		}

		public override void emitGet(CodeGen cg) {
			frame.emitGet(cg);
			cg.emitString(name.GetString());
			cg.emitCall(typeof(Frame), "GetGlobal");
		}

		public override void emitGetAddr(CodeGen cg) {
			//???how bad is it that we can't do this???
			throw new NotImplementedException("address of frame slot");
		}

		public override void emitSet(CodeGen cg, Slot val) {
			frame.emitGet(cg);
			cg.emitString(name.GetString());
			val.emitGet(cg);
			cg.emitCall(typeof(Frame), "SetGlobal");
		}

		public override Type type { get { return typeof(object); } }
	}
//
//	public class ModuleSlot:Slot {
//		public readonly Slot module;
//		public readonly Slot name;
//
//		public ModuleSlot(Slot module, Slot name) {
//			this.module = module;
//			this.name = name;
//		}
//
//		public override void emitGet(CodeGen cg) {
//			module.emitGet(cg);
//			name.emitGet(cg);
//			cg.emitCall(typeof(PyModule), "getGlobal");
//		}
//
//		public override void emitGetAddr(CodeGen cg) {
//			//???how bad is it that we can't do this???
//			throw new NotImplementedException("address of module slot");
//		}
//
//		public override void emitSet(CodeGen cg, Slot val) {
//			module.emitGet(cg);
//			name.emitGet(cg);
//			val.emitGet(cg);
//			cg.emitCall(typeof(PyModule), "setGlobal");
//		}
//
//		public override Type type { get { return typeof(object); } }
//	}

	public class StaticFieldSlot:Slot {
		public readonly FieldInfo field;

		public StaticFieldSlot(FieldInfo field) {
			this.field = field;
		}
		public override void emitGet(CodeGen cg) {
			cg.emitFieldGet(field);
		}
		public override void emitGetAddr(CodeGen cg) {
			cg.ilg.Emit(OpCodes.Ldsflda, field);
		}

		public override void emitSet(CodeGen cg) {
			cg.emitFieldSet(field);
		}

		public override Type type { get { return field.FieldType; } }
	}

	public class FieldSlot:Slot {
		public readonly Slot instance;
		public readonly FieldInfo field;

		public FieldSlot(Slot instance, FieldInfo field) {
			this.instance= instance;
			this.field = field;
		}
		public override void emitGet(CodeGen cg) {
			instance.emitGet(cg);
			cg.ilg.Emit(OpCodes.Ldfld, field);
		}
		public override void emitGetAddr(CodeGen cg) {
			instance.emitGet(cg);
			cg.ilg.Emit(OpCodes.Ldflda, field);
		}

		public override void emitSet(CodeGen cg, Slot val) {
			instance.emitGet(cg);
			val.emitGet(cg);
			cg.ilg.Emit(OpCodes.Stfld, field);
		}

		public override void emitSet(CodeGen cg) {
			Slot val = cg.getLocalTmp(field.FieldType);
			val.emitSet(cg);
			emitSet(cg, val);
			cg.freeLocalTmp(val);
		}

		public override Type type { get { return field.FieldType; } }
	}


	public class LocalSlot:Slot {
		public readonly LocalBuilder localBuilder;

		public LocalSlot(LocalBuilder localBuilder) {
			this.localBuilder = localBuilder;
		}
		public override void emitGet(CodeGen cg) {
			cg.ilg.Emit(OpCodes.Ldloc, localBuilder);
		}
		public override void emitGetAddr(CodeGen cg) {
			cg.ilg.Emit(OpCodes.Ldloca, localBuilder);
		}

		public override void emitSet(CodeGen cg) {
			cg.ilg.Emit(OpCodes.Stloc, localBuilder);
		}

		public override Type type { get { return localBuilder.LocalType; } }

		public override void emitCheck(CodeGen cg) {
			if (Options.CheckUninitializedLocals) base.emitCheck(cg);
		}

	}

	public class ArgSlot:Slot {
		public static ArgSlot make(MethodBuilder methodBuilder, int index, string name) {
			ParameterBuilder pb =
				methodBuilder.DefineParameter(index, ParameterAttributes.None, name);
			return new ArgSlot(pb);
		}

		public readonly ParameterBuilder paramBuilder;

		public ArgSlot(ParameterBuilder paramBuilder) {
			this.paramBuilder = paramBuilder;
		}
		private int index(CodeGen cg) {
			if (cg.methodBuilder.IsStatic) return paramBuilder.Position-1;
			else return paramBuilder.Position;
		}

		public override void emitGet(CodeGen cg) {
			cg.emitArgGet(paramBuilder.Position-1);
		}

		public override void emitGetAddr(CodeGen cg) {
			cg.ilg.Emit(OpCodes.Ldarga, index(cg));
		}

		public override void emitSet(CodeGen cg) {
			cg.ilg.Emit(OpCodes.Starg, index(cg));
		}

		//!!! never uninitialized (unless explictly del'd...)
		public override void emitCheck(CodeGen cg) { return; } 

		//!!! not true for non-Pythonic code
		public override Type type { get { return typeof(object); } }
	}

	public class ThisSlot:Slot {
		public readonly Type _type;

		public ThisSlot(Type type) {
			this._type = type;
		}
		public override void emitGet(CodeGen cg) {
			cg.ilg.Emit(OpCodes.Ldarg_0);
		}

		public override void emitSet(CodeGen cg) {
			cg.ilg.Emit(OpCodes.Starg, 0);
		}

		public override void emitGetAddr(CodeGen cg) {
			cg.ilg.Emit(OpCodes.Ldarga, 0);
		}

		public override Type type { get { return _type; } }
	}

	public class FrameObjectSlot:Slot {
		public readonly ArgSlot argSlot;
		public readonly Slot fieldSlot;

		public readonly CodeGen baseCodeGen;

		public FrameObjectSlot(CodeGen baseCodeGen, ArgSlot argSlot, Slot fieldSlot) {
			this.baseCodeGen = baseCodeGen;
			this.argSlot = argSlot;
			this.fieldSlot = fieldSlot;
		}

		public override void emitGet(CodeGen cg) {
			if (baseCodeGen == cg) argSlot.emitGet(cg);
			else fieldSlot.emitGet(cg);
		}

		public override void emitSet(CodeGen cg) {
			throw new NotSupportedException("setting a module slot");
		}

		public override void emitGetAddr(CodeGen cg) {
			throw new NotSupportedException("addr of a module slot");
		}

		public override Type type { get { return typeof(Frame); } }
	}

	public class ModuleSlot:Slot {
		public readonly Type _type;

		public ModuleSlot(Type type) {
			this._type = type;
		}
		public override void emitGet(CodeGen cg) {
			cg.emitModuleInstance();
		}

		public override void emitSet(CodeGen cg) {
			throw new NotSupportedException("setting a module slot");
		}

		public override void emitGetAddr(CodeGen cg) {
			throw new NotSupportedException("addr of a module slot");
		}

		public override Type type { get { return _type; } }
	}
}
