/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;

using System.Collections;
using System.Reflection;
using System.Reflection.Emit;

using IronPython.Objects;

namespace IronPython.AST
{
	[FlagsAttribute]
	public enum FuncDefFlags { None=0, ArgList, KwDict }

	/// <summary>
	/// Summary description for FuncDef.
	/// </summary>
	public class FuncDef:Stmt {
		public readonly Name name;
		public readonly Expr[] parameters;
		public readonly Expr[] defaults;
		public readonly FuncDefFlags flags;
		public readonly Stmt body;

		public int yieldCount = 0;

		public FuncDef(Name name, Expr[] parameters, Expr[] defaults, FuncDefFlags flags, Stmt body) {
			this.name = name;
			this.parameters = parameters;
			this.defaults = defaults;
			this.flags = flags;
			this.body = body;
		}


		public object MakeFunction(NameEnv env) {
			string[] names = Name.ToStrings(makeNames(parameters));
			object[] defaults = Expr.Evaluate(this.defaults, env);
			return new InterpFunction(name.GetString(), names, defaults, body, env.globals);
		}


		public override object Execute(NameEnv env) {
			env.Set(name.GetString(), MakeFunction(env));
			return NextStmt;
		}

		public override void Walk(IWalker w) {
			if (w.Walk(this)) {
				foreach (Expr e in parameters) e.Walk(w);
				foreach (Expr e in defaults) e.Walk(w);
				body.Walk(w);
			}
			w.PostWalk(this);
		}

		public override void Emit(CodeGen cg) {
			Type[] paramTypes = Constants.makeArray(typeof(object), parameters.Length);
			Name[] paramNames = makeNames(parameters);

			CodeGen impl = MakeImplMethod(cg, paramNames, paramTypes);

			Type funcType, targetType;
			if (flags != FuncDefFlags.None) {
				funcType = typeof(FunctionX); targetType = typeof(CallTargetN);
			} else {
				if (parameters.Length <= Ops.MAX_CALL_ARGS) {
					switch(parameters.Length) {
						case 0: funcType = typeof(Function0); targetType = typeof(CallTarget0); break;
						case 1: funcType = typeof(Function1); targetType = typeof(CallTarget1); break;
						case 2: funcType = typeof(Function2); targetType = typeof(CallTarget2); break;
						case 3: funcType = typeof(Function3); targetType = typeof(CallTarget3); break;
						case 4: funcType = typeof(Function4); targetType = typeof(CallTarget4); break;
						default: funcType = typeof(FunctionN); targetType = typeof(CallTargetN); break;
					}
				} else {
					funcType = typeof(FunctionN); targetType = typeof(CallTargetN); 
				}
			}
			
			cg.emitModuleInstance();

			cg.emitString(name.GetString());	
			
			//cg.emitThisOrNull();
			cg.ilg.Emit(OpCodes.Ldnull);
			cg.ilg.Emit(OpCodes.Ldftn, impl.methodBuilder); 
			cg.ilg.Emit(OpCodes.Newobj, 
				(ConstructorInfo)(targetType.GetMember(".ctor")[0]));

			// generate and store PyFunction object
			cg.emitStringArray(Name.ToStrings(paramNames));
			cg.emitObjectArray(defaults);

			if (flags != FuncDefFlags.None) {
				cg.emitInt((int)flags);

				cg.ilg.Emit(OpCodes.Newobj,
					funcType.GetConstructor(
					new Type[] {typeof(module), typeof(string), targetType, typeof(string[]), typeof(object[]), typeof(FuncDefFlags)}));

			} else {
				cg.ilg.Emit(OpCodes.Newobj,
					funcType.GetConstructor(
					new Type[] {typeof(module), typeof(string), targetType, typeof(string[]), typeof(object[])}));
			}

			// add doc string if defined
			string doc = body.GetDocString();
			if (doc != null) {
				cg.ilg.Emit(OpCodes.Dup);
				cg.emitString(doc);
				cg.emitFieldSet(typeof(Function).GetField("__doc__"));
			}

			cg.emitSet(name);
		}



		private static int index = 0;
		private CodeGen MakeImplMethod(CodeGen cg, Name[] names, Type[] types) {
			String mname = name.GetString() + "$f" + index++;

			CodeGen icg = cg.typeGen.defineMethod(mname, typeof(object),  types);
			icg.names = new LocalNamespace(cg.names, icg);
			icg.setArgs(names);

			EmitTupleParams(icg);

//			foreach (Name nm in names) {
//				icg.emitGet(nm);
//				icg.emitCall(typeof(Ops), "Print", new Type[] { typeof(object) });
//			}

			EmitBody(icg, names);

			if (parameters.Length > Ops.MAX_CALL_ARGS || flags != FuncDefFlags.None) {
				return MakeWrapperMethodN(cg, icg.methodBuilder);
			} else {
				return icg;
			}
		}

		private CodeGen MakeWrapperMethodN(CodeGen cg, MethodBuilder impl) {
			CodeGen icg = cg.typeGen.defineMethod(
				impl.Name, typeof(object),  new Type[] { typeof(object[]) });
			Slot arg = ArgSlot.make(icg.methodBuilder, 1, "args");
			
			//if (!Options.STATIC_MODULES) icg.ilg.Emit(OpCodes.Ldarg_0);

			for (int pi=0; pi < parameters.Length; pi++) {
				arg.emitGet(icg);
				icg.emitInt(pi);
				icg.ilg.Emit(OpCodes.Ldelem_Ref);
			}
			icg.emitCall(impl);
			icg.ilg.Emit(OpCodes.Ret);
			return icg;
		}

		private void EmitTupleParams(CodeGen cg) {
			for (int i=0; i < parameters.Length; i++) {
				Expr p = parameters[i];
				if (p is NameExpr) continue;

				//!!! not too clean
				cg.names.getSlotForGet(makeTupleParamName(p, i)).emitGet(cg);

				p.EmitSet(cg);
			}
		}


		private void EmitBody(CodeGen icg, Name[] names) {
			if (yieldCount > 0) {
				EmitGeneratorBody(icg, names);
			} else {
				body.Emit(icg);
				icg.emitReturn(null);
				icg.finish();
			}
		}


		private static int counter=0;
		private void EmitGeneratorBody(CodeGen cg, Name[] names) {
			// create a new generator class
			TypeGen tg = cg.typeGen.defineNestedType(name.GetString()+counter++, typeof(Generator));

			//!!!cg.emitModuleInstance();
			//!!!tg.moduleSlot.emitSet(cg);

			// create the next method
			CodeGen ncg = tg.defineMethod(
				MethodAttributes.Virtual|MethodAttributes.Public,
				"InnerNext", typeof(bool), new Type[] { Constants.typeofObjectAddr });
			
			ncg.names = new FieldNamespace(cg.names, tg, new ThisSlot(tg.myType));
			foreach (Name nm in names) { ncg.names.getSlotForSet(nm); }

			YieldTarget[] targets = YieldLabelBuilder.BuildYieldTargets(this, ncg);

			Label[] jumpTable = new Label[yieldCount];
			for (int i=0; i < yieldCount; i++) jumpTable[i] = targets[i].topBranchTarget; //ncg.ilg.DefineLabel();
			ncg.yieldLabels = jumpTable;

			ncg.pushTryBlock();
			ncg.ilg.BeginExceptionBlock();

			ncg.ilg.Emit(OpCodes.Ldarg_0);
			ncg.emitFieldGet(typeof(Generator), "location");
			ncg.ilg.Emit(OpCodes.Switch, jumpTable);
			

			// fall-through on first pass
			// yield statements will insert the needed labels after their returns
			body.Emit(ncg);

			// fall-through is almost always possible in generators, so this
			// is almost always needed
			ncg.emitReturnInGenerator(null);

			// special handling for StopIteration thrown in body
			ncg.ilg.BeginCatchBlock(typeof(PythonStopIteration));
			ncg.ilg.EndExceptionBlock();
			ncg.emitReturnInGenerator(null);
			ncg.popTargets();


			ncg.finish();

			cg.emitLine(42);  //XXX obviously bogus

			// my actual return function creates a new instance of the generator
			// and sets its state appropriately
			cg.emitNew(tg.myType.DefineDefaultConstructor(MethodAttributes.Public));
			Slot genSlot = cg.getLocalTmp(tg.myType);
			genSlot.emitSet(cg);

			foreach (Name nm in names) {
				genSlot.emitGet(cg);
				cg.emitGet(nm); // load the value
				FieldSlot fs = (FieldSlot)ncg.names.getSlotForSet(nm);
				cg.emitFieldSet(fs.field);
			}
			genSlot.emitGet(cg);
			cg.ilg.Emit(OpCodes.Ret);
		}

//		private void getFunctionTypes(int nargs, out Type funcType, out Type targetType) {
//			if (Options.FRAME_FUNCTIONS) {
//				if (flags != FuncDefFlags.None) funcType = typeof(PyFrameFunctionX);
//				else funcType = typeof(PyFrameFunction);
//				targetType = typeof(PyFrameCallTarget);
//				return;
//			}
//
//			if (flags != FuncDefFlags.None) {
//				funcType = typeof(PyFunctionX);
//				targetType = typeof(PyCallTargetN);
//				return;
//			}
//
//			switch(nargs) {
//				case 0:
//					funcType = typeof(PyFunction0);
//					targetType = typeof(PyCallTarget0);
//					break;
//				case 1:
//					funcType = typeof(PyFunction1);
//					targetType = typeof(PyCallTarget1);
//					break;
//				case 2:
//					funcType = typeof(PyFunction2);
//					targetType = typeof(PyCallTarget2);
//					break;
//				case 3:
//					funcType = typeof(PyFunction3);
//					targetType = typeof(PyCallTarget3);
//					break;
//				case 4:
//					funcType = typeof(PyFunction4);
//					targetType = typeof(PyCallTarget4);
//					break;
//				case 5:
//					funcType = typeof(PyFunction5);
//					targetType = typeof(PyCallTarget5);
//					break;
//				case 6:
//					funcType = typeof(PyFunction6);
//					targetType = typeof(PyCallTarget6);
//					break;
//				case 7:
//					funcType = typeof(PyFunction7);
//					targetType = typeof(PyCallTarget7);
//					break;
//				default:
//					funcType = typeof(PyFunctionN);
//					targetType = typeof(PyCallTargetN);
//					break;
//			}
//		}
//
//		private CodeGen makeFrameImpl(CodeGen cg, Name[] names, Type[] types) {
//			String mname = name.GetString() + "$f";
//
//			CodeGen icg = cg.typeGen.defineMethod(mname, typeof(PyObject),  new Type[] {typeof(PyFrame)});
//
//			icg.names = new FrameNamespace(cg.names, icg);
//			icg.setArgs(names);
//
//			generateTupleParams(icg);
//
//			generateBody(icg, names);
//			return icg;
//		}
//

//
//
//		private CodeGen makeImpl(CodeGen cg, Name[] names, Type[] types) {
//			if (Options.FRAME_FUNCTIONS) return makeFrameImpl(cg, names, types);
//
//			String mname = name.GetString() + "$f" + index++;
//
//			CodeGen icg = cg.typeGen.defineMethod(mname, typeof(PyObject),  types);
//			icg.names = new LocalNamespace(cg.names, icg);
//			icg.setArgs(names);
//
//			generateTupleParams(icg);
//
//			generateBody(icg, names);
//
//			if (parameters.Length > PyObject.MAX_CALL_ARGS || flags != FuncDefFlags.None) {
//				return makeMethodN(cg, icg.methodBuilder);
//			} else {
//				return icg;
//			}
//		}
//
//		private CodeGen makeMethodN(CodeGen cg, MethodBuilder impl) {
//			CodeGen icg = cg.typeGen.defineMethod(
//				impl.Name, typeof(PyObject),  new Type[] { typeof(PyObject[]) });
//			Slot arg = ArgSlot.make(icg.methodBuilder, 1, "args");
//			
//			if (!Options.STATIC_MODULES) icg.ilg.Emit(OpCodes.Ldarg_0);
//
//			for (int pi=0; pi < parameters.Length; pi++) {
//				arg.emitGet(icg);
//				icg.emitInt(pi);
//				icg.ilg.Emit(OpCodes.Ldelem_Ref);
//			}
//			icg.emitCall(impl);
//			icg.ilg.Emit(OpCodes.Ret);
//			return icg;
//		}

		private Name makeTupleParamName(Expr param, int index) {
			return Name.make("tupleArg" + index);
		}

		private Name[] makeNames(Expr[] parameters) {
			Name[] ret = new Name[parameters.Length];
			for (int i=0; i < parameters.Length; i++) {
				Expr p = parameters[i];
				NameExpr ne = p as NameExpr;
				if (ne == null) {
					ret[i] = makeTupleParamName(p, i);
				} else {
					ret[i] = ne.name;
				}
			}
			return ret;
		}
//
//		private void generateTupleParams(CodeGen cg) {
//			for (int i=0; i < parameters.Length; i++) {
//				Expr p = parameters[i];
//				if (p is NameExpr) continue;
//
//				p.emitAssign(cg, cg.names.getSlotForGet(makeTupleParamName(p, i)));
//			}
//		}
//
//		//!!!
//		public void generate(CodeGen cg) {
//			Type[] types = Constants.makeArray(typeof(PyObject), parameters.Length);
//			Name[] rawNames = makeNames(parameters);
//
//
//			// generate a new method for body
//			CodeGen impl = makeImpl(cg, rawNames, types);
//			// generate my PyCode object
//
//			if (Options.FRAME_FUNCTIONS) {
//				cg.emitModuleInstance();
//			}
//
//			cg.emitConstant(PyString.make(name.GetString()));
//
//			Type funcType, targetType;
//			getFunctionTypes(parameters.Length, out funcType, out targetType);
//
//			cg.emitThisOrNull();
//			cg.ilg.Emit(OpCodes.Ldftn, impl.methodBuilder); 
//			cg.ilg.Emit(OpCodes.Newobj, 
//				(ConstructorInfo)(targetType.GetMember(".ctor")[0]));
//
//			// generate and store PyFunction object
//
//			if (Options.FRAME_FUNCTIONS) {
////				if (impl.slots.Count > PyFrame.FIELD_COUNT) {
////					Console.WriteLine("need big slots for: " + name + ", " + impl.slots.Count);
////				}
//				cg.emitInt( ((FrameNamespace)impl.names).count); //impl.slots.Count);
//				cg.emitPyStringArray(rawNames);
//				cg.emitPyObjectArray(defaults);
//				if (flags != FuncDefFlags.None) {
//					cg.emitInt((int)flags);
//					cg.ilg.Emit(OpCodes.Newobj,
//						funcType.GetConstructor(
//						new Type[] {typeof(PyModule), typeof(PyString), targetType, typeof(int), typeof(PyString[]), typeof(PyObject[]), typeof(FuncDefFlags)}));
//				} else {
//					cg.ilg.Emit(OpCodes.Newobj,
//						funcType.GetConstructor(
//						new Type[] {typeof(PyModule), typeof(PyString), targetType, typeof(int), typeof(PyString[]), typeof(PyObject[])}));
//				}
//			} else
//			if (flags != FuncDefFlags.None) {
//				cg.emitPyStringArray(rawNames);
//				cg.emitPyObjectArray(defaults);
//				cg.emitInt((int)flags);
//				cg.ilg.Emit(OpCodes.Newobj,
//					funcType.GetConstructor(
//					new Type[] {typeof(PyString), targetType, typeof(PyString[]), typeof(PyObject[]), typeof(FuncDefFlags)}));
//
//			} else {
//				cg.emitPyStringArray(rawNames);
//				cg.emitPyObjectArray(defaults);
//				cg.ilg.Emit(OpCodes.Newobj,
//					funcType.GetConstructor(
//					new Type[] {typeof(PyString), targetType, typeof(PyString[]), typeof(PyObject[])}));
//			}
//
//			cg.emitSet(name);
//		}
//

	}

	//!!! This probably becomes a linked list in order to handle >1 surrounding try block
	public struct YieldTarget {
		public Label topBranchTarget;
		public Label innerBranchTarget;

		public YieldTarget(Label topBranchTarget) {
			this.topBranchTarget = topBranchTarget;
			innerBranchTarget = new Label();
		}

		public YieldTarget FixForTry(CodeGen cg) {
			innerBranchTarget = cg.ilg.DefineLabel();
			return this;
		}
	}



	public class YieldLabelBuilder:IWalker {
		YieldTarget[] topYields;
		Stack tryBlocks = new Stack();

		CodeGen cg;

		public static YieldTarget[] BuildYieldTargets(FuncDef func, CodeGen cg) {
			YieldLabelBuilder b = new YieldLabelBuilder();
			b.cg = cg;
			b.topYields = new YieldTarget[func.yieldCount];
			func.Walk(b);

			return b.topYields;
		}

			

		#region IWalker Members

		public bool Walk(Stmt s) {
			TryStmt ts = s as TryStmt;
			if (ts != null) {
				tryBlocks.Push(ts);
			}
			return true;
		}

		public void PostWalk(Stmt s) {
			TryStmt ts = s as TryStmt;
			if (ts != null) {
				tryBlocks.Pop();
				return;
			}
			YieldStmt ys = s as YieldStmt;
			if (ys != null) {
				topYields[ys.index] = new YieldTarget(cg.ilg.DefineLabel());
				
				if (tryBlocks.Count == 0) {
					ys.label = topYields[ys.index].topBranchTarget;
				} else if (tryBlocks.Count == 1) {
					TryStmt tb = (TryStmt)tryBlocks.Peek();
					tb.AddYieldTarget(topYields[ys.index].FixForTry(cg));
					ys.label = topYields[ys.index].innerBranchTarget;
				} else {
					throw new NotImplementedException("yield in more than one try block");
				}
			}
		}

		public bool Walk(Node n) {
			return true;
		}

		public void PostWalk(Node n) {
			// nothing to do
		}

		#endregion

	}

}
