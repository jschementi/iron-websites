/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Text;
using System.Reflection;
using System.Reflection.Emit;
using System.Collections;

using System.Diagnostics;

using IronPython.Objects;


namespace IronPython.AST
{
	/// <summary>
	/// Summary description for Stmt.
	/// </summary>
	public abstract class Stmt:Node
	{
		public static readonly object NextStmt = new object();

		public virtual object Execute(NameEnv env) {
			throw new NotImplementedException("execute: " + this);
		}

		public virtual void Emit(CodeGen cg) {
			throw new NotImplementedException("Emit: " + this);
		}

		public virtual string GetDocString() {
			return null;
		}

		public abstract void Walk(IWalker w);
	}

	public class SuiteStmt:Stmt {
		public readonly Stmt[] stmts;
		public SuiteStmt(Stmt[] stmts) {
			this.stmts = stmts;
		}

		public override object Execute(NameEnv env) {
			object ret = Stmt.NextStmt;
			foreach (Stmt stmt in stmts) {
				ret = stmt.Execute(env);
				if (ret != Stmt.NextStmt) break;
			}
			return ret;
		}

		public override void Emit(CodeGen cg) {
			foreach (Stmt stmt in stmts) {
				cg.emitPosition(stmt);
				stmt.Emit(cg);
			}
		}

		public override void Walk(IWalker w) {
			if (w.Walk(this)) {
				foreach (Stmt stmt in stmts) stmt.Walk(w);
			}
			w.PostWalk(this);
		}


		public override string GetDocString() {
			if (stmts.Length > 0 && stmts[0] is ExprStmt) {
				ExprStmt es = (ExprStmt)stmts[0];
				if (es.expr is ConstantExpr) {
					object val = ((ConstantExpr)es.expr).value;
					if (val is string) return (string)val;
					//if (val is Str) return ((Str)val).value;
				}
			}
			return null;
		}

	}

	public class IfStmt:Stmt {
		public readonly IfStmtTest[] tests;
		public readonly Stmt else_;
		public IfStmt(IfStmtTest[] tests, Stmt else_) {
			this.tests = tests; this.else_ = else_;
		}

		public override object Execute(NameEnv env) {
			foreach (IfStmtTest t in tests) {
				object val = t.test.Evaluate(env);
				if (Ops.IsTrue(val)) {
					return t.body.Execute(env);
				}
			}
			if (else_ != null) {
				return else_.Execute(env);
			}
			return NextStmt;
		}

		public override void Emit(CodeGen cg) {
			Label eoi = cg.ilg.DefineLabel();
			foreach (IfStmtTest t in tests) {
				Label next = cg.ilg.DefineLabel();
				cg.emitNonzero(t.test);
				cg.ilg.Emit(OpCodes.Brfalse, next);
				t.body.Emit(cg);
				// optimize no else case
				cg.ilg.Emit(OpCodes.Br, eoi);
				cg.ilg.MarkLabel(next);
			}
			if (else_ != null) {
				else_.Emit(cg);
			}
			cg.ilg.MarkLabel(eoi);
		}

		public override void Walk(IWalker w) {
			if (w.Walk(this)) {
				foreach (IfStmtTest t in tests) t.Walk(w);
				if (else_ != null) else_.Walk(w);
			}
			w.PostWalk(this);
		}
	}

	public class IfStmtTest:Node {
		public readonly Expr test;
		public readonly Stmt body;
		public IfStmtTest(Expr test, Stmt body) {
			this.test = test; this.body = body;
		}

		public void Walk(IWalker w) {
			if (w.Walk(this)) {
				test.Walk(w);
				body.Walk(w);
			}
			w.PostWalk(this);
		}
	}

	public class WhileStmt:Stmt {
		public readonly Expr test;
		public readonly Stmt body;
		public readonly Stmt else_;
		public WhileStmt(Expr test, Stmt body, Stmt else_) {
			this.test = test; this.body = body; this.else_ = else_;
		}

		public override object Execute(NameEnv env) {
			object ret = NextStmt;
			while (Ops.IsTrue(test.Evaluate(env))) {
				ret = body.Execute(env);
				if (ret != NextStmt) break;
			}
			return ret;
//			if (else_ != null) {
//				else_.exec(env);
//			}
		}

		public override void Emit(CodeGen cg) {
			Label eol = cg.ilg.DefineLabel();
			Label breakTarget = cg.ilg.DefineLabel();
			Label continueTarget = cg.ilg.DefineLabel();

			cg.ilg.MarkLabel(continueTarget);

			
			cg.emitNonzero(test);
			cg.ilg.Emit(OpCodes.Brfalse, eol);

			cg.pushTargets(breakTarget, continueTarget);

			body.Emit(cg);

			cg.ilg.Emit(OpCodes.Br, continueTarget);

			cg.popTargets();

			cg.ilg.MarkLabel(eol);
			if (else_ != null) {
				else_.Emit(cg);
			}
			cg.ilg.MarkLabel(breakTarget);
		}

		public override void Walk(IWalker w) {
			if (w.Walk(this)) {
				test.Walk(w);
				body.Walk(w);
				if (else_ != null) else_.Walk(w);
			}
			w.PostWalk(this);
		}

	}

	public class ForStmt:Stmt {
		public readonly Expr lhs;
		public readonly Expr list;
		public readonly Stmt body;
		public readonly Stmt else_;
		public ForStmt(Expr lhs, Expr list, Stmt body, Stmt else_) {
			this.lhs = lhs; this.list = list; 
			this.body = body; this.else_ = else_;
		}

		public override object Execute(NameEnv env) {
			object ret = Stmt.NextStmt;

			IEnumerator i = Ops.GetEnumerator(list.Evaluate(env));

			while (i.MoveNext()) {
				lhs.Assign(i.Current, env);
				ret = body.Execute(env);
				if (ret != NextStmt) return ret;
			}

			return ret;
			//			if (else_ != null) {
			//				else_.exec(env);
			//			}
		}

		private int counter = 0;
		public override void Emit(CodeGen cg) {
			Label eol = cg.ilg.DefineLabel();
			Label breakTarget = cg.ilg.DefineLabel();
			Label continueTarget = cg.ilg.DefineLabel();

			list.Emit(cg);
			cg.emitCall(typeof(Ops), "GetEnumerator");

			Slot iter;
			if (cg.IsGenerator()) {
				iter = cg.names.GetTempSlot("iter", typeof(IEnumerator)); //getSlotForSet(Name.make("iter$"+counter++));  //!!!
			} else {
				iter = cg.getLocalTmp(typeof(IEnumerator));
			}

			//!!!Slot iter = 

			iter.emitSet(cg);

			cg.ilg.MarkLabel(continueTarget);
			iter.emitGet(cg);
			cg.emitCall(typeof(IEnumerator), "MoveNext");

			cg.ilg.Emit(OpCodes.Brfalse, eol);

			cg.pushTargets(breakTarget, continueTarget);

			iter.emitGet(cg);
			cg.emitCall(typeof(IEnumerator).GetProperty("Current").GetGetMethod());
			lhs.EmitSet(cg);

			body.Emit(cg);

			cg.ilg.Emit(OpCodes.Br, continueTarget);

			cg.popTargets();

			cg.ilg.MarkLabel(eol);
			if (else_ != null) {
				else_.Emit(cg);
			}
			cg.ilg.MarkLabel(breakTarget);

			if (cg.IsGenerator()) {
				//!!! need to free my temp
			} else {
				cg.freeLocalTmp(iter);
			}
		}

		public override void Walk(IWalker w) {
			if (w.Walk(this)) {
				lhs.Walk(w);
				list.Walk(w);
				body.Walk(w);
				if (else_ != null) else_.Walk(w);
			}
			w.PostWalk(this);
		}
	}

	public class TryStmt:Stmt {
		public readonly Stmt body;
		public readonly TryStmtHandler[] handlers;
		public readonly Stmt else_;

		public ArrayList yieldTargets = new ArrayList();
		public TryStmt(Stmt body, TryStmtHandler[] handlers, Stmt else_) {
			this.body = body; this.handlers = handlers; this.else_ = else_;
		}


		public void AddYieldTarget(YieldTarget t) {
			yieldTargets.Add(t);
		}

		//!!! need to evaluate break/continue through a try block
		public override void Emit(CodeGen cg) {
			Slot choiceVar = null;
			if (yieldTargets.Count > 0) {
				Label startOfBlock = cg.ilg.DefineLabel();
				choiceVar = cg.getLocalTmp(typeof(int));
				cg.emitInt(-1);
				choiceVar.emitSet(cg);
				cg.ilg.Emit(OpCodes.Br, startOfBlock);

				int index = 0;
				foreach (YieldTarget yt in yieldTargets) {
					cg.ilg.MarkLabel(yt.topBranchTarget);
					cg.emitInt(index++);
					choiceVar.emitSet(cg);
					cg.ilg.Emit(OpCodes.Br, startOfBlock);
				}

				cg.ilg.MarkLabel(startOfBlock);
			}

			//Label end = cg.ilg.DefineLabel();
			Label afterElse = cg.ilg.DefineLabel();
			cg.pushTryBlock();
			cg.ilg.BeginExceptionBlock();

			if (yieldTargets.Count > 0) {
				int index = 0;
				foreach (YieldTarget yt in yieldTargets) {
					choiceVar.emitGet(cg);
					cg.emitInt(index++);
					cg.ilg.Emit(OpCodes.Beq, yt.innerBranchTarget);
				}
				cg.freeLocalTmp(choiceVar);
			}


			body.Emit(cg);
			cg.ilg.BeginCatchBlock(typeof(Exception));
			cg.emitCall(typeof(Ops), "ExtractException");
			Slot pyExc = cg.getLocalTmp(typeof(object));
			pyExc.emitSet(cg);
			//Slot exc = cg.genTmp(typeof(Exception), "exc");
			//exc.emitSet(cg);
			foreach (TryStmtHandler handler in handlers) {
				Label next = cg.ilg.DefineLabel();
				if (handler.test != null) {
					pyExc.emitGet(cg);
					handler.test.Emit(cg);
					cg.emitCall(typeof(Ops), "CheckException");
					cg.ilg.Emit(OpCodes.Brfalse, next);
				}

				if (handler.target != null) {
					pyExc.emitGet(cg);
					handler.target.EmitSet(cg);
				}
				handler.body.Emit(cg);
				cg.ilg.Emit(OpCodes.Leave, afterElse);
				cg.ilg.MarkLabel(next);
			}
			cg.ilg.Emit(OpCodes.Rethrow);
			cg.ilg.EndExceptionBlock();
			cg.popTargets();
			if (else_ != null) {
				else_.Emit(cg);
			}
			cg.ilg.MarkLabel(afterElse);
			cg.freeLocalTmp(pyExc);
		}

		public override void Walk(IWalker w) {
			if (w.Walk(this)) {
				body.Walk(w);
				foreach (TryStmtHandler handler in handlers) handler.Walk(w);
				if (else_ != null) else_.Walk(w);
			}
			w.PostWalk(this);
		}
	}

	public class TryStmtHandler:Node {
		public readonly Expr test, target;
		public readonly Stmt body;

		public TryStmtHandler(Expr test, Expr target, Stmt body) {
			this.test = test; this.target = target; this.body = body;
		}

		public void Walk(IWalker w) {
			if (w.Walk(this)) {
				if (test != null) test.Walk(w);
				if (target != null) target.Walk(w);
				body.Walk(w);
			}
			w.PostWalk(this);
		}
	}


	public class TryFinallyStmt:Stmt {
		public readonly Stmt body;
		public readonly Stmt finally_;
		public TryFinallyStmt(Stmt body, Stmt finally_) {
			this.body = body; this.finally_ = finally_;
		}

		public override void Emit(CodeGen cg) {
			cg.pushTryBlock();
			cg.ilg.BeginExceptionBlock();
			body.Emit(cg);
			cg.ilg.BeginFinallyBlock();
			finally_.Emit(cg);
			cg.ilg.EndExceptionBlock();
			cg.popTargets();
		}

		public override void Walk(IWalker w) {
			if (w.Walk(this)) {
				body.Walk(w);
				finally_.Walk(w);
			}
			w.PostWalk(this);
		}
	}

	public class ExprStmt:Stmt {
		public readonly Expr expr;
		public ExprStmt(Expr expr) { this.expr = expr; }

		public override object Execute(NameEnv env) {
			expr.Evaluate(env);
			//!!! print it if in the right env
			return NextStmt;
		}
 
		public override void Emit(CodeGen cg) {
			expr.Emit(cg);
			cg.ilg.Emit(OpCodes.Dup);
			cg.emitSet(Name.make("_")); //!!! should only set non-null
			cg.emitExprPopOrPrint();
		}
		public override void Walk(IWalker w) {
			if (w.Walk(this)) {
				expr.Walk(w);
			}
			w.PostWalk(this);
		}
	}

	public class AssignStmt:Stmt {
		public readonly Expr[] lhs;
		public readonly Expr rhs;
		public AssignStmt(Expr[] lhs, Expr rhs) { this.lhs = lhs; this.rhs = rhs; }

		public override object Execute(NameEnv env) {
			object v = rhs.Evaluate(env);
			foreach (Expr e in lhs) {
				e.Assign(v, env);
			}
			return NextStmt;
		}

		public override void Emit(CodeGen cg) {
			rhs.Emit(cg);
			for (int i=0; i < lhs.Length; i++) {
				if (i < lhs.Length-1) cg.ilg.Emit(OpCodes.Dup);
				lhs[i].EmitSet(cg);
			}
		}

		public override void Walk(IWalker w) {
			if (w.Walk(this)) {
				foreach (Expr e in lhs) e.Walk(w);
				rhs.Walk(w);
			}
			w.PostWalk(this);
		}

	}

	public class AugAssignStmt:Stmt {
		public readonly BinaryOperator op;
		public readonly Expr lhs;
		public readonly Expr rhs;
		public AugAssignStmt(BinaryOperator op, Expr lhs, Expr rhs) {
			this.op = op; this.lhs = lhs; this.rhs = rhs;
		}

		public override void Emit(CodeGen cg) {
			lhs.Emit(cg);  //!!! this doesn't work right for [] or .
			rhs.Emit(cg);

			cg.emitCall(op.inPlaceTarget.Method);
			lhs.EmitSet(cg);
		}

		public override void Walk(IWalker w) {
			if (w.Walk(this)) {
				lhs.Walk(w);
				rhs.Walk(w);
			}
			w.PostWalk(this);
		}

	}


	public class PrintStmt:Stmt {
		public readonly Expr dest;
		public readonly Expr[] exprs;
		public readonly bool trailingComma;
		public PrintStmt(Expr dest, Expr[] exprs, bool trailingComma) {
			this.dest = dest; this.exprs = exprs;
			this.trailingComma = trailingComma;
		}
			
		public override object Execute(NameEnv env) {
			Console.Out.Write("print> ");
			foreach (Expr e in exprs) {
				object val = e.Evaluate(env);
				Ops.PrintComma(val);
			}
			if (!trailingComma) Ops.PrintNewline();

			return NextStmt;
		}

		public override void Emit(CodeGen cg) {
			string suffix = "";
			if (dest != null) suffix = "WithDest";
			if (exprs.Length == 0) {
				if (dest != null) dest.Emit(cg);
				cg.emitCall(typeof(Ops), "PrintNewline" + suffix);
			}

			for (int i=0; i < exprs.Length; i++) {
				if (dest != null) dest.Emit(cg); //!!! need to put in a temp
				exprs[i].Emit(cg);
				if (i < exprs.Length-1 || trailingComma) cg.emitCall(typeof(Ops), "PrintComma"+suffix);
				else cg.emitCall(typeof(Ops), "Print"+suffix);
			}
		}
		public override void Walk(IWalker w) {
			if (w.Walk(this)) {
				if (dest != null) dest.Walk(w);
				foreach (Expr e in exprs) e.Walk(w);
			}
			w.PostWalk(this);
		}
	}

	public class DottedName:Node {
		public readonly Name[] names;
		public DottedName(Name[] names) { this.names = names; }

		public string MakeString() {
			StringBuilder ret = new StringBuilder(names[0].GetString());
			for (int i=1; i < names.Length; i++) {
				ret.Append('.');
				ret.Append(names[i].GetString());
			}
			return ret.ToString();
		}
	}


	public class ImportStmt:Stmt {
		public readonly DottedName[] names;
		public readonly Name[] asNames;
		public ImportStmt(DottedName[] names, Name[] asNames) {
			this.names = names;
			this.asNames = asNames;
		}

		public override void Emit(CodeGen cg) {
			for (int i=0; i < names.Length; i++) {
				DottedName name = names[i];
				cg.emitModuleInstance();
				cg.emitString(name.MakeString());
				if (asNames[i] == null) {
					cg.emitCall(typeof(Ops), "Import");
				} else {
					cg.emitString(asNames[i].GetString());
					cg.emitCall(typeof(Ops), "ImportAs");
				}
			}
		}

		public override void Walk(IWalker w) {
			w.Walk(this);
			w.PostWalk(this);
		}
	}

	public class FromImportStmt:Stmt {
		public static readonly Name[] STAR = new Name[1];

		public readonly DottedName root;
		public readonly Name[] names;
		public readonly Name[] asNames;
		public FromImportStmt(DottedName root, Name[] names, Name[] asNames) {
			this.root = root;
			this.names = names;
			this.asNames = asNames;
		}


		public override object Execute(NameEnv env) {
			Ops.ImportFrom(env.globals, root.MakeString(), Name.ToStrings(names));

			return NextStmt;
		}

		public override void Emit(CodeGen cg) {
			cg.emitModuleInstance();
			cg.emitString(root.MakeString());
			if (names == STAR) {
				cg.emitCall(typeof(Ops), "ImportStar"); //!!! this is tricky
			} else {
				cg.emitStringArray(Name.ToStrings(names));
				//!!! support the typical case of no asNames
				if (asNames != null) {
					cg.emitStringArray(Name.ToStrings(asNames));
					cg.emitCall(typeof(Ops), "ImportFromAs");
				} else {
					cg.emitCall(typeof(Ops), "ImportFrom");
				}
			}
		}

		public override void Walk(IWalker w) {
			w.Walk(this);
			w.PostWalk(this);
		}
	}

	public class GlobalStmt:Stmt {
		public readonly Name[] names;
		public GlobalStmt(Name[] names) {
			this.names = names;
		}

		public override object Execute(NameEnv env) {
			foreach (Name name in names) env.MarkGlobal(name.GetString());

			return NextStmt;
		}

		public override void Emit(CodeGen cg) {
			foreach (Name name in names) cg.names.markGlobal(name);
		}

		public override void Walk(IWalker w) {
			w.Walk(this);
			w.PostWalk(this);
		}
	}

	public class DelStmt:Stmt {
		public readonly Expr[] exprs;
		public DelStmt(Expr[] exprs) {
			this.exprs = exprs;
		}

		public override void Emit(CodeGen cg) {
			foreach (Expr expr in exprs) {
				expr.EmitDel(cg);
			}
		}

		public override void Walk(IWalker w) {
			if (w.Walk(this)) {
				foreach (Expr e in exprs) e.Walk(w);
			}
			w.PostWalk(this);
		}
	}

	public class RaiseStmt:Stmt {
		public readonly Expr type, _value, traceback;
		public RaiseStmt(Expr type, Expr _value, Expr traceback) {
			this.type = type; this._value = _value; this.traceback = traceback;
		}

		public override void Emit(CodeGen cg) {
			if (type == null && _value == null && traceback == null) {
				cg.emitCall(typeof(Ops), "Raise", Type.EmptyTypes);
				return;
			} else {
				cg.emitExprOrNone(type);
				cg.emitExprOrNone(_value);
				cg.emitExprOrNone(traceback);
				cg.emitCall(typeof(Ops), "Raise", new Type[] {typeof(object), typeof(object), typeof(object)});
			}
		}
		public override void Walk(IWalker w) {
			if (w.Walk(this)) {
				if (type != null) type.Walk(w);
				if (_value != null) _value.Walk(w);
				if (traceback != null) traceback.Walk(w);
			}
			w.PostWalk(this);
		}

	}

	public class AssertStmt:Stmt {
		public readonly Expr test, message;
		public AssertStmt(Expr test, Expr message) {
			this.test = test;
			this.message = message;
		}

//		public override void generate(CodeGen cg) {
//			//!!! check for optimize mode and eliminate tests
//			cg.emitNonzero(test);
//			Label end = cg.ilg.DefineLabel();
//			cg.ilg.Emit(OpCodes.Brtrue, end);
//			cg.emitExprOrNone(message);
//			cg.emitCall(typeof(Py), "AssertionError", new Type[] { typeof(PyObject) });
//			cg.ilg.Emit(OpCodes.Throw);
//			cg.ilg.MarkLabel(end);
//		}

		public override void Walk(IWalker w) {
			if (w.Walk(this)) {
				test.Walk(w);
				if (message != null) message.Walk(w);
			}
			w.PostWalk(this);
		}
	}

	public class ExecStmt:Stmt {
		public readonly Expr code, locals, globals;
		public ExecStmt(Expr code, Expr locals, Expr globals) {
			this.code = code;
			this.locals = locals;
			this.globals = globals;
		}

		public override void Emit(CodeGen cg) {
			code.Emit(cg);
			if (locals == null) {
				cg.emitModuleInstance();
				cg.emitCall(typeof(Ops), "Exec", new Type[] { typeof(object), typeof(module) });
			} else if (globals == null) {
				locals.Emit(cg);
				cg.emitCall(typeof(Ops), "Exec", new Type[] { typeof(object), typeof(object) });
			} else {
				locals.Emit(cg);
				globals.Emit(cg);
				cg.emitCall(typeof(Ops), "Exec", new Type[] { typeof(object), typeof(object), typeof(object) });
			}			
		}

		public override void Walk(IWalker w) {
			if (w.Walk(this)) {
				code.Walk(w);
				if (locals != null) locals.Walk(w);
				if (globals != null) globals.Walk(w);
			}
			w.PostWalk(this);
		}

	}

	public class ReturnStmt:Stmt {
		public readonly Expr expr;
		public ReturnStmt(Expr expr) {
			this.expr = expr;
		}

		public override object Execute(NameEnv env) {
			return expr.Evaluate(env);
		}

		public override void Emit(CodeGen cg) {
			cg.emitReturn(expr);
		}

		public override void Walk(IWalker w) {
			if (w.Walk(this)) {
				if (expr != null) expr.Walk(w);
			}
			w.PostWalk(this);
		}
	}

	public class YieldStmt:Stmt {
		public readonly Expr expr;
		public readonly int index;
		public Label label;
		public YieldStmt(Expr expr, int index) {
			this.expr = expr;
			this.index = index;
		}


		public override void Emit(CodeGen cg) {
			cg.emitYield(expr, index, label);
		}

		public override void Walk(IWalker w) {
			if (w.Walk(this)) {
				expr.Walk(w);
			}
			w.PostWalk(this);
		}
	}


	public class PassStmt:Stmt {
		public PassStmt() { }

		public override object Execute(NameEnv env) {
			return NextStmt;
		}

		public override void Emit(CodeGen cg) {
			// do nothing
		}

		public override void Walk(IWalker w) {
			if (w.Walk(this)) {
				;
			}
			w.PostWalk(this);
		}

	}
	public class BreakStmt:Stmt {
		public BreakStmt() { }

		public override void Emit(CodeGen cg) {
			cg.emitBreak();
		}

		public override void Walk(IWalker w) {
			if (w.Walk(this)) {
				;
			}
			w.PostWalk(this);
		}

	}
	public class ContinueStmt:Stmt {
		public ContinueStmt() { }

		public override void Emit(CodeGen cg) {
			cg.emitContinue();
		}

		public override void Walk(IWalker w) {
			if (w.Walk(this)) {
				;
			}
			w.PostWalk(this);
		}
	}

	//!!! Expect to expand this to a "proper" visitor when there's more than one client
	public interface IWalker {
		bool Walk(Stmt s);
		void PostWalk(Stmt s);

		bool Walk(Node n);
		void PostWalk(Node n);
	}
}
