/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Reflection;
using System.Reflection.Emit;
using System.Collections;
using System.Collections.Specialized;

using IronPython.Objects;

namespace IronPython.AST
{
	/// <summary>
	/// Summary description for ClassDef.
	/// </summary>
	public class ClassDef:Stmt {
		public readonly Name name;
		public readonly Expr[] bases;
		public readonly Stmt body;
		public ClassDef(Name name, Expr[] bases, Stmt body) {
			this.name = name;
			this.bases = bases;
			this.body = body;
		}

		private static int index = 0;
		public override void Emit(CodeGen cg) {
			// a method to generate the body of the class
			CodeGen icg = cg.typeGen.defineMethod(
				name.GetString() + "$maker" + index++,
				typeof(IDictionary), new Type[0]);

			icg.names = new LocalNamespace(cg.names, icg);
			icg.names.privatePrefix = name.GetString(); //??? this is a bit of a hack

			body.Emit(icg);
			icg.names.emitLocalsDict(icg);
			icg.ilg.Emit(OpCodes.Ret);

			// Make the actual class
			//cg.emitModuleInstance();
			cg.emitGet(Name.make("__name__")); //!!! doesn't handle undefined __name__ correctly
			cg.ilg.Emit(OpCodes.Castclass, typeof(string));

			cg.emitString(name.GetString());

			cg.emitObjectArray(bases);
			cg.emitCall(typeof(Ops), "MakeTuple");
			cg.emitCall(icg.methodBuilder);

			cg.emitCall(typeof(Ops), "MakeClass");
//			cg.ilg.Emit(OpCodes.Newobj, typeof(PyClass).GetConstructor(
//				new Type[] {typeof(PyString), typeof(PyTuple), typeof(PyDictionary)}));

			//!!!
//			if (name.GetString() == "Record") {
//				cg.ilg.Emit(OpCodes.Pop);
//				cg.emitNew(typeof(RecordClass).GetConstructor(Type.EmptyTypes));
//			}

			//!!!!!! This is a total hack to ignore nested functions for a little longer
			if (cg.names.parent != null) {
				cg.names.markGlobal(name);
			}
			cg.emitSet(name);
		}

		public override void Walk(IWalker w) {
			if (w.Walk(this)) {
				foreach (Expr e in bases) e.Walk(w);
				body.Walk(w);
			}
			w.PostWalk(this);
		}
	}
}
