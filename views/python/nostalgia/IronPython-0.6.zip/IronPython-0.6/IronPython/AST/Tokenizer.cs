/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using IronPython.Objects;

namespace IronPython.AST
{
	/// <summary>
	/// Summary description for Tokenizer.
	/// </summary>
	public class Tokenizer {
		private readonly char[] data;
		private readonly int length;
		private int index;

		private const int EOF = -1;
		private const int NONE = -2;

		// token positions
		public int start, end;
		public int line=1;

		// indentation state
		private const int MAX_INDENT = 80;
		private int[] indent = new int[MAX_INDENT];
		private int indentLevel = 0;
		private int pendingDedents = 0;
		private int pendingNewlines = 1;

		// grouping state
		private int parenLevel=0, braceLevel=0, bracketLevel=0;

		public Tokenizer(char[] data) {
			this.data = data;
			this.length = data.Length;
			this.index = 0;
		}

		protected bool nextChar(int ch) {
			if (peekChar() == ch) {
				nextChar();
				return true;
			} 
			else {
				return false;
			}
		}

		protected int nextChar() {
			if (index < length) {
				int ret = data[index++];
				if (ret == '\n') {
					line++;
				} else if (ret == '\r') {
					if (peekChar() == '\n') {
						nextChar();
					} else {
						line++;
					}
					ret = '\n';
				}
				return ret;
			} else {
				index++;
				return EOF;
			}
		}

		protected int peekChar() {
			if (index < length) return data[index];
			else return EOF;
		}

		protected void backup() {
			index--;
			if (peekChar() == '\n') {
				line--;
				if (data[index-1] == '\r') index--;
			} else if (peekChar() == '\r') {
				line--;
			}
		}

		protected String getImage() {
			return new String(data, start, end-start);
		}

		public Token next() 
		{
			if (pendingDedents != 0) {
				if (pendingDedents == -1) {
					pendingDedents = 0;
					return TokenKind.IndentToken;
				} else {
					pendingDedents--;
					return TokenKind.DedentToken;
				}
			}
			while (true) 
			{
				this.start = index; //??? is this a performance issue ???
				int ch = nextChar();
				switch(ch) 
				{
					case EOF:
						setEnd();
						if (pendingNewlines-- > 0) return TokenKind.NewlineToken;
						else return TokenKind.EofToken;
					case ' ': case '\t': case '\f':
						// see readNewline for indentation handling
						continue;
					case '#':
						// do single-line comment
						return readEolComment();

					case '\\':
						if (peekChar() == '\n' || peekChar() == '\r') {
							nextChar();
							return next();
						} else {
							return badChar(ch);
						}
					case '\n':
						setPosition(1);
						return readNewline();
//					case '\r':
//						setPosition(1);
//						nextChar('\n');  // consume \n as well if present
//						return readNewline();
					case '\"': case '\'':
						return readString((char)ch, false, false);
					case 'u': case 'U':
						if (nextChar('\"')) return readString('\"', false, true);
						if (nextChar('\'')) return readString('\'', false, true);
						if (nextChar('r') || nextChar('R')) {
							if (nextChar('\"')) return readString('\"', true, true);
							if (nextChar('\'')) return readString('\'', true, true);
							backup();
						}
						return readName((char)ch);
					case 'r': case 'R':
						if (nextChar('\"')) return readString('\"', true, false);
						if (nextChar('\'')) return readString('\'', true, false);
						return readName((char)ch);
					case '.':
						if (isDigit(peekChar())) {
							return readFloatPostDot();
						} else {
							setEnd();
							return TokenKind.DotToken;
						}

					#region Generated Tokenize Ops
					case '+':
						if (nextChar('=')) {
							setEnd(); return TokenKind.AddEqToken;
						}
						setEnd(); return TokenKind.AddToken;
					case '-':
						if (nextChar('=')) {
							setEnd(); return TokenKind.SubEqToken;
						}
						setEnd(); return TokenKind.SubToken;
					case '*':
						if (nextChar('*')) {
							if (nextChar('=')) {
								setEnd(); return TokenKind.PowEqToken;
							}
							setEnd(); return TokenKind.PowToken;
						}
						if (nextChar('=')) {
							setEnd(); return TokenKind.MulEqToken;
						}
						setEnd(); return TokenKind.MulToken;
					case '/':
						if (nextChar('=')) {
							setEnd(); return TokenKind.DivEqToken;
						}
						if (nextChar('/')) {
							if (nextChar('=')) {
								setEnd(); return TokenKind.FloordivEqToken;
							}
							setEnd(); return TokenKind.FloordivToken;
						}
						setEnd(); return TokenKind.DivToken;
					case '%':
						if (nextChar('=')) {
							setEnd(); return TokenKind.ModEqToken;
						}
						setEnd(); return TokenKind.ModToken;
					case '<':
						if (nextChar('=')) {
							setEnd(); return TokenKind.LeToken;
						}
						if (nextChar('<')) {
							if (nextChar('=')) {
								setEnd(); return TokenKind.LshiftEqToken;
							}
							setEnd(); return TokenKind.LshiftToken;
						}
						if (nextChar('>')) {
							setEnd(); return TokenKind.LgToken;
						}
						setEnd(); return TokenKind.LtToken;
					case '>':
						if (nextChar('=')) {
							setEnd(); return TokenKind.GeToken;
						}
						if (nextChar('>')) {
							if (nextChar('=')) {
								setEnd(); return TokenKind.RshiftEqToken;
							}
							setEnd(); return TokenKind.RshiftToken;
						}
						setEnd(); return TokenKind.GtToken;
					case '&':
						if (nextChar('=')) {
							setEnd(); return TokenKind.AndEqToken;
						}
						setEnd(); return TokenKind.AndToken;
					case '|':
						if (nextChar('=')) {
							setEnd(); return TokenKind.OrEqToken;
						}
						setEnd(); return TokenKind.OrToken;
					case '^':
						if (nextChar('=')) {
							setEnd(); return TokenKind.XorEqToken;
						}
						setEnd(); return TokenKind.XorToken;
					case '=':
						if (nextChar('=')) {
							setEnd(); return TokenKind.EqToken;
						}
						setEnd(); return TokenKind.AssignToken;
					case '!':
						if (nextChar('=')) {
							setEnd(); return TokenKind.NeToken;
						}
						return badChar(nextChar());
					case '(':
						parenLevel++;
						setEnd(); return TokenKind.LParenToken;
					case ')':
						parenLevel--;
						setEnd(); return TokenKind.RParenToken;
					case '[':
						bracketLevel++;
						setEnd(); return TokenKind.LBracketToken;
					case ']':
						bracketLevel--;
						setEnd(); return TokenKind.RBracketToken;
					case '{':
						braceLevel++;
						setEnd(); return TokenKind.LBraceToken;
					case '}':
						braceLevel--;
						setEnd(); return TokenKind.RBraceToken;
					case ',':
						setEnd(); return TokenKind.CommaToken;
					case ':':
						setEnd(); return TokenKind.ColonToken;
					case '`':
						setEnd(); return TokenKind.BackquoteToken;
					case ';':
						setEnd(); return TokenKind.SemicolonToken;
					case '~':
						setEnd(); return TokenKind.TwidleToken;
					#endregion

					//NUMBERS
					case '0': case '1': case '2': case '3': case '4':
					case '5': case '6': case '7': case '8': case '9':
						return readNumber((char)ch);

					case '_': return readName('_');

					default:
						if (isNameStart(ch)) return readName((char)ch);
						return badChar(ch);
				}
			}
		}

		private ErrorToken badChar(int ch) {
			setEnd();
			return new ErrorToken("bad character '" + (char)ch + "'");
		}

		private bool isNameStart(int ch) {
			return (ch >= 'a' && ch <= 'z') || 
				(ch >= 'A' && ch <= 'Z') ||
				ch == '_';
		}
		private bool isNamePart(int ch) {
			return (ch >= 'a' && ch <= 'z') || 
				(ch >= 'A' && ch <= 'Z') ||
				(ch == '_') ||
				(ch >= '0' && ch <= '9');
		}

		private bool isDigit(int ch) {
			return (ch >= '0' && ch <= '9');
		}

		private Token readString(char quoteChar, bool isRaw, bool isUnicode) {
			// find out if this is a single or triple
			bool isTriple = false;
			if (nextChar(quoteChar)) {
				if (nextChar(quoteChar)) isTriple = true;
				else backup();
			}

			while (true) {
				int ch = nextChar();
				if (ch == quoteChar) {
					if (isTriple) {
						if (nextChar(ch) && nextChar(ch)) break;
					} else {
						break;
					}
				} else if (ch == '\\') {
					if (!nextChar('\\')) nextChar(quoteChar); // skip a possible quote
				} else if (!isTriple && (ch == '\n' || ch == '\r')) {
					setEnd();
					return new ErrorToken("NEWLINE in single-quoted string");
				}
			}
			setEnd();
			String contents;
			int start = this.start;
			if (isRaw) start += 1;
			if (isUnicode) start += 1;
			if (isTriple) {
				contents = new String(data, start+3, end-start-6);
				contents = contents.Replace("\r\n", "\n"); //!!! partially right, Mac is still ToDo
			} else {
				contents =  new String(data, start+1, end-start-2);
			}
			return new ConstantValueToken(LiteralParser.ParseString(contents, isRaw)); 
		}

		private Token readNumber(char start) {
			int b = 10;
			if (start == '0') {
				if (nextChar('x') || nextChar('X')) {
					return readHexNumber();
				}
				b = 8;
			}
			while (true) {
				int ch = nextChar();
				switch(ch) {
					case '0': case '1': case '2': case '3': case '4':
					case '5': case '6': case '7': case '8': case '9':
						continue;
					case '.': return readFloatPostDot();
					case 'e': case 'E':
						return readFloatPostE();
					case 'j': case 'J':
						setEnd();
						return new ConstantValueToken(LiteralParser.ParseImaginary(getImage()));
					case 'l': case 'L':
						setEnd();
						return new ConstantValueToken(LiteralParser.ParseBigIntegerForL(getImage(), b));
					default:
						backup();
						setEnd();
						return new ConstantValueToken(LiteralParser.ParseInteger(getImage(), b));
				}
			}
		}

		private Token readHexNumber() {
			while (true) {
				int ch = nextChar();
				string s;
				switch(ch) {
					case '0': case '1': case '2': case '3': case '4':
					case '5': case '6': case '7': case '8': case '9':
					case 'a': case 'b': case 'c': case 'd': case 'e': case 'f':
					case 'A': case 'B': case 'C': case 'D': case 'E': case 'F':
						continue;
					case 'l': case 'L':
						setEnd();
						s = getImage();
						s = s.Substring(2, s.Length-3);
						return new ConstantValueToken(LiteralParser.ParseBigIntegerForL(s, 16));
					default:
						backup();
						setEnd();
						s = getImage();
						s = s.Substring(2, s.Length-2);
						return new ConstantValueToken(LiteralParser.ParseInteger(s, 16));
				}
			}
		}

		private Token readFloatPostDot() {
			while (true) {
				int ch = nextChar();
				switch(ch) {
					case '0': case '1': case '2': case '3': case '4':
					case '5': case '6': case '7': case '8': case '9':
						continue;
					case 'e': case 'E':
						return readFloatPostE();
					case 'j': case 'J':
						setEnd();
						return new ConstantValueToken(LiteralParser.ParseImaginary(getImage()));
					default:
						backup();
						setEnd();
						return new ConstantValueToken(LiteralParser.ParseFloat(getImage()));
				}
			}
		}

		private Token readFloatPostE() {
			while (true) {
				int ch = nextChar();
				switch(ch) {
					case '-': continue;

					case '0': case '1': case '2': case '3': case '4':
					case '5': case '6': case '7': case '8': case '9':
						continue;
					case 'j': case 'J':
						setEnd();
						return new ConstantValueToken(LiteralParser.ParseImaginary(getImage()));
					default:
						backup();
						setEnd();
						return new ConstantValueToken(LiteralParser.ParseFloat(getImage()));
				}
			}
		}

		private Token readName(char first) {
			int ch = nextChar();
			while (isNamePart(ch)) {
				ch = nextChar();
			}
			backup();
			setEnd();
			Name name = Name.make(this.data, start, end);
//			Console.WriteLine("name: " + name);
//			foreach (Name n in TokenKind.keywords.Keys) {
//				Console.WriteLine("    " + n + ", " + (n == name));
//			}
			Token ret = (Token)TokenKind.keywords[name];
			if (ret == null) return new NameToken(name);
			else return ret;
		}

		private void setEnd() {
			end = index;
		}

		private void setPosition(int len) {
			start = index-len;
			end = index;
		}

		private bool inGrouping() {
			return parenLevel != 0 || braceLevel != 0 || bracketLevel != 0;
		}

		private void setIndent(int spaces) {
			int current = indent[indentLevel];
			if (spaces == current) {
				return;
			} else if (spaces > current) {
				indent[++indentLevel] = spaces;
				pendingDedents = -1;
				return;
			} else {
				while (spaces < current) {
					indentLevel-=1;
					pendingDedents+=1;
					current = indent[indentLevel];
				}
				if (spaces != current) {
					// get me an error message
				}
			}
		}

		private Token readNewline() {
			int spaces = 0;
			while (true) {
				int ch = nextChar();
				switch(ch) {
					case ' ': spaces += 1; continue;
					case '\t': spaces += 8; continue;
					case '\f': spaces += 1; continue;
					case '\n': /*case '\r': line++;*/ setPosition(1); spaces = 0; continue;
					case '#': readToEol(); setPosition(1); spaces = 0; continue;
					default:
						if (inGrouping()) {
							backup();
							return next();
						} else {
							setIndent(spaces);
							backup();
							return TokenKind.NewlineToken;
						}
				}
			}
		}

		private void readToEol() {
			while (true) {
				int ch = nextChar();
				switch(ch) {
					case '\n': case EOF: return;
				}
			}
		}

		private Token readEolComment() {
			while (true) {
				int ch = nextChar();
				switch(ch) {
					case '\n': this.end = index; return readNewline();
					//case '\r': nextChar('\n'); line++; this.end = index; return readNewline();
					case EOF: this.end = index-1; return TokenKind.EofToken;
				}
			}
		}

	}
}
