/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;

namespace IronPython.AST
{
	/// <summary>
	/// Summary description for Name.
	/// </summary>
	public class Name
	{
		public static Name make(String source) {
			return make(source.ToCharArray(), 0, source.Length);
		}

		public static string[] ToStrings(Name[] names) {
			string[] ret = new string[names.Length];
			for (int i=0; i < names.Length; i++) {
				if (names[i] == null) ret[i] = null;
				else ret[i] = names[i].GetString();
			}
			return ret;
		}

		public static Name make(char[] source, int start, int end) {
			NameKey key = new NameKey(source, start, end);
			Name ret = (Name)names[key];
			if (ret == null) {
				ret = key.makeName();
				key = new NameKey(ret.name, 0, ret.name.Length);
				names[key] = ret;
			}
			return ret;
		}

		private static int hash(char[] source, int start, int end) {
			int ret = 0;
			for (int i=start; i < end; i++) {
				ret = 31*ret + source[i];
			}
			return ret;
		}

		private static Hashtable names = new Hashtable();

		// in the current design, these will hold on the too much text
		private class NameKey {
			private char[] name;
			private int start, end, length;
			private int hashcode;
			public NameKey(char[] name, int start, int end) {
				this.name = name;
				this.start = start;
				this.end = end;
				this.length = end-start;
				this.hashcode = hash(name, start, end);
			}

			public Name makeName() {
				char[] chs = new char[length];
				for (int i=chs.Length-1, j=end-1; i >= 0; i--, j--) {
					chs[i] = name[j];
				}
				// need to truncate name here...
				return new Name(chs, hashcode);
			}

			public override int GetHashCode() {
				return hashcode;
			}

			public override bool Equals(object other) {
				NameKey okey = other as NameKey;
				if (okey == null) return false;

				if (length != okey.name.Length) return false;
				// TODO check performance of making locals of fields
				for (int i=0; i < length; i++) {
					if (name[i+start] != okey.name[i]) return false;
				}
				return true;
			}
		}


		private char[] name;
		private int hashcode;

		private Name(char[] name, int hashcode)
		{
			this.name = name;
			this.hashcode = hashcode;
		}
		public override int GetHashCode() {
			return hashcode;
		}
		public override bool Equals(object other) {
			return (object)this == other;
		}

		public String GetString() {
			return new String(name);
		}

		public override string ToString() {
			return "Name(" + new String(name) + ")";
		}
	}

}
