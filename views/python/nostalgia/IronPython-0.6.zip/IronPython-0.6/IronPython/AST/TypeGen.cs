/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;

using System.Collections;

using System.Reflection;
using System.Reflection.Emit;

using System.Security.Permissions;

using IronPython.Objects;
using IronMath;

namespace IronPython.AST {
	public class TypeGen {
		private ConstructorBuilder initializer;
		private CodeGen initGen;

		public readonly AssemblyGen myAssembly;
		public readonly TypeBuilder myType;
		private ArrayList nestedTypeGens = new ArrayList();
		public Slot moduleSlot;

		public TypeGen(AssemblyGen myAssembly, TypeBuilder myType) {
			this.myAssembly = myAssembly;
			this.myType = myType;
			//!!!AddModuleField(myType);
		}

		public CodeGen getOrMakeInitializer() {
			if (initializer == null) {
				initializer = myType.DefineTypeInitializer();
				initGen = new CodeGen(this, null, initializer.GetILGenerator());
			}
			return initGen;
		}

		public Type finishType() {
			if (initGen != null) initGen.ilg.Emit(OpCodes.Ret);

			Type ret = myType.CreateType();
			foreach (TypeGen ntb in nestedTypeGens) {
				ntb.finishType();
			}

			//Console.WriteLine("finished: " + ret.FullName);
			return ret;
		}

		public TypeGen defineNestedType(string name, Type parent) {
			TypeBuilder tb = myType.DefineNestedType(name, TypeAttributes.NestedPublic);
			tb.SetParent(parent);
			TypeGen ret = new TypeGen(myAssembly, tb);
			nestedTypeGens.Add(ret);

			//!!!ret.AddModuleField(myType);

			return ret;
		}

		public void AddModuleField(Type moduleType) {
			FieldBuilder moduleField = this.myType.DefineField("myModule__py",
				moduleType, FieldAttributes.Public|FieldAttributes.Static);  //!!!
			this.moduleSlot = new StaticFieldSlot(moduleField);
		}

//		public CodeGen defineMethod(string name, Type retType, Type[] paramTypes) {
//			return defineMethod(MethodAttributes.Public, name, retType, paramTypes);
//		}
//		public CodeGen defineStaticMethod(string name, Type retType, Type[] paramTypes) {
//			return defineMethod(MethodAttributes.Public|MethodAttributes.Static, name, retType, paramTypes);
//		}

		public Slot AddField(Type fieldType, string name) {
			FieldBuilder fb = myType.DefineField(name, fieldType, FieldAttributes.Public);
			return new FieldSlot(new ThisSlot(myType), fb);
		}

		public CodeGen DefineMethodOverride(MethodInfo baseMethod) {
			MethodAttributes attrs = baseMethod.Attributes & ~MethodAttributes.Abstract;
			MethodBuilder mb = myType.DefineMethod(baseMethod.Name, attrs, baseMethod.ReturnType, 
				Constants.GetTypes(baseMethod.GetParameters()));
			CodeGen ret = new CodeGen(this, mb, mb.GetILGenerator());
			ret.methodToOverride = baseMethod;
			return ret;
		}


		public CodeGen defineMethod(string name, Type retType, Type[] paramTypes) {
			MethodAttributes attrs = MethodAttributes.Public;
			if (Options.STATIC_MODULES) attrs |= MethodAttributes.Static;
			return defineMethod(attrs, name, retType, paramTypes);
		}

		public CodeGen defineMethod(MethodAttributes attrs, string name, Type retType, Type[] paramTypes) {
			MethodBuilder mb = myType.DefineMethod(name, attrs, retType, paramTypes);
			return new CodeGen(this, mb, mb.GetILGenerator());
		}

		private Type[] ExtractTypes(ParameterInfo[] ps) {
			int len = ps.Length;
			Type[] ret = new Type[len];
			for (int i=0; i < len; i++) {
				ret[i] = ps[i].ParameterType;
			}
			return ret;
		}


		public ConstructorInfo DefineChainedConstructor(ConstructorInfo parentConstructor) {
			ParameterInfo[] pis = parentConstructor.GetParameters();
			Type[] types = ExtractTypes(pis);
			ConstructorBuilder cb = myType.DefineConstructor(MethodAttributes.Public, CallingConventions.Standard, types);
			for (int i=0; i < pis.Length; i++) {
				ParameterBuilder pb = cb.DefineParameter(i+1, pis[i].Attributes, pis[i].Name);
				if (pis[i].IsDefined(typeof(ParamArrayAttribute), false)) {
					pb.SetCustomAttribute(new CustomAttributeBuilder(
						typeof(ParamArrayAttribute).GetConstructor(Type.EmptyTypes), new object[0]));
				}
			}

			ILGenerator ilg = cb.GetILGenerator();
			ilg.Emit(OpCodes.Ldarg_0);

			for (int i=0; i < types.Length; i++) {
				ilg.Emit(OpCodes.Ldarg, i+1);
			}
			ilg.Emit(OpCodes.Call, parentConstructor);
			ilg.Emit(OpCodes.Ret);
			return cb;
		}

		/// <summary>
		/// Constants
		/// </summary>
		private Hashtable constants = new Hashtable();
//		public Slot getOrMakeConstant(PyObject _value) {
//			//!!! should I use a parent ???
//
//			Slot ret = (Slot)constants[_value];
//			//Console.WriteLine("making constant for: " + _value + " is " + ret);
//			if (ret != null) return ret;
//
//			String name = "c$" + constants.Count;
//
//			FieldBuilder fb = myType.DefineField(name, _value.GetType(),
//				FieldAttributes.Static);//??? | FieldAttributes.Literal
//			ret = new StaticFieldSlot(fb);
//
//			emitConstantInitializer(getOrMakeInitializer(), _value);
//			initGen.emitFieldSet(fb);
//
//			constants[_value] = ret;
//			return ret;
//		}

		public Slot getOrMakeConstant(object _value) {
			//!!! should I use a parent ???

			Slot ret = (Slot)constants[_value];
			//Console.WriteLine("making constant for: " + _value + " is " + ret);
			if (ret != null) return ret;

			String name = "c$" + constants.Count;

			FieldBuilder fb = myType.DefineField(name, typeof(object), //value.GetType(),
				FieldAttributes.Static);//??? | FieldAttributes.Literal
			ret = new StaticFieldSlot(fb);

			emitConstantInitializer(getOrMakeInitializer(), _value);
			initGen.emitFieldSet(fb);

			constants[_value] = ret;
			return ret;
		}

		private void emitConstantInitializer(CodeGen cg, object _value) {
			if (_value is int) {
				cg.emitInt((int)_value);
				cg.ilg.Emit(OpCodes.Box, typeof(int));
			} else if (_value is double) {
				cg.ilg.Emit(OpCodes.Ldc_R8, (double)_value);
				cg.ilg.Emit(OpCodes.Box, typeof(double));
			} else if (_value is long) {
				cg.ilg.Emit(OpCodes.Ldc_I8, (long)_value);
				cg.ilg.Emit(OpCodes.Box, typeof(long));
			} else if (_value is Complex64) {
				Complex64 c = (Complex64)_value;
				if (c.real != 0.0) throw new NotImplementedException();
				cg.ilg.Emit(OpCodes.Ldc_R8, c.imag);
				cg.emitCall(typeof(Complex64), "MakeImaginary");
				cg.ilg.Emit(OpCodes.Box, typeof(Complex64));
			} else if (_value is integer) {
				integer i = (integer)_value;
				int ival;
				if (i.AsInt32(out ival)) {
					cg.emitInt(ival);
					cg.emitCall(typeof(integer), "make", new Type[] {typeof(int)});
					cg.ilg.Emit(OpCodes.Box, typeof(integer));
					return;
				}
				long lval;
				if (i.AsInt64(out lval)) {
					cg.ilg.Emit(OpCodes.Ldc_I8, lval);
					cg.emitCall(typeof(integer), "make", new Type[] {typeof(long)});
					cg.ilg.Emit(OpCodes.Box, typeof(integer));
					return;
				}

				cg.emitString( i.ToString((uint)16) );
				cg.emitCall(typeof(Ops), "MakeIntegerFromHex");
				cg.ilg.Emit(OpCodes.Box, typeof(integer));
				return;
//			} else if (_value is Str) {
//				cg.emitString( ((Str)_value).value );
//				cg.emitCall(typeof(Str), "intern", new Type[] { typeof(string) });
			} else {
				throw new NotImplementedException("generate: " + _value);
			}
		}


//		private void emitConstantInitializer(CodeGen cg, PyObject _value) {
//			PyString s = _value as PyString;
//			if (s != null) {
//				cg.ilg.Emit(OpCodes.Ldstr, s.value);
//				cg.ilg.Emit(OpCodes.Call,
//					typeof(PyString).GetMethod("intern", 
//					new Type[] {typeof(string)}));
//				return;
//			}
//			PyInteger i = _value as PyInteger;
//			if (i != null) {
//				cg.emitInt(i.value);
//				cg.emitCall(typeof(PyInteger), "make");
//				return;
//			}
//			PyFloat f = _value as PyFloat;
//			if (f != null) {
//				cg.ilg.Emit(OpCodes.Ldc_R8, f.value);
//				cg.emitCall(typeof(PyFloat), "make");
//				return;
//			}
//			PyLong l = _value as PyLong;
//			if (l != null) {
//				int ival;
//				if (l.value.AsInt32(out ival)) {
//					cg.emitInt(ival);
//					cg.emitCall(typeof(PyLong), "make", new Type[] {typeof(int)});
//					return;
//				}
//				long lval;
//				if (l.value.AsInt64(out lval)) {
//					cg.ilg.Emit(OpCodes.Ldc_I8, lval);
//					cg.emitCall(typeof(PyLong), "make", new Type[] {typeof(long)});
//					return;
//				}
//				throw new NotImplementedException("too big long: " + l);
//			}
//
//			if (_value == Py.None) {
//				cg.emitPyNone();
//				return;
//			}
//
//			throw new NotImplementedException("generate: " + _value);
//		}

		////////////////////////////////////////////////
		///getattr and setattr helpers
		///  need to detect case of too many attrs and generate switch
//		public void createAttrMethods(Hashtable slots) {
//			CodeGen setGen = defineMethod(
//				MethodAttributes.Virtual|MethodAttributes.Public,
//				"__setattr__", typeof(void), 
//				new Type[] { typeof(PyString), typeof(PyObject) });
//			ArgSlot.make(setGen.methodBuilder, 1, null);
//			Slot retSlot = ArgSlot.make(setGen.methodBuilder, 2, null);
//
//
//			//setGen.ilg.EmitWriteLine("in __setattr__");
//			internArg1(setGen);
//
//			CodeGen getGen = defineMethod(
//				MethodAttributes.Virtual|MethodAttributes.Public,
//				"__getattr__", typeof(bool),
//				new Type[] { typeof(PyString), Constants.typeofPyObjectAddr });
//			internArg1(getGen);
//
//			foreach (DictionaryEntry entry in slots) {
//				Slot slot = (Slot)entry.Value;
//				Name name = (Name)entry.Key;
//				PyString nameVal = PyString.make(name.GetString());
//				createSlot(getOrMakeConstant(nameVal), slot, retSlot, getGen, setGen);
//			}
//
//			callBase(setGen, myType.BaseType.GetMethod("__setattr__"));
//			setGen.ilg.Emit(OpCodes.Ret);
//
//			callBase(getGen, myType.BaseType.GetMethod("__getattr__",
//				new Type[] { typeof(PyString), Constants.typeofPyObjectAddr }));
//			getGen.ilg.Emit(OpCodes.Ret);
//		}
//
//		private void callBase(CodeGen cg, MethodInfo baseInfo) {
//			int nargs = baseInfo.GetParameters().Length;
//			if (!baseInfo.IsStatic) nargs += 1;
//			for (int i=0; i < nargs; i++) {
//				cg.ilg.Emit(OpCodes.Ldarg, i);
//			}
//			cg.ilg.Emit(OpCodes.Call, baseInfo);
//		}
//
//		private void internArg1(CodeGen cg) {
//			cg.ilg.Emit(OpCodes.Ldarg_1);
//			cg.ilg.Emit(OpCodes.Call, typeof(PyString).GetMethod("intern", new Type[0]));
//			cg.ilg.Emit(OpCodes.Starg, 1);
//		}
//
//		
//		private void createSlot(Slot name, Slot val, Slot retSlot, CodeGen getGen, CodeGen setGen) {
//			Label next = setGen.ilg.DefineLabel();
//			setGen.ilg.Emit(OpCodes.Ldarg_1);
//			name.emitGet(setGen);
//			setGen.ilg.Emit(OpCodes.Bne_Un, next);
//
//			val.emitSet(setGen, retSlot);
//			setGen.ilg.Emit(OpCodes.Ret);
//			setGen.ilg.MarkLabel(next);
//
//			next = getGen.ilg.DefineLabel();
//			getGen.ilg.Emit(OpCodes.Ldarg_1);
//			name.emitGet(getGen);
//			getGen.ilg.Emit(OpCodes.Bne_Un, next);
//
//			getGen.ilg.Emit(OpCodes.Ldarg_2);
//			val.emitGet(getGen);
//			getGen.ilg.Emit(OpCodes.Stind_Ref);
//
//			getGen.emitInt(1);
//			getGen.ilg.Emit(OpCodes.Ret);
//			getGen.ilg.MarkLabel(next);
//		}
	}
}
