/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;

namespace IronPython.AST
{
	/// <summary>
	/// Summary description for Options.
	/// </summary>
	public class Options
	{
		public static bool RAW_OBJECTS = true;

		public static bool FRAME_FUNCTIONS = false;
		public static bool FIELDS_FOR_GLOBALS = true;
		public static bool STATIC_MODULES = true;


		public static bool CHECK_UNINITIALIZED = true;
		public static bool CheckUninitializedLocals = false;


		public static bool DEBUG = true;

		public static bool TRACK_REFLECT_CALLS = false;

		public static bool OPTIMIZE_REFLECT_CALLS = true;


		public static bool UsePythonStr = false;

		public static bool MonoWorkaround = false;

		public static bool FastEval = true;
	}
}
