#####################################################################
# Copyright (c) 2003, 2004 Jim Hugunin
# All rights reserved. 
# This program and the accompanying materials are made available 
# under the terms of the Common Public License v1.0 
# which accompanies this distribution and is available at 
# http://www.eclipse.org/legal/cpl-v10.html 
#  
# Contributors: 
#     Jim Hugunin     initial implementation 
#####################################################################

import os

def is_binary(filename):
    root, ext = os.path.splitext(filename)
    return ext in ['.pyc', '.pyo', '.pdb', '.exe', '.dll', '.projdata']

def do_dir(dirname):
    if dirname == BIN_DIR: return
    
    for file in os.listdir(dirname):
        filename = os.path.join(dirname, file)
        if os.path.isdir(filename):
            do_dir(filename)
        elif is_binary(filename):
            print 'deleting', filename
            os.remove(filename)

TOP_DIR = "c:\\IronPython-0.6"
BIN_DIR = os.path.join(TOP_DIR, "bin")

do_dir(TOP_DIR)

        
    
