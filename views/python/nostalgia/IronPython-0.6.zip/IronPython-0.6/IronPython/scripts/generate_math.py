#####################################################################
# Copyright (c) 2003, 2004 Jim Hugunin
# All rights reserved. 
# This program and the accompanying materials are made available 
# under the terms of the Common Public License v1.0 
# which accompanies this distribution and is available at 
# http://www.eclipse.org/legal/cpl-v10.html 
#  
# Contributors: 
#     Jim Hugunin     initial implementation 
#####################################################################
import generate
reload(generate)
from generate import CodeGenerator, CodeWriter

class Func:
    def __init__(self, name, args=1, cname=None):
        self.name = name
        self.args = args
        if cname is None:
            cname = name.capitalize()
        self.cname = cname

    def write(self, cw):
        params = ["double v%d" % i for i in range(self.args)]
        args = ["v%d" % i for i in range(self.args)]
        cw.enter_block("public static double %s(%s)" %
                       (self.name, ", ".join(params)))
        cw.write("return check(Math.%s(%s));" %
                 (self.cname, ", ".join(args)))
        cw.exit_block()

#Func('fmod', 2), Func('modf'),
#Func('frexp'),Func('hypot', 2), Func('ldexp', 2), 
        
funcs = [
    Func('acos'), Func('asin'), Func('atan'), Func('atan2', 2),
    Func('ceil', 1, 'Ceiling'), Func('cos'), Func('cosh'), Func('exp'),
    Func('fabs', 1, 'Abs'), Func('floor'),
    Func('log'), Func('log', 2), Func('log10'),
    Func('pow', 2), Func('sin'), Func('sinh'),
    Func('sqrt'), Func('tan'), Func('tanh'),
]
    
def gen_funcs(cw):
    for func in funcs:
        func.write(cw)

CodeGenerator("math functions", gen_funcs).doit()
 
