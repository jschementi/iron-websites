#####################################################################
# Copyright (c) 2003, 2004 Jim Hugunin
# All rights reserved. 
# This program and the accompanying materials are made available 
# under the terms of the Common Public License v1.0 
# which accompanies this distribution and is available at 
# http://www.eclipse.org/legal/cpl-v10.html 
#  
# Contributors: 
#     Jim Hugunin     initial implementation 
#####################################################################
cs_header = """/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
"""

py_header = """#####################################################################
# Copyright (c) 2003, 2004 Jim Hugunin
# All rights reserved. 
# This program and the accompanying materials are made available 
# under the terms of the Common Public License v1.0 
# which accompanies this distribution and is available at 
# http://www.eclipse.org/legal/cpl-v10.html 
#  
# Contributors: 
#     Jim Hugunin     initial implementation 
#####################################################################
"""

import os

def add_header(filename, header):
    text = open(filename, 'r').read()
    text = header + text
    open(filename, 'w').write(text)

def do_dir(dirname):
    for file in os.listdir(dirname):
        if file == "ExternalCode": continue
        filename = os.path.join(dirname, file)
        if os.path.isdir(filename):
            do_dir(filename)
        elif filename.endswith(".cs"):
            add_header(filename, cs_header)
        elif filename.endswith(".py"):
            add_header(filename, py_header)


do_dir("c:\\IronPython-0.6")

        
    
