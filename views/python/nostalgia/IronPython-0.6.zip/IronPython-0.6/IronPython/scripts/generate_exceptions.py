#####################################################################
# Copyright (c) 2003, 2004 Jim Hugunin
# All rights reserved. 
# This program and the accompanying materials are made available 
# under the terms of the Common Public License v1.0 
# which accompanies this distribution and is available at 
# http://www.eclipse.org/legal/cpl-v10.html 
#  
# Contributors: 
#     Jim Hugunin     initial implementation 
#####################################################################
import generate
reload(generate)
from generate import CodeGenerator, CodeWriter

import exceptions

CLASS = """
[PythonType("%(name)s")] public class %(name)s:%(supername)s {
    public static new PyObject __new__(params PyObject[] args) { return new %(name)s(args); }
    public %(name)s(params PyObject[] args):base(args) {}
    public static new readonly PyBuiltinType pytype = new PyBuiltinType(typeof(%(name)s));
    public override PyType get__class__() { return pytype; }
    public override PythonException makePythonException() { return new %(xname)s(this); }
}"""

def collect_excs():
    ret = []
    for e in exceptions.__dict__.values():
        if not hasattr(e, '__bases__'): continue
        assert len(e.__bases__) <= 1, e
        if len(e.__bases__) == 0:
            continue
            #supername = None
        else:
            supername = e.__bases__[0].__name__
        ret.append( (e, supername) )
    return ret
excs = collect_excs()
    

def exc_generator(cw):
    gaw = CodeWriter()
    saw = CodeWriter()

    for e, supername in excs:
        xname = e.__name__
        name = "Py"+xname
        #if supername is None: supername = 'PyException'
        cw.write(CLASS, name=name, xname = xname, supername = "Py"+supername)
        gaw.write("if ((object)name == (object)%(xname)s_str) { ret=%(name)s.pytype; return true; }",
                  name=name, xname=xname)
        saw.write('static PyString %(xname)s_str = PyString.intern("%(xname)s");',
                  name = name, xname=xname)


    cw.writeline()
    cw.enter_block("public override bool __getattr__(PyString name, out PyObject ret)")
    cw.write("name = name.intern();")
    cw.write(gaw.text())
    cw.write("return base.__getattr__(name, out ret);")
    cw.exit_block()

    cw.write(saw.text())
            
CodeGenerator("Exception Classes", exc_generator).doit()

FACTORY = """
public static %(name)s %(name)s(string format, params object[] args) {
        return new %(name)s(new exceptions.Py%(name)s(PyString.make(format, args)));
}"""

def factory_gen(cw):
    for e, supername in excs:
        cw.write(FACTORY, name=e.__name__)


CodeGenerator("PythonException Factory", factory_gen).doit()

CLASS1 = """
public class %(name)s:%(supername)s {
        public %(name)s(exceptions.Py%(name)s error):base(error) {}
}"""

def factory_gen(cw):
    for e, supername in excs:
        if supername =="Exception": supername = 'PythonException'
        cw.write(CLASS1, name=e.__name__, supername=supername)


CodeGenerator("PythonExceptions", factory_gen).doit()

def builtin_gen(cw):
    for e, supername in excs:
        cw.write("public static PyObject %s = exceptions.Py%s.pytype;" %
                 (e.__name__, e.__name__))

CodeGenerator("Builtin Exceptions", builtin_gen).doit()

