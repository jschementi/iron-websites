#####################################################################
# Copyright (c) 2003, 2004 Jim Hugunin
# All rights reserved. 
# This program and the accompanying materials are made available 
# under the terms of the Common Public License v1.0 
# which accompanies this distribution and is available at 
# http://www.eclipse.org/legal/cpl-v10.html 
#  
# Contributors: 
#     Jim Hugunin     initial implementation 
#####################################################################
import generate
reload(generate)
from generate import CodeGenerator, CodeWriter

MAX_ARGS = 4

def make_params(nargs, *prefix):
    params = ["object arg%d" % i for i in range(nargs)]
    return ", ".join(list(prefix) + params)
    

def calltargets(cw):
    for nparams in range(MAX_ARGS+1):
        cw.write("public delegate object CallTarget%d(%s);" %
                 (nparams, make_params(nparams)))

CodeGenerator("CallTargets", calltargets).doit()


def gen_call(nargs, nparams, cw):
    #params = ["object arg%d" % i for i in range(nargs)]
    args = ["arg%d" % i for i in range(nargs)]
    cw.enter_block("public override object Call(%s)" % make_params(nargs))

    if (nargs == nparams):
        cw.write("return target(%s);" % ", ".join(args))
    else:
        ndefaults = nparams-nargs
        
        dargs = args + ["defaults[defaults.Length-%d]" % i for i in range(ndefaults, 0, -1)]
        cw.write("if (defaults.Length >= %d) return target(%s);" %
                 (ndefaults, ", ".join(dargs)))
        cw.write("else throw badArgCount(%d);" % nargs)

    cw.exit_block()


def gen_function(nparams, cw):
    cw.write("""[PythonType("function")]""")
    cw.enter_block("public class Function%d:Function" % nparams)
    cw.write("private CallTarget%d target;" % nparams)
    
    cw.enter_block("public Function%(nparams)d(module globals, string name, CallTarget%(nparams)s target, string[] argNames, object[] defaults): base(globals, name, argNames, defaults)",
                   nparams=nparams)
    cw.write("this.target = target;")
    cw.exit_block()

    cw.write("public override MethodInfo GetMethod() { return target.Method; }")

    for nargs in range(nparams+1):
        gen_call(nargs, nparams, cw)

    cw.enter_block("public override object Call(params object[] args)")
    cw.enter_block("switch(args.Length)")
    for nargs in range(nparams+1):
        args = ["args[%d]" % i for i in range(nargs)]
        cw.write("case %d: return Call(%s);" % (nargs, ", ".join(args)))
    cw.write("default: throw badArgCount(args.Length);")
    cw.exit_block()
    cw.exit_block()

    cw.exit_block()

def functions(cw):
    for nparams in range(MAX_ARGS+1):
        gen_function(nparams, cw)

CodeGenerator("FunctionNs", functions).doit()




##def gen_invoke_meth(nargs, cw):
##    params = ["PyObject arg%d" % i for i in range(nargs)]
##    args = ["arg%d" % i for i in range(nargs)]
##    params.insert(0, "PyString name")
##    cw.enter_block("public virtual PyObject invoke(%s)" %
##                   ", ".join(params))
##    cw.write("return __getattr__(name).__call__(%s);" %
##             ", ".join(args))
##    cw.exit_block()

def gen_methods(cw):    
    for nparams in range(MAX_ARGS+1):
        cw.write("object Call(%s);" % make_params(nparams))

CodeGenerator("FastCallable methods", gen_methods).doit()

CODE = """
public static object Call(%(params)s) {
    Function f = func as Function;
    if (f != null) return f.Call(%(args)s);

    IFastCallable ifc = func as IFastCallable;
    if (ifc != null) return ifc.Call(%(args)s);

    ICallable ic = func as ICallable;
    if (ic != null) return ic.Call(%(argsArray)s);

    return Ops.Call(func, %(argsArray)s);
}"""


def gen_call_meth(nargs, cw):
    args = ["arg%d" % i for i in range(nargs)]
    argsArray = "EMPTY"
    if nargs > 0:
        argsArray = "new object[] { %s }" % ", ".join(args)
        
    cw.write(CODE, params=make_params(nargs, 'object func'), args=", ".join(args),
             argsArray = argsArray)

def gen_methods(cw):
    cw.write("public const int MAX_CALL_ARGS = %s;" % MAX_ARGS)
    
    for nparams in range(MAX_ARGS+1):
        gen_call_meth(nparams, cw)

CodeGenerator("Call Ops", gen_methods).doit()




def gen_targets(cw):
    for nargs in range(MAX_ARGS+1):
        cw.write("public CallTarget%d target%d;" % (nargs, nargs))

        params = ["object arg%d" % i for i in range(nargs)]
        args = ["arg%d" % i for i in range(nargs)]
        cw.enter_block("public override object Call(%s)" %
                       ", ".join(params))
        cw.write("if (target%d != null) return target%d(%s);" %
                 (nargs, nargs, ", ".join(args)))
        cw.write("else if (targetN != null) return targetN(new object[]{%s});" %
                 ", ".join(args))
        cw.write("else throw badArgCount(%d);" % nargs)
        cw.exit_block()

    cw.enter_block("public override object Call(params object[] args)")
    #cw.write("if (targetN != null) return targetN(args);")
    cw.enter_block("switch(args.Length)")
    for nargs in range(MAX_ARGS+1):
        cw.write("case %d: return Call(%s);" %
                 (nargs, ", ".join(["args[%d]" % i for i in range(nargs)])))
    cw.write("default: if (targetN != null) return targetN(args);")
    cw.write("         else throw badArgCount(args.Length);")

    cw.exit_block()
    

    cw.exit_block()
        
CodeGenerator("BuiltinFunction targets", gen_targets).doit()


def gen_delegates(cw):
    for nargs in range(MAX_ARGS+1):
        cw.write("case %d: target%d=(CallTarget%d)Delegate.CreateDelegate(typeof(CallTarget%d), mi); break;" %
                 (nargs, nargs, nargs, nargs))

CodeGenerator("BuiltinFunction delegates", gen_delegates).doit()

