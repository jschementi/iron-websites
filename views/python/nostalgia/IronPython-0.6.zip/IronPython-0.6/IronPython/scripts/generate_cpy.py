#####################################################################
# Copyright (c) 2003, 2004 Jim Hugunin
# All rights reserved. 
# This program and the accompanying materials are made available 
# under the terms of the Common Public License v1.0 
# which accompanies this distribution and is available at 
# http://www.eclipse.org/legal/cpl-v10.html 
#  
# Contributors: 
#     Jim Hugunin     initial implementation 
#####################################################################
import generate
reload(generate)
from generate import CodeGenerator, CodeWriter

import re, os

include_dir = r"C:\Python23\Python-2.3.1\Include"

ret_pat = r"(?:\w+\s+)|(?:\w+\s*\*\s*)|(?:PyAPI_FUNC\([^\)]*\)\s+)"

func_pat = r"(?P<ret_type>%s)(?P<name>(?:\w|_)+)\s*\((?P<params>(?:_|\*|\w|\s|,|\[|\])*)\);" % (
    ret_pat)

func_re = re.compile(func_pat, re.DOTALL|re.MULTILINE)

param_pat = r"((?:\w+\s+)|(?:\w+\s*\*\s*))(\w+)\s*[,]?"
param_re = re.compile(param_pat, re.DOTALL|re.MULTILINE)

def collect_params(params):
    param_list = []
    for p_match in param_re.finditer(params):
        ptype, pname = p_match.groups()
        ptype = ptype.strip()
        param_list.append( (ptype, pname) )
    if not param_list:
        i = 0
        for ptype in params.split(','):
            ptype = ptype.strip()
            pname = "arg%d" % i
            i += 1
            param_list.append( (ptype, pname) )

    return param_list


def collect_funcs(filename, funcs, only_from_as=False):
    text = open(filename).read()

    for match in func_re.finditer(text):
        ret_type, name, params = match.groups()
        if only_from_as:
            if 'From' not in name and 'As' not in name and not name.endswith("_New"): continue
        
        ret_type = ret_type.strip()

        if ret_type.startswith("PyAPI_FUNC("):
            ret_type = ret_type[len("PyAPI_FUNC("):-1]

        param_list = collect_params(params.strip())
        if not param_list:
            print 'skipping', name, ' with bad params ', params
        funcs.append( (ret_type, name, param_list) )

funcs = []

for filename in os.listdir(include_dir):
    if not filename.endswith(".h"): continue
    only_from_as = filename != 'abstract.h'

    collect_funcs(os.path.join(include_dir, filename), funcs, only_from_as)


TEMPLATE = """[DllImport("python23.dll")]
public static extern IntPtr PyNumber_Add(IntPtr o1, IntPtr o2);"""

TEMPLATE = """[DllImport("python23.dll")]
public static extern %(ret_type)s %(name)s(%(params)s);"""

mtypes = {
    'PyObject *':'IntPtr',
    'PyObject*':'IntPtr',
    'int':'int',
    'long':'int',
    'double':'double',
    'char *':'string',
}

keywords = {'object':1, 'base':1, 'override':1}

def clean_name(name):
    if keywords.has_key(name): return "_"  + name
    else: return name

def import_gen(cw):
    for ret_type, name, param_list in funcs:
        try:
            params = ["%s %s" % (mtypes[ptype], clean_name(pname)) for ptype, pname in param_list]
            cw.write(TEMPLATE, ret_type=mtypes[ret_type], name=clean_name(name),
                     params=", ".join(params))
        except KeyError, ke:
            print 'skipping', name, ' with error ', ke

CodeGenerator("CPython DllImports", import_gen).doit()
