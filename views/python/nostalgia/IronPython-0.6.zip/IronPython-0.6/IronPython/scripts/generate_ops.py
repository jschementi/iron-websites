#####################################################################
# Copyright (c) 2003, 2004 Jim Hugunin
# All rights reserved. 
# This program and the accompanying materials are made available 
# under the terms of the Common Public License v1.0 
# which accompanies this distribution and is available at 
# http://www.eclipse.org/legal/cpl-v10.html 
#  
# Contributors: 
#     Jim Hugunin     initial implementation 
#####################################################################
import generate
reload(generate)
from generate import CodeGenerator
import keyword, operator

class Symbol:
    def __init__(self, symbol, name):
        self.symbol = symbol
        self.name = name

    def cap_name(self):
        return self.name.title().replace(' ', '')

    def upper_name(self):
        return self.name.upper().replace(' ', '_')

    def simple_name(self):
        return self.name[0] + self.cap_name()[1:]

    def __repr__(self):
        return 'Symbol(%s)' % self.symbol

class Operator(Symbol):
    def __init__(self, symbol, name, rname, clrName=None,prec=-1):
        Symbol.__init__(self, symbol, name)
        self.rname = rname
        self.clrName = clrName
        self.meth_name = "__" + name + "__"
        self.rmeth_name = "__" + rname + "__"
        if keyword.kwdict.has_key(name):
            name = name + "_"
        self.op = getattr(operator, name)
        self.prec = prec

    def clrInPlaceName(self):
        return "InPlace" + self.clrName

    def isCompare(self):
        return self.prec == -1

    def __repr__(self):
        return 'Operator(%s,%s,%s)' % (self.symbol, self.name, self.rname)

class Grouping(Symbol):
    def __init__(self, symbol, name, side):
        Symbol.__init__(self, symbol, side+" "+name)
        self.base_name = name
        self.side = side

ops = []
def add_ops(oplist):
    for names in oplist:
        if len(names) == 2:
            symbol, name = names
            rname = "r"+name
        else:
            symbol, name, rname = names
        op = Operator(symbol, name, rname)
        ops[symbol] = op
        ops[name] = op

"""
0 expr: xor_expr ('|' xor_expr)*
1 xor_expr: and_expr ('^' and_expr)*
2 and_expr: shift_expr ('&' shift_expr)*
3 shift_expr: arith_expr (('<<'|'>>') arith_expr)*
4 arith_expr: term (('+'|'-') term)*
5 term: factor (('*'|'/'|'%'|'//') factor)*
"""
binaries = [('+', 'add', 4, 'Add'), ('-', 'sub',4,'Subtract'), ('**', 'pow', 6,'Power'), ('*', 'mul', 5,'Multiply'),
            ('//', 'floordiv', 5, 'FloorDivide'), ('/', 'div', 5, 'Divide'),
            ('%', 'mod', 5, 'Mod'), ('<<', 'lshift', 3, 'LeftShift'), ('>>', 'rshift', 3, 'RightShift'),
            ('&', 'and', 2, 'BitwiseAnd'), ('|', 'or', 0, 'BitwiseOr'), ('^', 'xor', 1, 'Xor')]
for sym, name, prec,clrName in binaries:
    ops.append(Operator(sym, name, 'r'+name, clrName,prec))
    ops.append(Symbol(sym+"=", name+" eq"))

compares = [('<', 'lt', 'ge', 'LessThan'), ('>', 'gt', 'le', 'GreaterThan'),
            ('<=', 'le', 'gt', 'LessThanOrEqual'), ('>=', 'ge', 'lt', 'GreaterThanOrEqual'),
            ('==', 'eq', 'eq', 'Equal'), ('!=', 'ne', 'ne', 'NotEqual')]
for sym, name, rname,clrName in compares:
    ops.append(Operator(sym, name, rname,clrName))

groupings = [('(', ')', 'paren'), ('[', ']', 'bracket'), ('{', '}', 'brace')]
for sym, rsym, name in groupings:
    ops.append(Grouping(sym, name, 'l'))
    ops.append(Grouping(rsym, name, 'r'))

simple = [(',', 'comma'), (':', 'colon'), ('`', 'backquote'), (';', 'semicolon'),
          ('=', 'assign'), ('~', 'twidle'), ('<>', 'lg')]
for sym, name in simple:
    ops.append(Symbol(sym, name))

start_symbols = {}
for op in ops:
    ss = op.symbol[0]
    if not start_symbols.has_key(ss): start_symbols[ss] = []
    start_symbols[ss].append(op)


def gen_tests(ops, pos, indent=1):
    ret = []
    
    default_match = []
    future_matches = {}
    for sop in ops:
        if len(sop.symbol) == pos:
            default_match.append(sop)
        elif len(sop.symbol) > pos:
            ch = sop.symbol[pos]
            if future_matches.has_key(ch):
                future_matches[ch].append(sop)
            else:
                future_matches[ch] = [sop]
    assert len(default_match) <= 1
    for ch, sops in future_matches.items():
        ret.append("if (nextChar('%s')) {" % ch)
        ret.extend(gen_tests(sops, pos+1))
        ret.append("}")
    if default_match:
        op = default_match[0]
        if isinstance(op, Grouping):
            if op.side == 'l':
                ret.append("%sLevel++;" % op.base_name);
            else:
                ret.append("%sLevel--;" % op.base_name);
        ret.append("setEnd(); return TokenKind.%sToken;" %
                   op.cap_name())
    else:
        ret.append("return badChar(nextChar());")

    return ["\t"*indent + l for l in ret]

def tokenize_generator(cw):
    ret = []
    done = {}
    for op in ops:
        ch = op.symbol[0]
        if done.has_key(ch): continue
        sops = start_symbols[ch]
        cw.write("case '%s':" % ch)
        for t in gen_tests(sops, 1):
            cw.write(t)
        done[ch] = True
    return ret
    

CodeGenerator("Tokenize Ops", tokenize_generator).doit()

def tokenkinds_generator(cw):
    i = 32
    for op in ops:
        cw.write("public const int %s = %d;" %
                   (op.upper_name(), i))
        i += 1
        if isinstance(op, Operator):
            creator = 'new OperatorToken(%s, Operator.%sOp)' % (
                op.upper_name(), op.cap_name())
        else:
            creator = 'new SymbolToken(%s, "%s")' % (
                op.upper_name(), op.symbol)
        cw.write("public static readonly Token %sToken = %s;" %
                   (op.cap_name(), creator))

    cw.writeline()
    keyword_list = list(keyword.kwdict.keys())
    keyword_list.sort()

    dict_init = []
    
    for kw in keyword_list:
        cw.write("public const int k%s = %d;" %
                           (kw.upper(), i))
        i += 1
        
        creator = 'new SymbolToken(k%s, "%s")' % (
            kw.upper(), kw)
        cw.write("public static readonly Token k%sToken = %s;" %
               (kw.capitalize(), creator))
        
        dict_init.append("keywords[Name.make(\"%s\")] = k%sToken;" %
                         (kw, kw.capitalize()))

    cw.writeline()
    cw.write("public static readonly Hashtable keywords = new Hashtable();");
    cw.enter_block("static TokenKind()")
    for l in dict_init: cw.write(l)
    cw.exit_block() 


CodeGenerator("Token Kinds", tokenkinds_generator).doit()
    
def operators_generator(cw):
    for op in ops:
        if not isinstance(op, Operator): continue

        if op.isCompare():
            creator = 'new BinaryOperator("%s", new CallTarget2(Ops.%s), null, -1)' % (
                op.symbol, op.clrName)
        else:
            creator = 'new BinaryOperator("%s", new CallTarget2(Ops.%s), new CallTarget2(Ops.%s), %d)' % (
                op.symbol, op.clrName, op.clrInPlaceName(), op.prec)

        cw.write("public static readonly BinaryOperator %sOp = %s;" %
                   (op.cap_name(), creator))

CodeGenerator("Operators", operators_generator).doit()

IBINOP = """
public static object %(name)s(object x, object y) {
    object ret;
    if (x is int) {
            ret = IntOps.%(name)s((int)x, y);
            if (ret != NotImplemented) return ret;
    } else if (x is IronMath.integer) {
            ret = LongOps.%(name)s((IronMath.integer)x, y);
            if (ret != NotImplemented) return ret;
    } else if (x is long) {
            ret = Int64Ops.%(name)s((long)x, y);
            if (ret != NotImplemented) return ret;
    }
    ret = GetDynamicType(x).%(name)s(x, y);
    if (ret != NotImplemented) return ret;
    ret = GetDynamicType(y).Reverse%(name)s(y, x);
    if (ret != NotImplemented) return ret;
    
    throw Ops.TypeError("unsupported operand type(s) for %(symbol)s: '{0}' and '{1}'",
                        GetDynamicType(x).__name__, GetDynamicType(y).__name__);
}"""


BINOP = """
public static object %(name)s(object x, object y) {
    object ret;
    if (x is int) {
            ret = IntOps.%(name)s((int)x, y);
            if (ret != NotImplemented) return ret;
    } else if (x is double) {
            ret = FloatOps.%(name)s((double)x, y);
            if (ret != NotImplemented) return ret;
    } else if (x is IronMath.Complex64) {
            ret = ComplexOps.%(name)s((IronMath.Complex64)x, y);
            if (ret != NotImplemented) return ret;
    } else if (x is IronMath.integer) {
            ret = LongOps.%(name)s((IronMath.integer)x, y);
            if (ret != NotImplemented) return ret;
    } else if (x is long) {
            ret = Int64Ops.%(name)s((long)x, y);
            if (ret != NotImplemented) return ret;
    }

    %(extra_code)s

    ret = GetDynamicType(x).%(name)s(x, y);
    if (ret != NotImplemented) return ret;
    ret = GetDynamicType(y).Reverse%(name)s(y, x);
    if (ret != NotImplemented) return ret;
    throw Ops.TypeError("unsupported operand type(s) for %(symbol)s: '{0}' and '{1}'",
                        GetDynamicType(x).__name__, GetDynamicType(y).__name__);
}"""

CMPOP = """
public static object %(name)s(object x, object y) {
    if (x is int) {
        if (y is int) {
            return bool2object(((int)x)%(symbol)s((int)y));
        } else if (y is double) {
            return ((int)x)%(symbol)s((double)y);
        }
    } else if (x is double) {
        if (y is int) {
            return ((double)x)%(symbol)s((int)y);
        } else if (y is double) {
            return ((double)x)%(symbol)s((double)y);
        }
    }

    return bool2object(Compare(x, y) %(symbol)s 0);
}"""

INPLACE_OP = """
public static object %(inname)s(object x, object y) {
    object ret;
    if (x is int) {
            ret = IntOps.%(name)s((int)x, y);
            if (ret != NotImplemented) return ret;
    } else if (x is double) {
            ret = FloatOps.%(name)s((double)x, y);
            if (ret != NotImplemented) return ret;
    } else if (x is long) {
            ret = Int64Ops.%(name)s((long)x, y);
            if (ret != NotImplemented) return ret;
    } else if (x is IronMath.integer) {
            ret = LongOps.%(name)s((IronMath.integer)x, y);
            if (ret != NotImplemented) return ret;
    }
    throw new NotImplementedException("%(inname)s");
}
"""
IINPLACE_OP = """
public static object %(inname)s(object x, object y) {
    object ret;
    if (x is int) {
            ret = IntOps.%(name)s((int)x, y);
            if (ret != NotImplemented) return ret;
    } else if (x is IronMath.integer) {
            ret = LongOps.%(name)s((IronMath.integer)x, y);
            if (ret != NotImplemented) return ret;
    }
    throw new NotImplementedException("%(inname)s");
}
"""

UBINOP = """
public static object %(name)s(object x, object y) {
    throw new NotImplementedException("%(name)s");
}
"""


ADD_EXTRA = """
    ISequence seq = x as ISequence;
    if (seq != null) { return seq.Add(y); }
"""			
MUL_EXTRA = """
    ISequence seq = x as ISequence;
    if (seq != null && y is int) { return seq.Multiply((int)y); }
""" 	


def ops_generator(cw):
    for op in ops:
        if not isinstance(op, Operator): continue

        if op.symbol in ['==', '!=']: continue

        extra = ""
        if op.symbol == '+': extra = ADD_EXTRA
        elif op.symbol == '*': extra = MUL_EXTRA

        #if op.symbol in ['//', '**']: template = UBINOP
        if op.isCompare(): template = CMPOP
        elif op.prec <= 3: template = IBINOP
        else: template = BINOP
        cw.write(template, name=op.clrName, rname=op.rname, symbol=op.symbol, extra_code=extra)

        if template is BINOP:
            cw.write(INPLACE_OP, name = op.clrName, inname=op.clrInPlaceName(),symbol=op.symbol)
        elif template is IBINOP:
            cw.write(IINPLACE_OP, name = op.clrName, inname=op.clrInPlaceName(),symbol=op.symbol)
            
CodeGenerator("Binary Ops", ops_generator).doit()


VIRTS = """
public virtual object %(clrName)s(object self, object other) {
    return Ops.NotImplemented;
}
public virtual object Reverse%(clrName)s(object self, object other) {
    return Ops.NotImplemented;
}
public virtual object InPlace%(clrName)s(object self, object other) {
    return Ops.%(clrName)s(self, other);
}"""

VIRT_CMP = """
public virtual object %(clrName)s(object self, object other) {
    return Ops.NotImplemented;
}"""

def ops_generator(cw, basicTemplate, cmpTemplate):
    for op in ops:
        if not isinstance(op, Operator): continue

        if op.isCompare(): template = cmpTemplate
        else: template = basicTemplate

        cw.write(template, clrName=op.clrName, name=op.name, rname=op.rname, symbol=op.symbol)

def dyn_ops(cw):
    return ops_generator(cw, VIRTS, VIRT_CMP)

CodeGenerator("DynamicType Binary Ops", dyn_ops).doit()


OLDS = """
public override object %(clrName)s(object self, object other) {
    object func;
    if (Ops.GetAttr(self, "__%(name)s__", out func)) return Ops.Call(func, other);
    return Ops.NotImplemented;
}
public override object Reverse%(clrName)s(object self, object other) {
    object func;
    if (Ops.GetAttr(self, "__r%(name)s__", out func)) return Ops.Call(func, other);
    return Ops.NotImplemented;

}
public override object InPlace%(clrName)s(object self, object other) {
    object func;
    if (Ops.GetAttr(self, "__i%(name)s__", out func)) return Ops.Call(func, other);
    return Ops.NotImplemented;
}"""

OLD_CMP = """
public override object %(clrName)s(object self, object other) {
    object func;
    if (Ops.GetAttr(self, "__%(name)s__", out func)) return Ops.Call(func, other);
    return Ops.NotImplemented;
}"""

def old_ops(cw):
    return ops_generator(cw, OLDS, OLD_CMP)

CodeGenerator("OldClass Binary Ops", old_ops).doit()

##ops.append(Operator('/', 'truediv', 'rtruediv', 'TrueDivide', 0))
##line = "public virtual PyObject __%s__(PyObject other) { return Py.NotImplemented; }"
##iline = "public virtual PyObject __i%s__(PyObject other) { return Py.%s(this, other); }"
##
##def pyobject_generator(cw):
##    for op in ops:
##        if not isinstance(op, Operator): continue
##
##        cw.write(line % op.name)
##        if op.prec != -1:
##            cw.write(line % op.rname)
##
##            cw.write(iline % (op.name, op.name))
##            
##CodeGenerator("PyObject Binary Operators", pyobject_generator).doit()
##
##BINOP = """
##public static PyObject %(name)s(PyObject x, PyObject y) {
##    PyObject ret = x.__%(name)s__(y);
##    if (ret != Py.NotImplemented) return ret;
##
##    ret = y.__%(rname)s__(x);
##    if (ret != Py.NotImplemented) return ret;
##
##    throw Py.TypeError("unsupported argument types for %(symbol)s: " +
##                x.getClassName() + ", " + y.getClassName());
##}"""
##
##CMPOP = """
##public static PyObject %(name)s(PyObject x, PyObject y) {
##    PyObject ret = x.__%(name)s__(y);
##    if (ret != Py.NotImplemented) return ret;
##
##    ret = y.__%(rname)s__(x);
##    if (ret != Py.NotImplemented) return ret;
##
##    return PyBoolean.make(x.__cmp__(y) %(symbol)s 0);
##}"""
##
##def py_generator(cw):
##    for op in ops:
##        if not isinstance(op, Operator): continue
##
##        if op.prec < 0: template = CMPOP
##        else: template = BINOP
##        cw.write(template, name=op.name, rname=op.rname, symbol=op.symbol)
##            
##CodeGenerator("Py Binary Operators", py_generator).doit()
##
##
##
##

