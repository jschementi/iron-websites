#####################################################################
# Copyright (c) 2003, 2004 Jim Hugunin
# All rights reserved. 
# This program and the accompanying materials are made available 
# under the terms of the Common Public License v1.0 
# which accompanies this distribution and is available at 
# http://www.eclipse.org/legal/cpl-v10.html 
#  
# Contributors: 
#     Jim Hugunin     initial implementation 
#####################################################################
import generate
reload(generate)
from generate import CodeGenerator, CodeWriter

import exceptions

def collect_excs():
    ret = []
    for e in exceptions.__dict__.values():
        if not hasattr(e, '__bases__'): continue
        assert len(e.__bases__) <= 1, e
        if len(e.__bases__) == 0:
            continue
            #supername = None
        else:
            supername = e.__bases__[0].__name__
        ret.append( (e, supername) )
    return ret
excs = collect_excs()


FACTORY = """
public static Exception %(name)s(string format, params object[] args) {
    return new Python%(name)s(string.Format(format, args));
}"""

def factory_gen(cw):
    for e, supername in excs:
        cw.write(FACTORY, name=e.__name__)


CodeGenerator("Exception Factories", factory_gen).doit()

CLASS1 = """
[PythonType("%(name)s")]
public class Python%(name)s:Python%(supername)s {
        public Python%(name)s(params object[] args):base(args) {
        }
}
"""

def factory_gen(cw):
    for e, supername in excs:
        if supername =="Exception": supername = 'ExceptionNew'
        cw.write(CLASS1, name=e.__name__, supername=supername)


CodeGenerator("PythonException Classes", factory_gen).doit()

def builtin_gen(cw):
    for e, supername in excs:
        cw.write("public static object %s = Ops.GetDynamicTypeFromType(typeof(Python%s));" %
                 (e.__name__, e.__name__))

CodeGenerator("builtin exceptions", builtin_gen).doit()

