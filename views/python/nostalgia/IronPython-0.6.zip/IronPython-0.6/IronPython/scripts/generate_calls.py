#####################################################################
# Copyright (c) 2003, 2004 Jim Hugunin
# All rights reserved. 
# This program and the accompanying materials are made available 
# under the terms of the Common Public License v1.0 
# which accompanies this distribution and is available at 
# http://www.eclipse.org/legal/cpl-v10.html 
#  
# Contributors: 
#     Jim Hugunin     initial implementation 
#####################################################################
import generate
reload(generate)
from generate import CodeGenerator, CodeWriter

MAX_ARGS = 7


def calltargets(cw):
    for nparams in range(MAX_ARGS+1):
        params = ["PyObject arg%d" % i for i in range(nparams)]
        cw.write("public delegate PyObject PyCallTarget%d(%s);" %
                 (nparams, ", ".join(params)))

CodeGenerator("PyCallTargets", calltargets).doit()


def gen_call(nargs, nparams, cw):
    params = ["PyObject arg%d" % i for i in range(nargs)]
    args = ["arg%d" % i for i in range(nargs)]
    cw.enter_block("public override PyObject __call__(%s)" % ", ".join(params))

    if (nargs == nparams):
        cw.write("return target(%s);" % ", ".join(args))
    else:
        ndefaults = nparams-nargs
        
        dargs = args + ["defaults[defaults.Length-%d]" % i for i in range(ndefaults, 0, -1)]
        cw.write("if (defaults.Length >= %d) return target(%s);" %
                 (ndefaults, ", ".join(dargs)))
        cw.write("else throw badArgCount(%d);" % nargs)

    cw.exit_block()


def gen_function(nparams, cw):
    cw.enter_block("public class PyFunction%d:PyFunction" % nparams)
    cw.write("private PyCallTarget%d target;" % nparams)
    
    cw.enter_block("public PyFunction%(nparams)d(PyString name, PyCallTarget%(nparams)d target, PyString[] argNames, PyObject[] defaults): base(name, argNames, defaults)",
                   nparams=nparams)
    cw.write("this.target = target;")
    cw.exit_block()

    cw.write("public override MethodInfo getMethodInfo() { return target.Method; }")

    for nargs in range(nparams+1):
        gen_call(nargs, nparams, cw)

    cw.enter_block("public override PyObject __call__(params PyObject[] args)")
    cw.enter_block("switch(args.Length)")
    for nargs in range(nparams+1):
        args = ["args[%d]" % i for i in range(nargs)]
        cw.write("case %d: return __call__(%s);" % (nargs, ", ".join(args)))
    cw.write("default: throw badArgCount(args.Length);")
    cw.exit_block()
    cw.exit_block()

    cw.exit_block()

def functions(cw):
    for nparams in range(MAX_ARGS+1):
        gen_function(nparams, cw)

CodeGenerator("PyFunctionNs", functions).doit()

"""
		{
			return __call__(new PyObject[] { arg1 });
		}
"""

def gen_call_meth(nargs, cw):
    params = ["PyObject arg%d" % i for i in range(nargs)]
    args = ["arg%d" % i for i in range(nargs)]
    cw.enter_block("public virtual PyObject __call__(%s)" % ", ".join(params))
    cw.write("return __call__(new PyObject[] { %s });" % ", ".join(args))
    cw.exit_block()

def gen_invoke_meth(nargs, cw):
    params = ["PyObject arg%d" % i for i in range(nargs)]
    args = ["arg%d" % i for i in range(nargs)]
    params.insert(0, "PyString name")
    cw.enter_block("public virtual PyObject invoke(%s)" %
                   ", ".join(params))
    cw.write("return __getattr__(name).__call__(%s);" %
             ", ".join(args))
    cw.exit_block()

def gen_methods(cw):
    cw.write("public const int MAX_CALL_ARGS = %s;" % MAX_ARGS)
    
    for nparams in range(MAX_ARGS+1):
        gen_call_meth(nparams, cw)
        
    for nparams in range(MAX_ARGS+1):
        gen_invoke_meth(nparams, cw)

CodeGenerator("__call__ methods", gen_methods).doit()


def gen_targets(cw):
    for nargs in range(MAX_ARGS+1):
        cw.write("public PyCallTarget%d target%d;" % (nargs, nargs))

        params = ["PyObject arg%d" % i for i in range(nargs)]
        args = ["arg%d" % i for i in range(nargs)]
        cw.enter_block("public override PyObject __call__(%s)" %
                       ", ".join(params))
        cw.write("if (target%d != null) return target%d(%s);" %
                 (nargs, nargs, ", ".join(args)))
        cw.write("else if (targetN != null) return targetN(new PyObject[]{%s});" %
                 ", ".join(args))
        cw.write("else throw badArgCount(%d);" % nargs)
        cw.exit_block()

    cw.enter_block("public override PyObject __call__(params PyObject[] args)")
    #cw.write("if (targetN != null) return targetN(args);")
    cw.enter_block("switch(args.Length)")
    for nargs in range(MAX_ARGS+1):
        cw.write("case %d: return __call__(%s);" %
                 (nargs, ", ".join(["args[%d]" % i for i in range(nargs)])))
    cw.write("default: if (targetN != null) return targetN(args);")
    cw.write("         else throw badArgCount(args.Length);")

    cw.exit_block()
    

    cw.exit_block()
        
CodeGenerator("PyBuiltinFunction targets", gen_targets).doit()


def gen_delegates(cw):
    for nargs in range(MAX_ARGS+1):
        cw.write("case %d: target%d=(PyCallTarget%d)Delegate.CreateDelegate(typeof(PyCallTarget%d), mi); break;" %
                 (nargs, nargs, nargs, nargs))

CodeGenerator("PyBuiltinFunction delegates", gen_delegates).doit()



def gen_frameCall(cw, nargs):
    cw.enter_block("public override PyObject __call__(%s)" % ", ".join(["PyObject arg%d" % i for i in range(nargs)]))
    cw.write("PyFrame frame = new PyFrame(locals);")
    for i in range(nargs):
        cw.write("frame.f%d = arg%d;" % (i, i))
    cw.write("if (argCount != %d) setDefaults(frame, %d);" % (nargs, nargs))

    cw.write("Context context = getContext();")
    cw.write("PyFrame parent = context.frame; context.frame = frame;")
    cw.write("frame.parent = parent; context.depth++;")
    cw.write("try { return target(frame); }")
    cw.write("finally { context.frame = parent; context.depth--; }")
    
    #cw.write("return target(frame);")
    cw.exit_block()
    

def gen_frameCalls(cw):
    for i in range(MAX_ARGS):
        gen_frameCall(cw, i)
    

CodeGenerator("PyFrameFunction calls", gen_frameCalls).doit()

