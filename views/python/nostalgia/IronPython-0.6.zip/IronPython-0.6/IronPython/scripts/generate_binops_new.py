#####################################################################
# Copyright (c) 2003, 2004 Jim Hugunin
# All rights reserved. 
# This program and the accompanying materials are made available 
# under the terms of the Common Public License v1.0 
# which accompanies this distribution and is available at 
# http://www.eclipse.org/legal/cpl-v10.html 
#  
# Contributors: 
#     Jim Hugunin     initial implementation 
#####################################################################
import generate
reload(generate)
from generate import CodeGenerator, CodeWriter

binaries = [('+', 'add', 4, 'Add'), ('-', 'sub',4,'Subtract'), ('**', 'pow', 6,'Power'), ('*', 'mul', 5,'Multiply'),
            ('/', 'floordiv', 5, 'FloorDivide'), ('///', 'div', 5, 'TrueDivide'),
            ('%', 'mod', 5, 'Mod'), ('<<', 'lshift', 3, 'LeftShift'), ('>>', 'rshift', 3, 'RightShift'),
            ('&', 'and', 2, 'BitwiseAnd'), ('|', 'or', 0, 'BitwiseOr'), ('^', 'xor', 1, 'Xor')]


##binaries = [('+', 'add', 4), ('-', 'sub',4), ('**', 'pow', 6), ('*', 'mul', 5),
##            ('/', 'floordiv', 5), ('///', 'truediv', 5),
##            ('%', 'mod', 5), ('<<', 'lshift', 3), ('>>', 'rshift', 3),
##            ('&', 'and', 2), ('|', 'or', 0), ('^', 'xor', 1),
##            ]

base_code = """
public static object %(name)s(%(type)s x, object other) {
    if (other is int) return x %(sym)s ((int)other);
    if (other is long) return x %(sym)s ((long)other);
    if (other is Complex64) return x %(sym)s  ((Complex64)other);
    if (other is double) return x %(sym)s  ((double)other);
    if (other is integer) return x %(sym)s  ((integer)other);
    return Ops.NotImplemented;
}
"""

base_code_m = """
public static object %(name)s(%(type)s x, object other) {
    if (other is int) return %(name)s(x , ((int)other));
    if (other is long) return %(name)s(x , ((long)other));
    if (other is Complex64) return %(name)s(x , ((Complex64)other));
    if (other is double) return %(name)s(x ,((double)other));
    if (other is integer) return %(name)s(x , ((integer)other));
    return Ops.NotImplemented;
}
"""


##long_code = """
##public static object %(name)s(integer x, object other) {
##    if (other is integer) return x %(sym)s (integer)other;
##    if (other is int) return x %(sym)s (int)other;
##    return Ops.NotImplemented;
##}
##"""

long_int_code = """
public static object %(name)s(integer x, object other) {
    if (other is int) return x %(sym)s (int)other;
    return Ops.NotImplemented;
}
"""
long_code_integers = """
public static object %(name)s(integer x, object other) {
    if (other is integer) return x %(sym)s (integer)other;
    if (other is int) return x %(sym)s (int)other;
    return Ops.NotImplemented;
}
"""

long_code_m = """
public static object %(name)s(integer x, object other) {
    if (other is int) return %(name)s(x, (int)other);
    return Ops.NotImplemented;
}
"""

##float_code = """
##public static object %(name)s(double x, object other) {
##    if (other is double) return x %(sym)s ((double)other);
##    if (other is int) return x %(sym)s (double) ((int)other);
##    return Ops.NotImplemented;
##}
##"""
##
##float_code_m = """
##public static object %(name)s(double x, object other) {
##    if (other is double) return %(name)s(x, ((double)other));
##    if (other is int) return %(name)s(x, (double) ((int)other));
##    return Ops.NotImplemented;
##}
##"""
##
##
##complex_code = """
##public static object %(name)s(Complex64 x, object other) {
##    if (other is Complex64) return x %(sym)s ((Complex64)other);
##    if (other is double) return x %(sym)s ((double)other);
##    if (other is int) return x %(sym)s (double) ((int)other);
##    if (other is integer) return x %(sym)s (double) ((integer)other);
##    return Ops.NotImplemented;
##}
##"""
##
##complex_code_m = """
##public static object %(name)s(Complex64 x, object other) {
##    if (other is Complex64) return x.%(name)s((Complex64)other);
##    if (other is double) return x.%(name)s((double)other);
##    if (other is int) return x.%(name)s((double) ((int)other));
##    if (other is integer) return x.%(name)s((double) ((integer)other));
##    return Ops.NotImplemented;
##}
##"""


int_code = """
public static object %(name)s(%(type)s x, object other) {
    if (other is int) {
        int y = (int)other;
        try {
            return Ops.%(type)s2object(checked(x %(sym)s y));
        } catch (OverflowException) {
            return integer.make(x) %(sym)s y; //(%(nextType)s)x %(sym)s y;
        }
    } else if (other is long) {
        long y = (long)other;
        try {
            return checked(x %(sym)s y);
        } catch (OverflowException) {
            return integer.make(x) %(sym)s y;
        }
    } else if (other is integer) {
        return integer.make(x) %(sym)s (integer)other;
    } else if (other is double) {
        return x %(sym)s (double)other;
    } else if (other is Complex64) {
        return Complex64.MakeReal(x) %(sym)s (Complex64)other;
    }
    return Ops.NotImplemented;
}
"""

int_code_integers = """
public static object %(name)s(%(type)s x, object other) {
    if (other is int) {
        int y = (int)other;
        try {
            return Ops.%(type)s2object(checked(x %(sym)s y));
        } catch (OverflowException) {
            return integer.make(x) %(sym)s y;
        }
    } else if (other is long) {
        long y = (long)other;
        try {
            return checked(x %(sym)s y);
        } catch (OverflowException) {
            return integer.make(x) %(sym)s y;
        }
    } else if (other is integer) {
        return integer.make(x) %(sym)s (integer)other;
    }
    return Ops.NotImplemented;
}
"""

int64_code_m = """
public static object %(name)s(long x, object other) {
    return Ops.NotImplemented;
}
"""


##int_code = """
##public static object %(name)s(int x, object other) {
##    if (other is int) {
##        int y = (int)other;
##        try {
##            return Ops.int2object(checked(x %(sym)s y));
##        } catch (OverflowException) {
##            return integer.make(x) %(sym)s y;
##        }
##    } else if (other is double) {
##        return x %(sym)s (double)other;
##    } else if (other is integer) {
##        return integer.make(x) %(sym)s (integer)other;
##    } else if (other is Complex64) {
##        return Complex64.MakeReal(x) %(sym)s (Complex64)other;
##    }
##    return Ops.NotImplemented;
##}
##"""
##int_code_integers = """
##public static object %(name)s(int x, object other) {
##    if (other is int) {
##        int y = (int)other;
##        try {
##            return Ops.int2object(checked(x %(sym)s y));
##        } catch (OverflowException) {
##            return integer.make(x) %(sym)s y;
##        }
##    } else if (other is integer) {
##        return integer.make(x) %(sym)s (integer)other;
##    }
##    return Ops.NotImplemented;
##}
##"""
int_code_pure = """
public static object %(name)s(%(type)s x, object other) {
    if (other is int) {
        int y = (int)other;
        try {
            return Ops.%(type)s2object(checked(x %(sym)s y));
        } catch (OverflowException) {
            return integer.make(x) %(sym)s y;
        }
    }
    return Ops.NotImplemented;
}
"""


int_code_m = """
public static object %(name)s(int x, object other) {
    if (other is int) {
        return %(name)s(x, (int)other);
    }
    return Ops.NotImplemented;
}
"""


bad_syms = ( ) #['//']
im_syms = ('**', '///',)

i_syms = ('<<', '>>')
any_integer_syms = ('&', '|', '^')
integer_syms =  any_integer_syms + i_syms

class GenFuncs:
    def __init__(self, tname, sym_map, default_template, default_div='TrueDivide', swap_syms = {}):
        self.tname = tname
        self.default_div = default_div
        self.swap_syms = swap_syms
        self.sym_map = {}
        for sym, name, prec, cname in binaries:
            self.sym_map[sym] = default_template
        
        for sym_list, template in sym_map.items():
            for sym in sym_list:
                self.sym_map[sym] = template
        print self.sym_map
        if tname == 'int': self.nextType = 'long'
        else: self.nextType = 'integer'

    def __call__(self, cw):
        for sym, name, prec,cname in binaries:
            sym = self.swap_syms.get(sym, sym)
            template = self.sym_map[sym]
            if template is not None:
                cw.write(template, name=cname, sym=sym, type=self.tname, nextType=self.nextType)
        #cw.write(div_code, name=self.default_div)
        #cw.write(self.tail)
                
        
CodeGenerator("LongOps", GenFuncs('integer', {bad_syms:None, im_syms:long_code_m,
                                         i_syms:long_int_code, any_integer_syms:long_code_integers}, base_code,
                                        default_div='FloorDivide')).doit()


CodeGenerator("IntOps", GenFuncs('int', {bad_syms:None, im_syms:int_code_m, any_integer_syms:int_code_integers,
                                  i_syms:int_code_pure}, int_code,
                                           default_div='FloorDivide')).doit()

CodeGenerator("Int64Ops", GenFuncs('long', {bad_syms:None, im_syms:int64_code_m, any_integer_syms:int_code_integers,
                                            i_syms:int_code_pure}, int_code,
                                           default_div='FloorDivide')).doit()

CodeGenerator("FloatOps", GenFuncs('double', {bad_syms+integer_syms:None, im_syms:base_code_m},
                                        base_code)).doit()

CodeGenerator("ComplexOps", GenFuncs('Complex64', {bad_syms+integer_syms:None, im_syms:base_code_m},
                                        base_code, swap_syms={'///':'/'})).doit()

 

