#####################################################################
# Copyright (c) 2003, 2004 Jim Hugunin
# All rights reserved. 
# This program and the accompanying materials are made available 
# under the terms of the Common Public License v1.0 
# which accompanies this distribution and is available at 
# http://www.eclipse.org/legal/cpl-v10.html 
#  
# Contributors: 
#     Jim Hugunin     initial implementation 
#####################################################################
import generate
reload(generate)
from generate import CodeGenerator, CodeWriter

binaries = [('+', 'add', 4), ('-', 'sub',4), ('**', 'pow', 6), ('*', 'mul', 5),
            ('/', 'floordiv', 5), ('///', 'truediv', 5),
            ('%', 'mod', 5), ('<<', 'lshift', 3), ('>>', 'rshift', 3),
            ('&', 'and', 2), ('|', 'or', 0), ('^', 'xor', 1),
            ]


long_code = """
public override PyObject __%(name)s__(PyObject other) {
        PyLong ol = other as PyLong;
        if (ol != null) { return make(_value %(sym)s ol._value); }
        PyInteger oi = other as PyInteger;
        if (oi != null) { return make(_value %(sym)s oi.value); }
        return Py.NotImplemented;
}

public override PyObject __r%(name)s__(PyObject other) {
        PyInteger oi = other as PyInteger;
        if (oi != null) { return make(oi.value %(sym)s _value); }
        return Py.NotImplemented;
}
"""

float_code = """
public override PyObject __%(name)s__(PyObject other) {
        double o;
        if (Py.checkDouble(other, out o)) return make(_value %(sym)s o);
        return Py.NotImplemented;
}

public override PyObject __r%(name)s__(PyObject other) {
        double o;
        if (Py.checkDouble(other, out o)) return make(o %(sym)s _value);
        return Py.NotImplemented;
}
"""

float_code_m = """
public override PyObject __%(name)s__(PyObject other) {
        double o;
        if (Py.checkDouble(other, out o)) return %(name)s(_value, o);
        return Py.NotImplemented;
}

public override PyObject __r%(name)s__(PyObject other) {
        double o;
        if (Py.checkDouble(other, out o)) return %(name)s(o, _value);
        return Py.NotImplemented;
}
"""


long_int_code = """
public override PyObject __%(name)s__(PyObject other) {
        PyInteger oi = other as PyInteger;
        if (oi != null) return make(_value %(sym)s oi.value);
        return Py.NotImplemented;
}
"""

int_code = """
public override PyObject __%(name)s__(PyObject other) {
        PyInteger oi = other as PyInteger;
        if (oi != null) {
            try {
                return make(checked(_value %(sym)s oi.value));
            } catch (OverflowException) {
                return PyLong.make(_value).__%(name)s__(oi);
            }
        }
        return Py.NotImplemented;
}
"""

int_code_m = """
public override PyObject __%(name)s__(PyObject other) {
        PyInteger oi = other as PyInteger;
        if (oi != null) { return %(name)s(_value, oi.value); }
        return Py.NotImplemented;
}
"""

simple_code = """
public override PyObject __not__() {
        return PyBoolean.make(!__nonzero__());
}

public override bool __nonzero__() {
        return _value != 0;
}

public override PyObject __pos__() {
        return this;
}
"""

simple_neg = """
public override PyObject __neg__() {
        return make(-_value);
}
"""
checked_neg = """
public override PyObject __neg__() {
        if (_value == int.MinValue) return PyLong.make( -(long)_value );
        else return make(-_value);
}
"""


div_code = """
public override PyObject __div__(PyObject other) { return __%(name)s__(other); }
public override PyObject __rdiv__(PyObject other) { return __r%(name)s__(other); }
"""


bad_syms = ( ) #['//']
im_syms = ('**', '///',)

i_syms = ('<<', '>>')
integer_syms = ('&', '|', '^') + i_syms

class GenFuncs:
    def __init__(self, sym_map, default_template, default_div='truediv', tail=simple_code+simple_neg):
        self.tail = tail
        self.default_div = default_div
        self.sym_map = {}
        for sym, name, prec in binaries:
            self.sym_map[sym] = default_template
        
        for sym_list, template in sym_map.items():
            for sym in sym_list:
                self.sym_map[sym] = template
        print self.sym_map

    def __call__(self, cw):
        for sym, name, prec in binaries:
            template = self.sym_map[sym]
            if template is not None:
                cw.write(template, name=name, sym=sym)
        cw.write(div_code, name=self.default_div)
        cw.write(self.tail)
                
        
CodeGenerator("PyLong binops", GenFuncs({bad_syms:None, im_syms:int_code_m,
                                         i_syms:long_int_code}, long_code,
                                        default_div='floordiv')).doit()


CodeGenerator("PyInteger binops", GenFuncs({bad_syms:None, im_syms:int_code_m}, int_code,
                                           default_div='floordiv',
                                           tail=simple_code+checked_neg)).doit()

CodeGenerator("PyFloat binops", GenFuncs({bad_syms+integer_syms:None, im_syms:float_code_m},
                                        float_code)).doit()


 

