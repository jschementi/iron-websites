#####################################################################
# Copyright (c) 2003, 2004 Jim Hugunin
# All rights reserved. 
# This program and the accompanying materials are made available 
# under the terms of the Common Public License v1.0 
# which accompanies this distribution and is available at 
# http://www.eclipse.org/legal/cpl-v10.html 
#  
# Contributors: 
#     Jim Hugunin     initial implementation 
#####################################################################
import generate
reload(generate)
from generate import CodeGenerator, CodeWriter, src_dir

MAX_ARGS = 7

import os, re, string

meth_pat = r"(?P<ret_type>\w+)\s+(?P<name>\w+)\s*\((?P<params>(?:\w|\s|,|\[|\])*)\)"
meth_pat = re.compile(r"public\s+(?P<mods>static\s+)?(virtual\s+)?"+meth_pat)

field_pat = r"(?P<type>\w+)\s+(?P<name>@?\w+)\s*[=;]"
field_pat = re.compile(r"public\s+(?P<mods>static\s+)?(readonly\s+)?"+field_pat)


class_pat = re.compile(r"public\s+(abstract\s+)?class\s+(?P<name>@?\w+)\s*(:\s*(?P<super_name>\w+))?")

from_table = {
    'int':"Py.asInt(%s)",
    'double':"Py.asDouble(%s)",
    'char':"Py.asChar(%s)",
    'string':"Py.asString(%s)",
    'integer':"Py.asInteger(%s)",
    'bool':"Py.asBool(%s)",
    'PyObject':"%s",
}

def from_any(totype, name):
    pat = from_table.get(totype, None)
    if pat is None:
        return "%s.checkCast(%s)" % (totype, name)
    else:
        return pat % name

to_table = {
    'int':"PyInteger.make(%s)",
    'double':"PyFloat.make(%s)",
    'bool':"PyBoolean.make(%s)",
    'char':"PyString.make(%s)",
    'string':"PyString.make(%s)",
    'PyObject':"%s",
}

def to_any(totype, name):
    pat = to_table.get(totype, None)
    if pat is None:
        return name #"(%s)%s" % (totype, name)
    else:
        return pat % name

BINOP = """
public override PyObject __%(name)s__(PyObject other) {
    %(type)s ov;
    if (!Py.check%(ctype)s(other, out ov)) return Py.NotImplemented;
    return %(ret_type)s.make(%(name)s(_value, ov));
}
public override PyObject __r%(name)s__(PyObject other) {
    %(type)s ov;
    if (!Py.check%(ctype)s(other, out ov)) return Py.NotImplemented;
    return %(ret_type)s.make(%(name)s(ov, _value));
}
"""

UNOP = """
public override PyObject __%(name)s__() {
    return %(ret_type)s.make(%(name)s(_value));
}
"""

top_names = ['keys']

class Field:
    def __init__(self, type, name, mods=None):
        self.type = type
        self.name = name
        self.mods = mods

    def get_visible_name(self):
        if self.name[0] == '@': return self.name[1:]
        else: return self.name

    def __repr__(self):
        return "Field(%s, %s, %s)" % (self.type, self.name, self.mods)


class Method:
    def __init__(self, ret_type, name, params, mods=None):
        self.param_list = map(lambda s: s.strip(), string.split(params, ","))
        self.param_list = filter(lambda s: s, self.param_list)
        self.ret_type = ret_type
        self.name = name
        self.mods = mods
        self.is_invokable = True

    def get_visible_name(self):
        if self.name[0] == '@': return self.name[1:]
        else: return self.name

    def get_py_name(self):
        if self.is_any_params() and not self.is_any():
            return self.name + "__pym"
        else:
            return self.name

    def is_varargs(self):
        return len(self.param_list) == 1 and self.param_list[0].startswith('params')

    def is_any_params(self):
        #print self.param_list
        if self.is_varargs():
            return True
        for p in self.param_list:
            if not p.startswith(ANY): return False
        return True

    def is_any(self):
        if self.ret_type != ANY: return False
        return self.is_any_params()
        
    def is_static(self):
        return self.mods is not None

    def is_internal(self):
        return (self.name in top_names or
            (self.name.endswith("__") and self.name != '__new__'
             and self.name != '__import__'))

    """
    def make_op(self, cw):
        self.is_invokable = False
        type = self.param_list[0].split(" ")[0]
        dict = {
            'name':self.get_py_name(),
            'type':type,
            'ctype':type.capitalize(),
            'ret_type':.split('.')[0]
            }

        if len(self.param_list) == 2:
            cw.write(BINOP % dict)
        else:
            cw.write(UNOP % dict)
    """


    def make_static(self, cw, intype):
        if self.is_varargs(): return # need to do better
        
        name = self.name + "__pysm"

        params = ["PyObject self"]
        args = []
        for p in self.param_list:
            ptype, pname = string.split(p)            
            args.append(pname)
            params.append("PyObject %s" % pname)
        
        cw.enter_block("public static PyObject %s(%s)" % (name, string.join(params, ", ")))
        
        value = "(%s).%s(%s)" % (from_any(intype, "self"), self.get_py_name(), string.join(args, ", "))
        cw.write("return %s;" % value)

        cw.exit_block()

    def make_any(self, cw, in_module=False):
        if not in_module and self.is_static() and self.name != '__new__':
            print 'skipping', self.name
            return #self.make_op(cw)
        
        name = self.get_py_name()

        params = []
        args = []
        for p in self.param_list:
            #print p
            ptype, pname = string.split(p)                
            args.append(from_any(ptype, pname))
            params.append("PyObject %s" % pname)

        if self.is_internal():
            mods = "override "
            self.is_invokable = False
        else:
            mods = ""

        if self.is_static():
            mods += "static "
        
        cw.enter_block("public %sPyObject %s(%s)" % (mods, name, string.join(params, ", ")))
        if self.ret_type == 'void':
            cw.write("%s(%s);" % (self.name, string.join(args, ", ")))
            cw.write("return Py.None;")
        else:
            value = "%s(%s)" % (self.name, string.join(args, ", "))
            cw.write("return %s;" % to_any(self.ret_type, value))

        cw.exit_block()

    def __repr__(self):
        return "Method(%s, %s, %s)" % (self.ret_type, self.name, self.param_list)

class Class:
    def __init__(self, name, super_name, methods, fields):
        self.name = name
        self.super_name = super_name
        self.methods = methods
        self.fields = fields
        self.strings = {}

    def get_constant_string(self, s):
        if not self.strings.has_key(s):
            self.strings[s] = s + "_str"

        return self.strings[s]

    def make_attrs(self, cw):
        if not self.fields: return

        if self.super_name == 'PyBuiltinModule':
            cw.enter_block("public override bool __getattr__(PyString name, out PyObject ret)")
            #cw.enter_block("if (name.interned)")
            cw.write("name = name.intern();")
            for field in self.fields:
                cw.write("if ((object)name == (object)%s) { ret=%s; return true; }" %
                         (self.get_constant_string(field.get_visible_name()),
                          to_any(field.type, field.name)))
            #cw.exit_block()
            cw.write("return base.__getattr__(name, out ret);")
            cw.exit_block()
        else:
            cw.enter_block("public override bool __getattr__(PyString name, out PyObject ret)")
            #cw.enter_block("if (name.interned)")
            cw.write("name = name.intern();")
            for field in self.fields:
                cw.write("if ((object)name == (object)%s) { ret=%s; return true; }" %
                         (self.get_constant_string(field.get_visible_name()),
                          to_any(field.type, field.name)))
            #cw.exit_block()
            cw.write("return base.__getattr__(name, out ret);")
            cw.exit_block()

        cw.enter_block("public override void __setattr__(PyString name, PyObject val)")
        cw.write("name = name.intern();")
        #cw.enter_block("if (name.interned)")
        for field in self.fields:
            cw.write("if ((object)name == (object)%s) { %s = %s; return; }" %
                     (self.get_constant_string(field.get_visible_name()),
                      field.name, from_any(field.type, "val")))
        #cw.exit_block()
        cw.write("base.__setattr__(name, val);")
        cw.exit_block()


    def make_invoke_method(self, out_cw, nargs):
        cw = CodeWriter()
        params = ["PyString name"]
        args = ["name"]
        for i in range(nargs):
            params.append("PyObject arg%d" % i)
            args.append("arg%d" % i)
        cw.enter_block("public override PyObject invoke(%s)" % ", ".join(params))
        #cw.enter_block("if (name.interned)")
        cw.write("name = name.intern();")
        #TODO create switch clause when more than 3-8 matches
        found_match = False
        for method in self.methods:
            if not method.is_invokable or len(method.param_list) != nargs or method.is_varargs():
                continue
            if not self.is_module() and method.is_static():
                continue
            found_match = True
            cw.write("if ((object)name == (object)%s) return %s(%s);" %
                       (self.get_constant_string(method.get_visible_name()), method.get_py_name(),
                        ", ".join(args[1:])))

        if not found_match: return

        #cw.exit_block()
        cw.write("return base.invoke(%s);" % ", ".join(args))
        cw.exit_block()
        
        out_cw.write(cw.text())

    def is_module(self):
        return self.super_name == 'PyBuiltinModule'

    def make_invokeN(self, out_cw):
        cw = CodeWriter()
        cw.enter_block("public override PyObject invoke(PyString name, params PyObject[] args)")
        cw.write("name = name.intern();")
        #TODO create switch clause when more than 3-8 matches
        found_match = False
        for method in self.methods:
            if not method.is_varargs():continue
            found_match = True
            cw.write("if ((object)name == (object)%s) return %s(args);" %
                       (self.get_constant_string(method.get_visible_name()), method.get_py_name()))

        if not found_match: return

        #cw.exit_block()
        cw.write("return base.invoke(name, args);")
        cw.exit_block()
        
        out_cw.write(cw.text())

    def make_any_methods(self, cw):
        mods = "public static readonly"
        if self.super_name not in ["PyObject", "PyIterator"]:
            mods = mods + " new"
        cw.write("%s PyBuiltinType pytype = new PyBuiltinType(typeof(%s));" %
                    (mods, self.name))

        #cw.write("public override PyType __class__ { get { return pytype; } }")
        cw.write("public override PyType get__class__() { return pytype;  }")

        if self.super_name != "PyBuiltinModule":
            mods = "public static"
            if self.super_name not in ["PyObject", "PyIterator"]:
                mods = mods + " new"
            cw.enter_block("%s %s checkCast(PyObject obj)" %
                           (mods, self.name))
            cw.write("%s ret = obj as %s;" % (self.name,self.name))
            cw.write('if (ret == null) throw Py.TypeError("expected {0}, found {1}", pytype.__name__, obj.getClassName());')
            cw.write("return ret;")
            cw.exit_block()

        
        # first generate the any forms of each method
        for method in self.methods:
            if not method.is_any():
                method.make_any(cw, self.is_module())

            if not method.is_static():
                method.make_static(cw, self.name)

        # now generate the various invoke methods
        for i in range(MAX_ARGS):
            self.make_invoke_method(cw, i)

        self.make_invokeN(cw)

        for value, name in self.strings.items():
            cw.write('static readonly PyString %s = PyString.intern("%s");' %
                       (name, value))

    def __repr__(self):
        return "Class(%s, %s)" % (self.name, self.super_name)

def collect_methods(text):
    meths = []
    fields = []
    match= class_pat.search(text)

    if match is None:
        return None
    cl = Class(match.group('name'), match.group('super_name'), meths, fields)
    
    for match in meth_pat.finditer(text):
        meth = Method(**match.groupdict())
        if meth.is_static() and meth.name in ['make', 'intern']: continue
        meths.append(meth)

    for match in field_pat.finditer(text):
        field = Field(**match.groupdict())
        fields.append(field)

    return cl

base = collect_methods(open(os.path.join(src_dir, "Objects/PyObject.cs")).read())
ANY = base.name

def attr_gen(cw):
    c = collect_methods(cw.text)
    assert c is not None and c.name != base.name
    print c, c.methods, c.fields
    c.make_attrs(cw)
    c.make_any_methods(cw)
    
CodeGenerator("Reflected Attributes", attr_gen).doit()

