#####################################################################
# Copyright (c) 2003, 2004 Jim Hugunin
# All rights reserved. 
# This program and the accompanying materials are made available 
# under the terms of the Common Public License v1.0 
# which accompanies this distribution and is available at 
# http://www.eclipse.org/legal/cpl-v10.html 
#  
# Contributors: 
#     Jim Hugunin     initial implementation 
#####################################################################
import os, re, string

src_dir = "..\\"

START = "#region Generated %s"
END =   "#endregion"
PREFIX = r"^([ \t]+)"

class CodeWriter:
    def __init__(self, indent=0):
        self.lines = []
        self.indent = indent

    def writeline(self, text=None):
        if text is None:
            self.lines.append("")
        else:
            self.lines.append("    "*self.indent + text)
        
    def write(self, template, **kw):
        for l in template.split('\n'):
            if kw: self.writeline(l % kw)
            else: self.writeline(l)

    def enter_block(self, text=None, **kw):
        if text is not None:
            self.writeline((text % kw) + " {")
        self.indent += 1

    def exit_block(self):
        self.indent -= 1
        self.writeline('}')

    def text(self):
        return string.join(self.lines, '\n')


class CodeGenerator:
    def __init__(self, name, generator):
        self.generator = generator
        self.generators = []
        self.replacer = BlockReplacer(name)

    def do_file(self, filename):
        g = FileGenerator(filename, self.generator, self.replacer)
        if g.has_match:
            self.generators.append(g)

    def do_generate(self):
        if not self.generators:
            raise "didn't find a match for %s" % self.replacer.name
        for g in self.generators:
            g.generate()
        
    def do_dir(self, dirname):
        for file in os.listdir(dirname):
            filename = os.path.join(dirname, file)
            if os.path.isdir(filename):
                self.do_dir(filename)
            elif filename.endswith(".cs"):
                self.do_file(filename)

    def doit(self):
        self.do_dir(src_dir)
        for g in self.generators:
            g.collect_info()
        self.do_generate()

class BlockReplacer:
    def __init__(self, name):
        self.start = START % name
        self.end = END# % name
        self.block_pat = re.compile(PREFIX+self.start+".*?"+self.end,
                                    re.DOTALL|re.MULTILINE)
        self.name = name

    def match(self, text):
        m = self.block_pat.search(text)
        if m is None: return None
        indent = m.group(1)
        return indent

    def replace(self, cw, text, indent):
        code = cw.lines
        code.insert(0, self.start)
        code.append(self.end)
        code_text = indent + ("\n"+indent).join(code)
        return self.block_pat.sub(code_text, text)
        

class FileGenerator:
    def __init__(self, filename, generator, replacer):
        self.filename = filename
        self.generator = generator
        self.replacer = replacer

        self.text = open(filename).read()
        self.indent = self.replacer.match(self.text)
        self.has_match = self.indent is not None

    def collect_info(self):
        pass

    def generate(self):
        cw = CodeWriter()
        cw.text = self.replacer.replace(CodeWriter(), self.text, self.indent)
        self.generator(cw)
        new_text = self.replacer.replace(cw, self.text, self.indent)
        if self.text != new_text:
            open(self.filename, 'w').write(new_text)

