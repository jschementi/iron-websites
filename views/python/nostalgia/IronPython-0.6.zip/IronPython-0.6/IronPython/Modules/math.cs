/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using IronPython.Objects;
using IronMath;


namespace IronPython.Modules {
	public class math {
		public static double pi = Math.PI;
		public static double e = Math.E;

		private static double check(double v) {
			if (double.IsInfinity(v)) {
				throw Ops.ValueError("math range error");
			} else if (double.IsNaN(v)) {
				throw Ops.ValueError("math domain error");
			} else {
				return v;
			}
		}

		private const double degreesToRadians = Math.PI / 180.0;
		public static double degrees(double radians) {
			return check(radians/degreesToRadians);
		}

		public static double radians(double degrees) {
			return check(degrees*degreesToRadians);
		}

		public static double fmod(double v, double w) {
			return v % w;
		}

		public static Tuple modf(double v) {
			double w = v % 1.0;
			v -= w;
			return Tuple.MakeTuple(w, v);
		}

		public static double ldexp(double v, int w) {
			return check(v * Math.Pow(2.0, w));
		}

		public static double hypot(double v, double w) {
			return check(IronMath.Complex64.Hypot(v, w));
		}


		#region Generated math functions
		public static double acos(double v0) {
		    return check(Math.Acos(v0));
		}
		public static double asin(double v0) {
		    return check(Math.Asin(v0));
		}
		public static double atan(double v0) {
		    return check(Math.Atan(v0));
		}
		public static double atan2(double v0, double v1) {
		    return check(Math.Atan2(v0, v1));
		}
		public static double ceil(double v0) {
		    return check(Math.Ceiling(v0));
		}
		public static double cos(double v0) {
		    return check(Math.Cos(v0));
		}
		public static double cosh(double v0) {
		    return check(Math.Cosh(v0));
		}
		public static double exp(double v0) {
		    return check(Math.Exp(v0));
		}
		public static double fabs(double v0) {
		    return check(Math.Abs(v0));
		}
		public static double floor(double v0) {
		    return check(Math.Floor(v0));
		}
		public static double log(double v0) {
		    return check(Math.Log(v0));
		}
		public static double log(double v0, double v1) {
		    return check(Math.Log(v0, v1));
		}
		public static double log10(double v0) {
		    return check(Math.Log10(v0));
		}
		public static double pow(double v0, double v1) {
		    return check(Math.Pow(v0, v1));
		}
		public static double sin(double v0) {
		    return check(Math.Sin(v0));
		}
		public static double sinh(double v0) {
		    return check(Math.Sinh(v0));
		}
		public static double sqrt(double v0) {
		    return check(Math.Sqrt(v0));
		}
		public static double tan(double v0) {
		    return check(Math.Tan(v0));
		}
		public static double tanh(double v0) {
		    return check(Math.Tanh(v0));
		}
		#endregion
	}
}
