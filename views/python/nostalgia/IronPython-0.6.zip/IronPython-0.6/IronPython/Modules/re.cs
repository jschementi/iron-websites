/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Text.RegularExpressions;

using IronPython.Objects;



namespace IronPython.Modules {
	public class re {
		public static RE_Pattern compile(string pattern) {
			return new RE_Pattern(pattern);
		}

		public static string escape(string text) {
			return Regex.Escape(text);
		}

		public class RE_Pattern {
			private Regex re, matchRe;

			public RE_Pattern(string pattern) { this.re = new Regex(pattern); this.matchRe = new Regex("\\A" + pattern); }

			public RE_Match match(string text) {
				return RE_Match.make(matchRe.Match(text));  
			}

			public RE_Match match(string text, int pos) {  
				return RE_Match.make(matchRe.Match(text, pos));
			}

			public RE_Match search(string text) {
				return RE_Match.make(re.Match(text));
			}

			public string sub(string repl, string text) {
				return re.Replace(text, repl);
			}
		}

		public class RE_Match {
			internal static RE_Match make(Match m) {
				if (m.Success) return new RE_Match(m);
				else return null;
			}

			private Match m;

			public RE_Match(Match m) { this.m = m; }

//			public override bool __nonzero__() {
//				return m.Success;
//			}

			public int end() {
				return m.Index+m.Length;
			}

			public int start() {
				return m.Index;
			}

			public int start(int group) {
				return m.Groups[group].Index;
			}

			public int end(int group) {
				return m.Groups[group].Index + m.Groups[group].Length;
			}

			public object group(int index) {
				return m.Groups[index].Value;
			}

			public object groups() {
				object[] ret = new object[m.Groups.Count-1];
				for (int i=1; i < m.Groups.Count; i++) {
					ret[i-1] = Ops.ToPython(m.Groups[i].Value); //!!! don't like this one bit
				}
				return Ops.MakeTuple(ret);
			}
		}
	}
}
