/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Collections;

using IronPython.Objects;
using IronPython.AST;

using IronMath;

namespace IronPython.Modules {
	public class __builtin__ {
		public static object True = Ops.bool2object(true);
		public static object False = Ops.bool2object(false);

		public static object None = null;
		public static object Ellipsis = Ops.Ellipsis;
		public static object NotImplemented = Ops.NotImplemented;

		public static object exit = "Use Ctrl-Z plus Return to exit";
		public static object quit = "Use Ctrl-Z plus Return to exit";

	
//		public static PyObject __import__(PyString name) {
//			return Py.importTop(null, name);
//		}

		public static object abs(object o) {
			if (o is int) return IntOps.Abs((int)o);
			else if (o is long) return Int64Ops.Abs((long)o);
			else if (o is double) return FloatOps.Abs((double)o);
			else if (o is integer) return LongOps.Abs((integer)o);
			else if (o is Complex64) return ComplexOps.Abs((Complex64)o);

			return Ops.Invoke(o, "__abs__");
		}

		public static object apply(object func, object args) {
			return Ops.CallWithArgsTuple(func, new object[0], args);
		}

//		public static object apply(object func, object args, object kws) {
//			return func.__call__(new PyObject[0], new PyString[0], args, kws);
//		}

		public static object basestring = Ops.GetDynamicTypeFromType(typeof(string)); //!!! more unicode "unification"

		public static object @bool = Ops.GetDynamicTypeFromType(typeof(bool));
		
		/*
		public static PyObject buffer = Py.None; //!!! todo

		public static bool callable(PyObject o) {
			return hasattr(o, Names.__call__);
		}

		*/
		public static string chr(int value) {
			return Ops.char2string((char)value);
		}

		public static object compile(string source, string filename, string kind) {
			Parser p =Parser.fromString(source);
			Stmt s = p.parseStmt(); //???
			FrameCode code = SnippetMaker.generate(s, filename);

			return code;
		}

		public static object classmethod = Ops.GetDynamicTypeFromType(typeof(ClassMethod));

		public static int cmp(object x, object y) {
			return Ops.Compare(x, y);
		}

		public static object complex = Ops.GetDynamicTypeFromType(typeof(Complex64));

		//!!! coerce, compile

		public static void delattr(object o, string name) {
			Ops.DelAttr(o, name);
		}

		public static object dict = Ops.GetDynamicTypeFromType(typeof(Dict));

		public static List dir() {
			return dir(module.LookupModuleOnStack());
		}

		public static List dir(object o) {
			return Ops.GetAttrNames(o);
		}

		//!!! Python has lots of optimizations for this
		public static Tuple divmod(object x, object y) {
			return Tuple.MakeTuple( Ops.Divide(x, y), Ops.Mod(x, y) );
		}

		public static object enumerate = Ops.GetDynamicTypeFromType(typeof(Enumerate));

		public static object eval(string expression) {
			return eval(expression, (IDictionary)globals());
		}

		public static object eval(string expression, IDictionary globals) {
			return eval(expression, globals, globals);
		}

		public static object eval(string expression, IDictionary globals, IDictionary locals) {
			Parser p = Parser.fromString(expression);
			Expr e = p.parseTest();

			module mod = new module();
			mod.__dict__ = globals;

			if (Options.FastEval) {//!!! experimenting with a HUGE (>100x) performance boost to simple evals
				return e.Evaluate(new NameEnv(mod, locals));
			} else {
				Stmt s = new ReturnStmt(e);
				FrameCode fc = SnippetMaker.generate(s, "eval");
				return fc.Run(new Frame(mod, globals, locals));
			}
		}

//		public static void execfile(string filename, PyObject globals, PyObject locals) {
//			throw new NotImplementedException("execfile");
//		}

//		public static PyObject file = PyFile.pytype;

		public static object filter(object function, object list) {
			//!!! need to optimize the string case some day
			List ret = new List();
			
			IEnumerator i = Ops.GetEnumerator(list);
			while (i.MoveNext()) {
				if (function == null) {
					if (Ops.IsTrue(i.Current)) ret.append(i.Current);
				} else {
					if (Ops.IsTrue(Ops.Call(function, i.Current))) ret.append(i.Current);
				}
			}
//
//			if (list is PyTuple) {
//				return PyTuple.make(ret.toObjectArray());
//			} else if (list is PyString) {
//				throw new NotImplementedException("filter of a string");
//			} else {
//				return ret;
//			}

			return ret;
		}

		public static object @float = Ops.GetDynamicTypeFromType(typeof(double));

		public static object getattr(object o, string name) {
			return Ops.GetAttr(o, name); //???string.Intern(name)); //!!! too expensive
		}

		public static object getattr(object o, string name, object def) {
			object ret;
			if (Ops.GetAttr(o, name, out ret)) return ret; //???string.Intern(name), out ret)) return ret;  //!!! too expensive
			else return def;
		}

		public static object globals() {
			module mod = module.LookupModuleOnStack();
			return mod.__dict__;
		}
		
		public static bool hasattr(object o, string name) {
			object tmp;
			return Ops.GetAttr(o, name, out tmp);
		}

		public static int hash(object o) {
			return Ops.Hash(o);
		}

		public static void help(object o) {
			throw new NotImplementedException("help");
		}

		//??? type this to string
		public static object hex(object o) {
			return Ops.Hex(o);
		}

		public static int id(object o) {
			return Ops.Id(o);
		}

		//!!! input

		public static object @int = Ops.GetDynamicTypeFromType(typeof(int));

		public static string intern(string s) {
			return string.Intern(s);
		}

		public static bool isinstance(object o, object typeinfo) {
			if (o is OldInstance) {
				throw new NotImplementedException();
			} else {
				return issubclass(Ops.GetDynamicType(o), typeinfo);
			}
		}

		public static bool issubclass(DynamicType c, object typeinfo) {
			//Console.WriteLine("checking issubclass {0} of {1}", c, typeinfo);
			Tuple pt = typeinfo as Tuple;
			if (pt == null) {
				return c.IsSubclassOf(typeinfo);
			} else {
				foreach (object o in pt) {
					if (c.IsSubclassOf(o)) return true;
				}
				return false;
			}
		}

		public static IEnumerator iter(object o) {
			return Ops.GetEnumerator(o);
		}

//		public static PyObject iter(PyObject func, PyObject sentinel) {
//			return new PyCallableIterator(func, sentinel);
//		}

		public static int len(object o) {
			string s = o as String;
			if (s != null) return s.Length;

			ISequence seq = o as ISequence;
			if (seq != null) return seq.__len__();

			ICollection ic = o as ICollection;
			if (ic != null) return ic.Count;

			return Ops.object2int(Ops.Invoke(o, "__len__"));
		}


		public static object list = Ops.GetDynamicTypeFromType(typeof(List));

//		public ** static PyDictionary locals() {
//			//!!! how do I get the current frame, without huge overhead!!!
//			throw new NotImplementedException("locals");
//		}

		public static object @long = Ops.GetDynamicTypeFromType(typeof(integer));

		public static List map(object func, object list) {
			List ret = new List();
			IEnumerator i =  Ops.GetEnumerator(list);
			while (i.MoveNext()) {
				if (func == null) ret.Add(i.Current);
				else ret.Add(Ops.Call(func, i.Current));
			}
			return ret;
		}


		public static List map(params object[] lists) {
			if (lists.Length < 2) throw Ops.TypeError("at least 2 arguments required to map");

			if (lists.Length == 2) return map(lists[0], lists[1]);

			List ret = new List();
			object func = lists[0];

			IEnumerator[] enums = new IEnumerator[lists.Length-1];
			for (int i = 0; i < enums.Length; i++) enums[i] = Ops.GetEnumerator(lists[i+1]);

			while (true) {
				object[] item = new object[enums.Length];
				for (int i=0; i < enums.Length; i++) {
					if (!enums[i].MoveNext()) return ret; //???
					item[i] = enums[i].Current;
				}
				ret.append( Tuple.Make(item) );
			}
		}

		public static object max(object x) {
			IEnumerator i = Ops.GetEnumerator(x);
			i.MoveNext();
			object ret = i.Current;
			while (i.MoveNext()) {
				if (Ops.IsTrue(Ops.GreaterThan(i.Current, ret))) ret = i.Current;
			}
			return ret;
		}

		public static object max(object x, object y) {
			return Ops.IsTrue(Ops.GreaterThan(x, y)) ? x : y;
		}

		public static object max(params object[] args) {
			object ret = args[0];
			for (int i=1; i < args.Length; i++) {
				if (Ops.IsTrue(Ops.GreaterThan(args[i], ret))) ret = args[i];
			}
			return ret;
		}

		public static object min(object x) {
			IEnumerator i = Ops.GetEnumerator(x);
			i.MoveNext();
			object ret = i.Current;
			while (i.MoveNext()) {
				if (Ops.IsTrue(Ops.LessThan(i.Current, ret))) ret = i.Current;
			}
			return ret;
		}

		public static object min(object x, object y) {
			return Ops.IsTrue(Ops.LessThan(x, y)) ? x : y;
		}

		public static object Min(params object[] args) {
			object ret = args[0];
			for (int i=1; i < args.Length; i++) {
				if (Ops.IsTrue(Ops.LessThan(args[i], ret))) ret = args[i];
			}
			return ret;
		}


		public static object @object = Ops.GetDynamicTypeFromType(typeof(object));
		
		public static object oct(object o) {
			return Ops.Oct(o);
		}

		/*
		public static PyObject open = PyFile.pytype; // alias for file
		*/

		//!!! should be alias for file type
		public static PythonFile open(string filename, string mode) {
			return PythonFile.Make(filename, mode, -1);
		}

		public static int ord(char value) {
			return (int)value;
		}

		public static object pow(object x, object y) {
			return Ops.Power(x, y);
		}

		public static object pow(object x, object y, object z) {
			return Ops.PowerMod(x, y, z);
		}

		public static object property = Ops.GetDynamicTypeFromType(typeof(Property));
		
		public static object range(int stop) {
			List ret = List.MakeEmptyList(stop);
			for (int i=0; i < stop; i++) ret.Add(Ops.int2object(i));
			return ret;
		}

		public static object range(int start, int stop) {
			List ret = List.MakeEmptyList(stop-start);
			for (int i=start; i < stop; i++) ret.Add(Ops.int2object(i));
			return ret;
		}

		public static object range(int start, int stop, int step) {
			if (step == 0) throw Ops.ValueError("step of 0");
			int n = (stop-start)/step;
			List ret = List.MakeEmptyList(n);
			for (int i=start; i < stop; i+=step) ret.Add(Ops.int2object(i));
			return ret;
		}

		//!!! raw_input

		public static object reduce(object func, object seq) {
			IEnumerator i = Ops.GetEnumerator(seq);
			i.MoveNext();
			object ret = i.Current;
			while (i.MoveNext()) {
				ret = Ops.Call(func, ret, i.Current);
			}
			return ret;
		}

		public static object reduce(object func, object seq, object initializer) {
			IEnumerator i = Ops.GetEnumerator(seq);
			object ret = initializer;
			while (i.MoveNext()) {
				ret = Ops.Call(func, ret, i.Current);
			}
			return ret;
		}
		
		//!!!reload

		public static object repr(object o) {
			return Ops.StringRepr(o);  //!!! error checking that this is a string
		}

		public static double round(double x) {
			return Math.Round(x);
		}

		public static double round(double x, int n) {
			if (n < 0) { //!!! certinaly imprecise
				double factor = Math.Pow(10.0, -n);
				return factor*Math.Round(x/factor);
			}
			return Math.Round(x, n);
		}

		public static void setattr(object o, string name, object val) {
			Ops.SetAttr(o, name, val);
		}

		public static object slice = Ops.GetDynamicTypeFromType(typeof(Slice));

		public static object staticmethod = Ops.GetDynamicTypeFromType(typeof(StaticMethod));
		
		public static object sum(object sequence) {
			return sum(sequence, 0);
		}
			
		public static object sum(object sequence, object start) {
			IEnumerator i = Ops.GetEnumerator(sequence);
			object ret = start;
			while (i.MoveNext()) {
				ret = Ops.Add(ret, i.Current);
			}
			return ret;
		}

		public static object super = Ops.GetDynamicTypeFromType(typeof(Super));
			
		public static object str = Ops.GetDynamicTypeFromType(typeof(string));
		//???
		public static object nstr = Ops.GetDynamicTypeFromType(typeof(Str));


		public static object tuple = Ops.GetDynamicTypeFromType(typeof(Tuple));

		public static object type = Ops.GetDynamicTypeFromType(typeof(PythonType));  //!!!

		//public static object utype = Ops.GetDynamicTypeFromType(typeof(UserType));  //!!!

		public static char unichr(int i) {
			return (char)i;
		}
		
		public static object unicode = Ops.GetDynamicTypeFromType(typeof(string)); //!!! unicode str diffs
			
		//!!!vars

		public static object xrange = Ops.GetDynamicTypeFromType(typeof(XRange)); //PyXRange.pytype;

		public static List zip2(object s0, object s1) {
			IEnumerator i0 = Ops.GetEnumerator(s0);
			IEnumerator i1 = Ops.GetEnumerator(s1);
			List ret = new List();
			while (i0.MoveNext() && i1.MoveNext()) {
				ret.append(Tuple.MakeTuple(i0.Current, i1.Current));
			}
			return ret;
		}


		//??? should we fastpath the 1,2,3 item cases???
		public static List zip(params object[] seqs) {
			int N = seqs.Length;
			if (N == 2) return zip2(seqs[0], seqs[1]);
			IEnumerator[] iters = new IEnumerator[N];
			for (int i=0; i < N; i++) iters[i] = Ops.GetEnumerator(seqs[i]);

			List ret = new List();
			while (true) {
				object[] items = new object[N];
				for (int i=0; i < N; i++) {
					if (!iters[i].MoveNext()) return ret;  //!!! is this the right edge behavior
					items[i] = iters[i].Current;
				}
				ret.append(Tuple.Make(items));
			}
		}

		public static object Exception = Ops.GetDynamicTypeFromType(typeof(PythonExceptionNew));

		#region Generated builtin exceptions
		public static object ValueError = Ops.GetDynamicTypeFromType(typeof(PythonValueError));
		public static object ImportError = Ops.GetDynamicTypeFromType(typeof(PythonImportError));
		public static object RuntimeError = Ops.GetDynamicTypeFromType(typeof(PythonRuntimeError));
		public static object UnicodeTranslateError = Ops.GetDynamicTypeFromType(typeof(PythonUnicodeTranslateError));
		public static object KeyError = Ops.GetDynamicTypeFromType(typeof(PythonKeyError));
		public static object StopIteration = Ops.GetDynamicTypeFromType(typeof(PythonStopIteration));
		public static object PendingDeprecationWarning = Ops.GetDynamicTypeFromType(typeof(PythonPendingDeprecationWarning));
		public static object EnvironmentError = Ops.GetDynamicTypeFromType(typeof(PythonEnvironmentError));
		public static object LookupError = Ops.GetDynamicTypeFromType(typeof(PythonLookupError));
		public static object OSError = Ops.GetDynamicTypeFromType(typeof(PythonOSError));
		public static object DeprecationWarning = Ops.GetDynamicTypeFromType(typeof(PythonDeprecationWarning));
		public static object UnicodeError = Ops.GetDynamicTypeFromType(typeof(PythonUnicodeError));
		public static object UnicodeEncodeError = Ops.GetDynamicTypeFromType(typeof(PythonUnicodeEncodeError));
		public static object FloatingPointError = Ops.GetDynamicTypeFromType(typeof(PythonFloatingPointError));
		public static object ReferenceError = Ops.GetDynamicTypeFromType(typeof(PythonReferenceError));
		public static object NameError = Ops.GetDynamicTypeFromType(typeof(PythonNameError));
		public static object OverflowWarning = Ops.GetDynamicTypeFromType(typeof(PythonOverflowWarning));
		public static object IOError = Ops.GetDynamicTypeFromType(typeof(PythonIOError));
		public static object SyntaxError = Ops.GetDynamicTypeFromType(typeof(PythonSyntaxError));
		public static object FutureWarning = Ops.GetDynamicTypeFromType(typeof(PythonFutureWarning));
		public static object SystemExit = Ops.GetDynamicTypeFromType(typeof(PythonSystemExit));
		public static object EOFError = Ops.GetDynamicTypeFromType(typeof(PythonEOFError));
		public static object StandardError = Ops.GetDynamicTypeFromType(typeof(PythonStandardError));
		public static object TabError = Ops.GetDynamicTypeFromType(typeof(PythonTabError));
		public static object ZeroDivisionError = Ops.GetDynamicTypeFromType(typeof(PythonZeroDivisionError));
		public static object SystemError = Ops.GetDynamicTypeFromType(typeof(PythonSystemError));
		public static object IndentationError = Ops.GetDynamicTypeFromType(typeof(PythonIndentationError));
		public static object AssertionError = Ops.GetDynamicTypeFromType(typeof(PythonAssertionError));
		public static object UnicodeDecodeError = Ops.GetDynamicTypeFromType(typeof(PythonUnicodeDecodeError));
		public static object TypeError = Ops.GetDynamicTypeFromType(typeof(PythonTypeError));
		public static object IndexError = Ops.GetDynamicTypeFromType(typeof(PythonIndexError));
		public static object RuntimeWarning = Ops.GetDynamicTypeFromType(typeof(PythonRuntimeWarning));
		public static object KeyboardInterrupt = Ops.GetDynamicTypeFromType(typeof(PythonKeyboardInterrupt));
		public static object UserWarning = Ops.GetDynamicTypeFromType(typeof(PythonUserWarning));
		public static object SyntaxWarning = Ops.GetDynamicTypeFromType(typeof(PythonSyntaxWarning));
		public static object MemoryError = Ops.GetDynamicTypeFromType(typeof(PythonMemoryError));
		public static object UnboundLocalError = Ops.GetDynamicTypeFromType(typeof(PythonUnboundLocalError));
		public static object ArithmeticError = Ops.GetDynamicTypeFromType(typeof(PythonArithmeticError));
		public static object Warning = Ops.GetDynamicTypeFromType(typeof(PythonWarning));
		public static object NotImplementedError = Ops.GetDynamicTypeFromType(typeof(PythonNotImplementedError));
		public static object AttributeError = Ops.GetDynamicTypeFromType(typeof(PythonAttributeError));
		public static object OverflowError = Ops.GetDynamicTypeFromType(typeof(PythonOverflowError));
		public static object WindowsError = Ops.GetDynamicTypeFromType(typeof(PythonWindowsError));
		#endregion
	}
}
