/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.IO;

using IronPython.Objects;
using IronPython.AST;

namespace IronPython.Modules {
	/// <summary>
	/// Summary description for imp.
	/// </summary>
//	public class imp:PyBuiltinModule {
//
//		internal static PyObject importOne(PyModule mod, PyString fullName, bool keepTop) {
//			PyObject ret;
//			if (mod != null) {
//				string[] names = fullName.value.Split('.');
//				PyObject top = mod.tryToImportFromParent(PyString.make(names[0]));
//				if (top != null) {
//					PyObject bottom = top;
//					for (int i=1; i < names.Length; i++) {
//						bottom = bottom.importFrom(PyString.make(names[i]));
//					}
//
//					return keepTop ? top : bottom;
//				}
//			}
//
//			ret = importOne(fullName, keepTop);
//			if (ret != null) return ret;
//
//			throw Py.ImportError("{0} not found", fullName);
//		}
//
//
//		static PyObject importOne(PyString fullName, bool keepTop) {
//			PyObject ret;
//			//!!!if (sys.modules.__getitem__(fullName, out ret)) return ret;
//
//			if (fullName.find(PyString.make('.')) == -1) {
//				return loadTop(fullName);
//			}
//
//			string[] names = fullName.value.Split('.');
//
//			PyObject top = importOne(PyString.make(names[0]), true);
//			if (top == null) return null;
//
//			PyObject bottom = top;
//			for (int i=1; i < names.Length; i++) {
//				bottom = bottom.importFrom(PyString.make(names[i]));
//			}
//
//			if (keepTop) return top;
//			else return bottom;
//		}
//
//		static PyObject loadBuiltin(PyString name) {
//			Type ty = Type.GetType("IronPython.Modules." + name.value);
//			if (ty != null) {
//				PyObject ret = (PyObject)ty.GetConstructor(new Type[0]).Invoke(new object[0]);
//				//!!!sys.modules.__setitem__(name, ret);
//				return ret;
//			}
//			return null;
//		}
//
//		static PyObject loadFromCPython(PyString name) {
//			PyObject ret = CPyObject.import(name.value);
//			//!!!Console.WriteLine("loaded from CPython: " + name);
//			//!!!sys.modules.__setitem__(name, ret);
//			return ret;
//		}
//
//		internal static PyObject loadTop(PyString name) {
//			PyObject ret = loadBuiltin(name);
//			if (ret != null) return ret;
//
//			//!!!ret = loadFromPath(name, name, sys.path);
//			if (ret != null) return ret;
//
////			ret = loadFromCPython(name);
////			if (ret != null) return ret;
//
//			if (PyReflectedPackage.make(name, out ret)) return ret;
//
//			return null;
//		}
//
//		internal static PyObject importFromPath(PyString name, PyString fullName, PyObject path) {
//			PyObject ret;
//			//!!!if (sys.modules.__getitem__(fullName, out ret)) return ret;
//
//			return loadFromPath(name, fullName, path);
//		}
//
//		internal static PyObject loadFromPath(PyString name, PyString fullName, PyObject path) {
//			PyObject ret = null;
//			PyObject iter = path.__iter__();
//			PyObject dirObj;
//			while (iter.next(out dirObj)) {
//				string dirname = Py.asString(dirObj);
//
//				string pathname = Path.Combine(dirname, name.value);
//				//Console.WriteLine("looking for dir: " + pathname);
//				if (Directory.Exists(pathname)) {
//					if (File.Exists(Path.Combine(pathname, "__init__.py"))) {
//						ret = loadPackage(fullName, pathname);
//						break;
//					}
//				}
//				string filename = pathname+".py";
//				if (File.Exists(filename)) {
//					ret = loadFromSource(fullName, filename, null);
//					break;
//				}
//			}
//			return ret;
//		}
//
//		static PyObject loadFromSource(PyString fullName, string filename, PyObject __path__) {
//			//Console.WriteLine("found: " + filename);
//			Parser parser = Parser.fromFile(filename);
//			Stmt s = parser.parseFileInput();
//			ModuleDef mod = new ModuleDef(Name.make(fullName.value), s);
//
//			string outname = fullName.value+".exe"; //Path.Combine(dirname.value, name.value+".exe");
//			PyModule pmod = null; //!!!mod.generate(filename); //, outname);
//			if (__path__ != null) pmod.__path__ = __path__;
//
//			//Put this in modules dict so we won't reload with circular imports
//			//!!!sys.modules.__setitem__(fullName, pmod);
//
//			pmod.init();
//			return pmod;
//		}
//
//		static PyObject loadPackage(PyString fullName, string dirname) {
//			PyList __path__ = PyList.make(PyString.make(dirname));
//			PyObject pmod =
//				loadFromSource(fullName, Path.Combine(dirname, "__init__.py"), __path__);
//			return pmod;
//		}
//	}
}
