/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.IO;

using IronPython.Objects;

namespace IronPython.Modules {
//	public class @struct {
//		private static int readCount(string fmt, ref int index) {
//			return 1;
//		}
//
//		private static void pack_L(PyObject arg, char[] ret, ref int index) {
//			uint v = (uint)arg.toObject(typeof(uint), "L");  // expensive
//
//			ret[index++] = (char)((v >> 0) & 0xFF);
//			ret[index++] = (char)((v >> 8) & 0xFF);
//			ret[index++] = (char)((v >> 16) & 0xFF);
//			ret[index++] = (char)((v >> 24) & 0xFF);
//		}
//
//		private static PyObject unpack_L(string data, ref int index) {
//			uint i0 = (uint)data[index++];
//			uint i1 = (uint)data[index++];
//			uint i2 = (uint)data[index++];
//			uint i3 = (uint)data[index++];
//
//			return PyLong.make(i3<<24 | i2<<16 | i1<<8 | i0);
//		}
//
//		private static void pack(int count, char kind, PyObject arg, char[] ret, ref int index) {
//			switch(kind) {
//				case 'L': pack_L(arg, ret, ref index); break;
//				default: throw new NotImplementedException("pack: " + kind);
//			}
//		}
//
//		private static PyObject unpack(int count, char kind, string data, ref int index) {
//			switch(kind) {
//				case 'L': return unpack_L(data, ref index); 
//				default: throw new NotImplementedException("unpack: " + kind);
//			}
//		}
//
//		public /**/static PyObject pack(PyObject[] args) {
//			string fmt = Py.asString(args[0]);
//			int size = calcsize(fmt);
//			char[] ret = new char[size];
//			int index =0, findex=0;
//
//			if (fmt[0] == '<') findex++;
//
//			for (int i=1; i < args.Length; i++) {
//				int count = readCount(fmt, ref findex);
//				char kind = fmt[findex++];
//				pack(count, kind, args[i], ret, ref index);
//			}
//			// add assertion that we did the whole thing
//			return PyString.make(new string(ret));
//		}
//
//		public static PyObject unpack(string fmt, string data) {
//			int size = countitems(fmt);
//			PyObject[] ret = new PyObject[size];
//			int index =0, findex=0;
//
//			if (fmt[0] == '<') findex++;
//
//			for (int i=0; i < ret.Length; i++) {
//				int count = readCount(fmt, ref findex);
//				char kind = fmt[findex++];
//				ret[i] = unpack(count, kind, data, ref index);
//			}
//
//			return PyTuple.make(ret);
//		}
//
//		private static int countitems(string fmt) {
//			return fmt.Length-1; //!!! wrong
//		}
//
//		public static int calcsize(string fmt) {
//			return 4*(fmt.Length-1); //!!! wrong
//		}
//	}
}