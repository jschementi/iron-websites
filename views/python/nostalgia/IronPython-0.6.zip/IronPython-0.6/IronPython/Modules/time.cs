/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.Threading;

using IronPython.Objects;



namespace IronPython.Modules {
	public class time {
		public static double clock() {
			return DateTime.Now.Ticks/1.0e7;
		}

		public static void sleep(double tm) {
			Thread.Sleep((int)(tm*1000));
		}
	}
}
