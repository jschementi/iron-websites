/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using System.IO;

using IronPython.Objects;

namespace IronPython.Modules {
	public class nt {

		private static void addBase(string[] files, List ret) {
			foreach (string file in files) {
				ret.append(Ops.MakeString(Path.GetFileName(file)));
			}
		}

		public static void _exit(int code) {
			Console.WriteLine("requesting exit");
			//System.Environment.Exit(code);
		}

		public static List listdir(string path) {
			//Console.WriteLine("path: " + path);
			List ret = List.Make();
			string[] files = Directory.GetFiles(path);
			addBase(files, ret);
			addBase(Directory.GetDirectories(path), ret);
			return ret;
		}
		

		public static void unlink(string path) {
			File.Delete(path);
		}
	}
}