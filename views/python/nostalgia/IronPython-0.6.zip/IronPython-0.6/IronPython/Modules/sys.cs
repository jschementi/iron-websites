/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;
using IronPython.Objects;

namespace IronPython.Modules {
	public class sys {
		public static object argv = Ops.MakeList();

//		public static PyTuple builtin_module_names = PyTuple.make(
//			PyString.make("sys"), PyString.make("exceptions"),
//			PyString.make("time"), PyString.make("nt")
//		);

		[ThreadStatic] public static object exc_type=null;
		[ThreadStatic] public static object exc_value=null;
		[ThreadStatic] public static object exc_traceback=null;

		//[ThreadStatic] public /**/ static Exception raw_exception; //!!!

		public static object exc_info() {
			return Ops.MakeTuple(exc_type, exc_value, exc_traceback);
		}

//		public static void exit(int code) {
//			Console.WriteLine("exit requested with code: " + code);
//		}
//
//		public static PyObject getfilesystemencoding() {
//			return Py.None;
//		}
//
//		public static PyObject _getframe() {
//			throw new NotImplementedException();
//		}

		public static int maxint = Int32.MaxValue;

		public static Dict modules = new Dict();

//		public static PyList path = new PyList(PyString.make(
//			@"C:\Documents and Settings\Jim\My Documents\Visual Studio Projects\IronPython\tests\Lib"),
//			PyString.make(@"C:\Python23\Lib"));

		public static List path = new List();


		public static object platform = Ops.ToPython("java-clr");

		public static object ps1 = Ops.ToPython(">>> ");
		public static object ps2 = Ops.ToPython("... ");

		public static object stdout = new PythonFile(Console.OpenStandardOutput(), "w", false);
		public static object stderr = new PythonFile(Console.OpenStandardError(), "w", false);


		//!!! These are IronPython specific.  Should they be in a different module?

		public static void LoadAssemblyByName(string name) {
			ReflectedPackage.LoadAssemblyWithPartialName(name, false);
		}

		public static void LoadAssemblyFromFile(string filename) {
			ReflectedPackage.LoadAssemblyFromFile(filename, false);
		}
	}
}