/* *******************************************************************
 * Copyright (c) 2003, 2004 Jim Hugunin
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Common Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://www.eclipse.org/legal/cpl-v10.html 
 *  
 * Contributors: 
 *     Jim Hugunin     initial implementation 
 * ******************************************************************/
using System;

using System.Reflection;
using System.Reflection.Emit;

using IronPython.AST;

/// <summary>
/// This builds a stand-along console program that is used to generate "SystemUtil.dll".
/// That utility library contains code that can't be written in C#.  Currently it contains the single
/// function "IdentityHashCode" that makes a non-virtual call to Object.GetHashCode.  This is
/// used to implement Python's "id" builtin function.
/// </summary>
public class UtilGenerator
{
	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main(string[] args) {
		GenerateUtil();
	}


	public static void GenerateUtil() {
		AssemblyGen ag = new AssemblyGen("SystemUtil.gen", "SystemUtil", "SystemUtil.dll");

		TypeGen tg = ag.defineType("SystemUtils", typeof(object));
		CodeGen cg = tg.defineMethod(MethodAttributes.Public|MethodAttributes.Static, "IdentityHashCode",
			typeof(int), new Type[] { typeof(object) });
		cg.emitArgGet(0);
		cg.ilg.EmitCall(OpCodes.Call, typeof(object).GetMethod("GetHashCode"), null);
		cg.emitReturn();
		cg.finish();

		tg.finishType();

		ag.dumpAndLoad();
	}
}