""" This provides a more convenient harness for running this
    benchmark and collecting separate timings for each component.
"""

from time import clock
import sys

t0 = clock()
import b0
import b1
import b2
import b3
import b4
import b5
import b6  
print 'import time = %.2f' % (clock()-t0)

N = 2
tests = [b0,b1,b2,b3,b4,b5,b6]
#N, tests = 4, [b0,b1,b2,b3,b4,b6]

results = {}

t0 = clock()
for i in range(N):
    for test in tests:
        ts0 = clock()
        test.main()
        tm = (clock()-ts0)
        results.setdefault(test, []).append(tm)
        print '%.2f sec running %s' % ( tm, test.__name__)

for test in tests:
    print '%s = %f -- %r' % (test.__name__, sum(results[test])/N, results[test])

print 'all done in %.2f sec' % (clock()-t0)

