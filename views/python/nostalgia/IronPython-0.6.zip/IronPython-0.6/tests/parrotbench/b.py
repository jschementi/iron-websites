import b0
import b1
import b2
import b3
import b4
import b5
import b6

def main():
    for i in range(2):
        print "--> iteration", i
        print "--> b0"
        b0.main()
        print "--> b1"
        b1.main()
        print "--> b2"
        b2.main()
        print "--> b3"
        b3.main()
        print "--> b4"
        b4.main()
        print "--> b5"
        b5.main()
        print "--> b6"
        b6.main()
    print "--> All done."

if __name__ == '__main__':
    main()
